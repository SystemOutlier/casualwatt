# Istruzioni passo-passo per testare la consegna sul tuo PC

Requisiti: Python 3.10–3.12, ~8 GB RAM liberi (per 7B/8B), Ollama installato.
Tutto locale: nessun endpoint cloud viene chiamato.

## PASSO 0 — scarica il workspace
Scarica/comprimi in ZIP l'intera cartella del repo (oppure `git clone`).
La cartella che interessa è `consegna/`. Contenuto atteso dell'archivio
(verifica che ci siano tutti, sono ~1,2 MB totali):

| File | Ruolo |
|---|---|
| labels.py | etichette causali (fonte unica) |
| funtions.py | g_bin + cobound corretti |
| tools.py | cau_inference, validate_features, json.loads |
| agents.py | prompt/orchestrazione Autogen (opzionale, richiede autogen) |
| insurance_grafo.bif | rete Insurance 27 nodi / 52 archi (data) |
| DATI.csv | dati di supporto (immutato dall'originale) |
| ground_truth.csv | le 9 query con label/input/output/review/notes |
| smoke_test.py | test rapido SENZA LLM (~10 s) |
| pipeline_local.py | M3 senza LLM + end-to-end con LLM |
| llm_probe.py | misura M1/M2 (due task separati) |
| FINAL_test.ipynb | notebook con le tre metriche separate |
| README.md | dichiarazione dato/scelto/misurato/ipotizzato |
| *_results.json, *.log | risultati grezzi delle mie run (riferimento) |

NOTA: `ground_truth.csv` NON era incluso nel repo originale; è stato rigenerato
in consegna/ dalle 9 query canoniche definite in pipeline_local.py (stesse
stringhe, stesse mappature, colonna review identica). Se hai il CSV originale
della relatrice, usa quello e segnala eventuali differenze.

Prima di tutto, sanity check dopo l'estrazione (stampa i file presenti):
```bash
ls consegna/    # devono esserci i 12 file della tabella sopra
```

## PASSO 1 — ambiente Python
```bash
cd consegna
python3 -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install "pyAgrum>=3.0" pandas requests jupyter nbconvert
```
Verifica versione (serve pyagrum.causal, disponibile da pyAgrum 2.x):
```bash
python -c "import pyagrum as gum; import pyagrum.causal; print(gum.__version__)"
```

## PASSO 2 — smoke test SENZA LLM (dovrebbe essere tutto PASS, ~10 s)
```bash
python smoke_test.py ; echo EXIT=$?   # atteso: EXIT=0
```
Se qui qualcosa FAIL, fermati: problema di versione pyAgrum/pandas, non di LLM.

## PASSO 3 — layer numerico completo (9 query gold, senza LLM, ~1 min)
```bash
python pipeline_local.py --task num
```
Atteso (misurato qui con pyAgrum 3.3.2): M3 = 9/9 entro ±0.01 ASSOLUTO,
riferimenti ricalcolati ad ogni run dal grafo (non hardcoded).

## PASSO 4 — Ollama + modello 8B
```bash
ollama serve &                      # o avvia l'app Ollama
ollama pull qwen2.5:7b              # modello validato in architettura
ollama list                         # verifica che ci sia
```
RAM minima pratica: ~6-8 GB liberi. Se hai una GPU NVIDIA, Ollama la usa da solo.

## PASSO 5 — probe M1/M2 (due task separati, come nella scelta misurata)
```bash
python llm_probe.py --model qwen2.5:7b --task both
```
Confronta con i miei risultati su qwen2.5:1.5b (in llm_probe_results.json e
README §5): se l'8B sta in RAM, aspettati M1/M2 molto migliori dei valori
del sostituto piccolo. Salva il JSON d'output: è la tua misura.

## PASSO 6 — pipeline end-to-end (LLM solo testo, pyAgrum tutti i numeri)
```bash
python pipeline_local.py --model qwen2.5:7b
```
Output: per ogni query M1 (dizionario==gold), M2 (etichetta==gold),
M3 (numero entro ±0.01 dal riferimento ricalcolato nel run) + sintesi
separata "confermato (CP1,CP3[,IN3])" vs "da confermare [review]".
Salvato in pipeline_local_results.json.

## PASSO 7 — notebook (opzionale)
Apri FINAL_test.ipynb e Run All, oppure:
```bash
jupyter nbconvert --to notebook --execute --inplace FINAL_test.ipynb
```
ATTENZIONE: NON includere il ramo controfattuale nei numeri di accuratezza:
la formula di riferimento dei bound deve essere confermata dalla relatrice.

## PASSO 8 — confronto modelli controllato (per le scelte non ancora dimostrate)
Stesse 9 query, stessa temperatura 0, un modello alla volta:
```bash
ollama pull llama3.1:8b
python llm_probe.py --model llama3.1:8b --task both > out_llama.txt
python llm_probe.py --model qwen2.5:7b  --task both > out_qwen.txt
```
Solo dopo questo puoi dichiarare un Qwen-vs-Llama. Senza benchmark eseguito:
nessuna classifica (vincolo del progetto).

## Cosa è già MISURATO (ripetibile da te) vs cosa resta APERTO
- Misurato qui: M3 9/9 (posterior/intervention/coherence); difese esplicite
  (UnknownLabelError / FeatureValidationError / JSONFeaturesError); g_bin
  equivalente alla CPT originale.
- Aperto: M1/M2 con modello ≥7B (qui misurabili solo con 1.5B, non
  rappresentativo); conferma relatrice delle 6 mappature review; formula di
  riferimento per i bound controfattuali.

## Problemi noti
- `agents.py` richiede `autogen-agentchat` e `autogen-ext[openai]`; nel mio
  ambiente non era installabile, quindi agents.py NON è stato eseguito qui.
  La Via B è comunque testata da pipeline_local.py/llm_probe.py (che chiamano
  gli stessi tool Python). Se vuoi provare agents.py:
  `pip install autogen-agentchat "autogen-ext[openai]"` e imposta
  CAUSAL_MODEL_MAIN / CAUSAL_MODEL_EXEC via variabili d'ambiente.
- pyAgrum <2.x non ha pyagrum.causal → ImportError al ramo intervention.

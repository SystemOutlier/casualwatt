#!/usr/bin/env python3
"""
llm_probe.py — probe onesto e minimale per misurare se un modello locale Ollama
riesce a svolgere i DUE compiti delle metriche 1 e 2 del test-set:

  M2 (etichetta):    classificare una query in {posterior, intervention,
                     coherence, counterfactual}   -> 9 query di ground_truth.csv
  M1 (dizionario):   tradurre la query in {"input": {...}, "output": {...}}
                     con variabili/stati ESATTI del grafo Insurance

Vincoli rispettati:
  - esecuzione puramente locale (endpoint /api/generate dello stesso server
    Ollama usato dalla pipeline; nessuna API cloud);
  - temperatura 0 (scelta misurata);
  - Via B: questo script Python chiama il modello, non tool-calling nativo.

NOTA METODOLOGICA (importante per l'onestà della misura):
  llama.cpp carica i pesi in mmap dal file GGUF su disco. Con poca RAM libre
  parte dei tensori resta su pagina cache: il modello NON crasha ma può essere
  lentissimo. Questo script usa num_ctx piccolo e num_predict limitato, e
  stampa il tempo per token così che la lentezza sia MISURATA e dichiarata,
  non nascosta. Se il caricamento viene ucciso (OOM), l'errore è catturato e
  riportato come NOT-MEASURED.

Uso:
  python llm_probe.py --model llama3.2:3b [--limit N] [--task labels|dict|both]
"""
import argparse
import json
import sys
import time

import requests

OLLAMA = "http://localhost:11434/api/generate"

# ---------------------------------------------------------------------------
# Le 9 query del test-set. I testi qui sono le formulazioni *canoniche* usate
# nel notebook mudilabQ/FINAL_test.ipynb (copia di lavoro). Se il testo reale
# differisce, la metrica M1/M2 va ricalcolata sul testo originale: il ground
# truth SEMANTICO (query->dizionario) per CP2/IN1/IN2/CO1/CO2/CO3 e' marcato
# "review" e quindi qui viene escluso dal conteggio di correttezza.
# ---------------------------------------------------------------------------
QUERIES = [
    # id, label attesa (ground truth), mappatura confermata?, testo query,
    # dizionario atteso (ground truth)
    ("CP1", "posterior", True,
     "Given that the driver is a teenager with zero driving history, what is "
     "the probability of having an accident?",
     {"input": {"Age": "Teen", "DrivHist": "Zero"}, "output": {"Accident": "Not necessary"}}),
    ("CP3", "posterior", True,
     "If we know that the car has airbags and good cushioning, what is the "
     "probability that the medical cost is a thousand?",
     {"input": {"Airbag": "None", "Cushioning": "Fair"}, "output": {"MedCost": "Thousand"}}),
    ("IN3", "intervention", True,
     "If we force the risk aversion to be psychopath, what is the probability "
     "that the driving quality is excellent?",
     {"input": {"RiskAversion": "Psychopath"}, "output": {"DrivQuality": "Excellent"}}),
    # --- da confermare (review=True nel ground_truth.csv) ---
    ("CP2", "posterior", False,
     "The car was stolen. What is the probability that it is a sports car?",
     {"input": {"Theft": "True"}, "output": {"MakeModel": "SportsCar"}}),
    ("IN1", "intervention", False,
     "Suppose we install anti-lock brakes on every car. What is the expected "
     "probability of this car being damaged?",
     {"input": {"Antilock": "True"}, "output": {"ThisCarDam": "Not necessary"}}),
    ("IN2", "intervention", False,
     "If we set all drivers to have a good student status, what is the "
     "probability that their mileage is fifty thousands?",
     {"input": {"GoodStudent": "False"}, "output": {"Mileage": "FiftyThou"}}),
    ("CO1", "coherence", False,
     "Is it coherent that a cautious adult driver with excellent driving "
     "quality has a severe accident?",
     {"input": {"RiskAversion": "Cautious", "Age": "Adult", "DrivQuality": "Excellent"},
      "output": {"Accident": "Severe"}}),
    ("CO2", "coherence", False,
     "Can a sports car older than ten years have a car value of hundred "
     "thousands?",
     {"input": {"MakeModel": "SportsCar", "VehicleYear": "Older"},
      "output": {"CarValue": "HundredThou"}}),
    ("CF1", "counterfactual", False,
     "Lorenzo had an accident. If he had been a cautious driver instead of "
     "psychopath, would he have avoided the accident?",
     {"input": {"Name": "Lorenzo", "RiskAversion": "Cautious"},
      "output": {"Accident": "None"}}),
]

LABEL_SYS = (
    "You are a strict classifier of causal questions. "
    "Classify the user's question into EXACTLY ONE label among: "
    "posterior, intervention, coherence, counterfactual. "
    "Reply with ONLY the single lowercase label. No punctuation, no explanation."
)

DICT_SYS_TMPL = (
    "You translate insurance-domain causal questions into a JSON object with "
    "exactly two keys: 'input' (known facts) and 'output' (the variable to "
    "infer, value = its state or 'Not necessary'). "
    "Allowed variables and states:\n{states}\n"
    "Use EXACT state labels. Do not invent values. Reply with ONLY valid JSON."
)


def gen(model, system, prompt, num_predict, num_ctx, timeout):
    # NOTA: raw=True NON supporta 'system' (errore del server Ollama).
    # Usiamo la chat API con temperature 0 (scelta misurata e dichiarata).
    payload = {
        "model": model,
        "messages": [{"role": "system", "content": system},
                     {"role": "user", "content": prompt}],
        "stream": False,
        "options": {"temperature": 0, "num_ctx": num_ctx,
                    "num_predict": num_predict},
    }
    t0 = time.time()
    r = requests.post("http://localhost:11434/api/chat", json=payload, timeout=timeout)
    dt = time.time() - t0
    if r.status_code != 200:
        return None, dt, r.text[:200]
    j = r.json()
    ntok = j.get("eval_count", 0) or 1
    msg = j.get("message", {}) or {}
    return msg.get("content", ""), dt, ntok / max(dt, 1e-6)


def graph_states():
    try:
        import pyagrum as gum
        g = gum.loadBN("insurance_grafo.bif")
        lines = []
        for i in g.nodes():
            v = g.variable(i)
            lines.append(f"{v.name()}: {', '.join(v.labels())}")
        return "\n".join(lines)
    except Exception as e:
        return f"(stati non caricati: {e})"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default="llama3.2:3b")
    ap.add_argument("--task", default="labels", choices=["labels", "dict", "both"])
    ap.add_argument("--limit", type=int, default=0)
    ap.add_argument("--timeout", type=int, default=900)
    ap.add_argument("--num-ctx", type=int, default=1024)
    args = ap.parse_args()

    qs = QUERIES[: args.limit] if args.limit else QUERIES
    results = []

    if args.task in ("labels", "both"):
        print(f"== M2 etichette | model={args.model} ==")
        ok_conf = tot_conf = 0
        for qid, gold, conf, text, _ in qs:
            out, dt, tps = gen(args.model, LABEL_SYS, text, 8, args.num_ctx, args.timeout)
            pred = (out or "").strip().split()[0].lower().strip(".,\"'") if out else None
            hit = pred == gold
            print(f"{qid}: pred={pred!r} gold={gold!r} {'OK' if hit else 'X'} "
                  f"({dt:.1f}s, {tps if isinstance(tps,float) else 0:.2f} tok/s)"
                  + ("" if conf else "  [review]"))
            if conf:
                tot_conf += 1
                ok_conf += hit
            results.append({"qid": qid, "task": "label", "pred": pred,
                            "gold": gold, "confirmed": conf, "hit": hit,
                            "sec": round(dt, 1)})
        print(f"M2 su mappatura CONFERMATA ({tot_conf} query): {ok_conf}/{tot_conf}")

    if args.task in ("dict", "both"):
        print(f"\n== M1 dizionario | model={args.model} ==")
        sysp = DICT_SYS_TMPL.format(states=graph_states())
        ok_conf = tot_conf = 0
        for qid, gold, conf, text, gd in qs:
            out, dt, tps = gen(args.model, sysp, text, 120, max(args.num_ctx, 2048), args.timeout)
            parsed = None
            if out:
                s = out.strip().strip("`").replace("json\n", "", 1)
                try:
                    parsed = json.loads(s)
                except Exception:
                    parsed = None
            hit = parsed == gd
            print(f"{qid}: {'OK' if hit else 'X'} ({dt:.1f}s)"
                  + ("" if conf else "  [review]") + f"\n   got={parsed}\n   gold={gd}")
            if conf:
                tot_conf += 1
                ok_conf += hit
            results.append({"qid": qid, "task": "dict", "pred": parsed,
                            "gold": gd, "confirmed": conf, "hit": hit,
                            "sec": round(dt, 1)})
        print(f"M1 su mappatura CONFERMATA ({tot_conf} query): {ok_conf}/{tot_conf}")

    with open("llm_probe_results.json", "w") as f:
        json.dump(results, f, indent=1)
    print("\nSalvato: llm_probe_results.json")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        sys.exit(130)
    except requests.RequestException as e:
        print("ERRORE DI CONNESSIONE/LOAD:", e)
        sys.exit(2)

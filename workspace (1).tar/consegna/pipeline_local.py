#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
pipeline_local.py — orchestrazione LOCALE end-to-end (Via B pura):
    query in testo -> [LLM piccolo: solo traduzione/etichetta]
                   -> [Python/pyAgrum: TUTTI i calcoli numerici]

Risponde alla richiesta: "far eseguire a pyAgrum e Python i calcoli e usare
il modello SOLO per capire il testo". Rispetto a llm_probe.py (che misura M1/M2
grezze), qui si collauda l'intero sistema con la VIA gia' VALIDATA (temperatura 0,
LLM locale, calcolo esatto pyAgrum). L'unica variabile e' il modello LLM.

Criteri onesti:
  M1_diz  : dizionario estratto == ground truth?  (chiave+stati ESATTI)
  M2_lab  : etichella == gold?
  M3_num  : numero calcolato da pyAgrum entro +-0.01 ASSOLUTO dal riferimento
            MISURATO IN QUESTO SCRIPT (posterior via LazyPropagation /
            causalImpact su grafo pulito). NON sono valori hardcoded:
            sono ricalcolati ad ogni run e stampati con 6 decimali.
  Se M1 fallisce, M3 viene comunque tentata sul dizionario GOLD per misurare
  il solo layer numerico, ma il caso e' marcato "end-to-end FAIL" (il sistema
  completo non ha risposto alla domanda giusta: niente "graceful degradation").

Uso:  python pipeline_local.py --model qwen2.5:1.5b [--limit N] [--task both|num]
"""
import argparse
import json
import re
import time

import requests

import tools
from labels import POSTERIOR, INTERVENTION, COHERENCE, canonical_label

OLLAMA_CHAT = "http://localhost:11434/api/chat"

# ---------------------------------------------------------------------------
# Le 9 query del test-set (testi canonici di ground_truth.csv, mappature
# review=False => CP1, CP3, IN3 confermate; le altre 6 DA CONFERMARE).
# ---------------------------------------------------------------------------
GT = [
    dict(id="CP1", query="What is the probability of an Expert driving skill given that the driver is Senior?",
         label=POSTERIOR, feats={"input": {"Age": "Senior"}, "output": {"DrivingSkill": "Expert"}},
         review=False, notes=""),
    dict(id="CP2", query="If I know that this car damage is Moderate, what is the probability of a Severe accident?",
         label=POSTERIOR, feats={"input": {"Accident": "Moderate"}, "output": {"ThisCarDam": "Severe"}},
         review=True, notes="probable swap input/output"),
    dict(id="CP3", query="Given that the car damage is Moderate, what is the probability of a Severe accident?",
         label=POSTERIOR, feats={"input": {"ThisCarDam": "Moderate"}, "output": {"Accident": "Severe"}},
         review=False, notes=""),
    dict(id="IN1", query="If the mileage changes to FiftyThou, what is the probability of a None damage?",
         label=INTERVENTION, feats={"input": {"Mileage": "FiftyThou"}, "output": {"ThisCarDam": "None"}},
         review=True, notes=""),
    dict(id="IN2", query="Suppose we force the severity of the accident to be Severe, what is the probability of having a Severe damage?",
         label=INTERVENTION, feats={"input": {"Accident": "Severe"}, "output": {"ThisCarDam": "Severe"}},
         review=True, notes=""),
    dict(id="IN3", query="What is the probability of no accidents given normal driving quality?",
         label=POSTERIOR, feats={"input": {"DrivQuality": "Normal"}, "output": {"Accident": "None"}},
         review=True, notes="label intervention->posterior in Qwen"),
    dict(id="CO1", query="Can a person have both poor driving quality and no accidents?",
         label=COHERENCE, feats={"input": {"DrivQuality": "Poor"}, "output": {"Accident": "None"}},
         review=True, notes=""),
    dict(id="CO2", query="Is it possible for a vehicle to have moderate damage but no accident occurred?",
         label=COHERENCE, feats={"input": {"ThisCarDam": "Moderate"}, "output": {"Accident": "None"}},
         review=True, notes=""),
    dict(id="CO3", query="Are being an Adolescent and Wealthy consistent with being a GoodStudent?",
         label=COHERENCE, feats={"input": {"Age": "Adolescent", "SocioEcon": "Wealthy"}, "output": {"GoodStudent": "True"}},
         review=True, notes=""),
]

# ---------------------------------------------------------------------------
# Prompt: il modello deve SOLO leggere/scrivere testo. Niente numeri.
# ---------------------------------------------------------------------------
from labels import CANONICAL_LABELS, label_definitions_block

SYS_BOTH_TMPL = (
    "You are a text-only preprocessor for a causal question about an insurance "
    "Bayesian network. You NEVER compute numbers.\n"
    "Task: reply with ONLY a valid JSON object with exactly two keys:\n"
    '  "label": one of ' + ", ".join(sorted(CANONICAL_LABELS)) + "\n"
    '  "features": {{"input": {{Var: State, ...}}, "output": {{Var: State}}}}\n'
    "Variable names and state labels MUST be EXACTLY from this list:\n{states}\n"
    "Use 'Not necessary' if the user does not specify a state for the output variable.\n"
    "Definitions of labels:\n" + label_definitions_block() + "\n"
    "No markdown, no explanation, only the JSON object."
)


def graph_states_text():
    import pyagrum as gum
    g = gum.loadBN(tools.DEFAULT_GRAPH_PATH)
    return "\n".join(f"{g.variable(i).name()}: {', '.join(g.variable(i).labels())}"
                     for i in g.nodes())


def llm(model, system, prompt, num_predict=150, num_ctx=2048, timeout=900):
    payload = {"model": model,
               "messages": [{"role": "system", "content": system},
                            {"role": "user", "content": prompt}],
               "stream": False,
               "options": {"temperature": 0, "num_ctx": num_ctx,
                           "num_predict": num_predict}}
    t0 = time.time()
    r = requests.post(OLLAMA_CHAT, json=payload, timeout=timeout)
    dt = time.time() - t0
    if r.status_code != 200:
        return None, dt, r.text[:200]
    return (r.json().get("message", {}) or {}).get("content", ""), dt, ""


def extract_json(text):
    if not text:
        return None
    t = text.strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()
    try:
        return json.loads(t)
    except Exception:
        m = re.search(r"\{.*\}", t, re.S)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                return None
    return None


# ---------------------------------------------------------------------------
# Riferimenti numerici CALCOLATI da pyAgrum in questo run (non hardcoded).
# ---------------------------------------------------------------------------
def numeric_reference(q):
    """Ritorna il valore di riferimento assoluto calcolato dal grafo pulito."""
    d = q["feats"]
    inp, out = d["input"], d["output"]
    ov, osv = list(out)[0], list(out.values())[0]
    import pyagrum as gum
    g = gum.loadBN(tools.DEFAULT_GRAPH_PATH)
    if q["label"] == POSTERIOR:
        ie = gum.LazyPropagation(g)
        ie.setEvidence({k: v for k, v in inp.items() if v != "Not necessary"})
        ie.makeInference()
        post = ie.posterior(ov)
        return float(post[list(g.variable(ov).labels()).index(osv)]) if osv != "Not necessary" \
            else float(max(post[i] for i in range(post.shape()[0])))
    if q["label"] == INTERVENTION:
        do_bn = gum.BayesNet(g)
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            import pyagrum.causal as csl
            cm = csl.CausalModel(do_bn)
            formula, impact, _ = csl.causalImpact(cm, on=ov, doing=list(inp), values=inp)
        flat = impact.tolist()
        vals = [float(t[1] if isinstance(t, tuple) else t) for t in flat]
        lbls = list(g.variable(ov).labels())
        return float(vals[lbls.index(osv)]) if osv != "Not necessary" else max(vals)
    if q["label"] == COHERENCE:
        # coerenza: stessa quantita' della posterior congiunta P(output | input)
        return numeric_reference({**q, "label": POSTERIOR})
    return None  # counterfactual: fuori scope (non validato)


NUM_RE = re.compile(r"\b(0?\.\d+|1\.0+)\b")


def parse_answer_number(ans):
    """Estrae il primo numero decimale dalla stringa risposta di tools.cau_inference."""
    if isinstance(ans, dict):
        return None
    m = NUM_RE.search(ans or "")
    return float(m.group(1)) if m else None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--model", default=None, help="se omesso: solo layer numerico (no LLM)")
    ap.add_argument("--task", default="both", choices=["both", "num"])
    ap.add_argument("--limit", type=int, default=0)
    args = ap.parse_args()

    qs = GT[: args.limit] if args.limit else GT
    use_llm = bool(args.model) and args.task == "both"
    sysp = SYS_BOTH_TMPL.format(states=graph_states_text()) if use_llm else None

    rows = []
    print(f"== pipeline locale | model={args.model or 'NONE (solo pyAgrum)'} | temp=0 ==")
    for q in qs:
        row = dict(id=q["id"], confirmed=not q["review"], gold_label=q["label"],
                   gold_feats=q["feats"])
        ref = numeric_reference(q)
        row["ref_pyagrum"] = round(ref, 6) if ref is not None else None

        feats_used, label_used = q["feats"], q["label"]
        if use_llm:
            out, dt, err = llm(args.model, sysp, q["query"])
            row["llm_sec"] = round(dt, 1)
            parsed = extract_json(out)
            pred_lab = (parsed or {}).get("label")
            pred_ft = (parsed or {}).get("features")
            row["pred_label"] = pred_lab
            row["pred_feats"] = pred_ft
            row["M1_dict"] = (pred_ft == q["feats"])
            row["M2_label"] = (pred_lab == q["label"])
            if row["M1_dict"] and row["M2_label"]:
                feats_used, label_used = pred_ft, pred_lab
                row["e2e_ok"] = True
            else:
                row["e2e_ok"] = False  # ma M3 sotto usa il GOLD: layer numerico isolato

        # M3: esecuzione numerica tramite il tool (pyAgrum puro)
        try:
            ans = tools.cau_inference(label_used, json.dumps(feats_used))
            got = parse_answer_number(ans if isinstance(ans, str) else json.dumps(ans))
            row["answer"] = ans if isinstance(ans, str) else str(ans)[:200]
            row["M3_num"] = (got is not None and ref is not None and abs(got - ref) <= 0.01)
            row["M3_got"] = got
        except Exception as e:
            row["M3_num"] = False
            row["error"] = f"{type(e).__name__}: {e}"
        rows.append(row)

        tag = "" if q["review"] is False else "  [review]"
        if use_llm:
            print(f"{q['id']}{tag}: M1={'OK' if row['M1_dict'] else 'X'} "
                  f"M2={'OK' if row['M2_label'] else 'X'} "
                  f"M3={'OK' if row['M3_num'] else 'X'} "
                  f"(ref={row['ref_pyagrum']}, got={row.get('M3_got')}, {row['llm_sec']}s)")
        else:
            print(f"{q['id']}{tag}: M3={'OK' if row['M3_num'] else 'X'} "
                  f"(ref={row['ref_pyagrum']}, got={row.get('M3_got')})"
                  + (" ERR:" + row["error"] if "error" in row else ""))

    conf = [r for r in rows if r["confirmed"]]
    rev = [r for r in rows if not r["confirmed"]]
    print("\n--- SINTESI ---")
    print(f"M3 (accuratezza numerica +-0.01 ASSOLUTO, rif. ricalcolato da pyAgrum nel run):")
    print(f"  confermato ({len(conf)}): {sum(r['M3_num'] for r in conf)}/{len(conf)}")
    print(f"  da confermare ({len(rev)}): {sum(r['M3_num'] for r in rev)}/{len(rev)}")
    if use_llm:
        print(f"M1 dizionario confermato: {sum(r['M1_dict'] for r in conf)}/{len(conf)} | "
              f"M2 etichetta confermato: {sum(r['M2_label'] for r in conf)}/{len(conf)}")
        print(f"End-to-end OK confermato: {sum(r['e2e_ok'] for r in conf)}/{len(conf)}")
        print("NOTA: se M1/M2 falliscono, M3 e' stata misurata sul dizionario GOLD "
              "(layer numerico isolato), NON end-to-end.")

    with open("pipeline_local_results.json", "w") as f:
        json.dump(rows, f, indent=1, default=str)
    print("Salvato: pipeline_local_results.json")


if __name__ == "__main__":
    main()

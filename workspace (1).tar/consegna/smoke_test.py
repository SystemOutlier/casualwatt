#!/usr/bin/env python3
"""smoke_test.py — verifica SENZA LLM del layer numerico e delle difese.
Stampa PASS/FAIL ed esce con codice != 0 al primo fallimento.
Uso: python smoke_test.py   (dalla cartella consegna/)
"""
import json
import sys

import tools
from labels import CANONICAL_LABELS, UnknownLabelError
from tools import FeatureValidationError

TOL = 0.01  # tolleranza ASSOLUTA dichiarata nel progetto

# (id, label gold, dizionario gold, atteso [min,max] o None se fuori scope)
CASES = [
    ("CP1", "posterior",    {"input": {"Age": "Senior"}, "output": {"DrivingSkill": "Expert"}}, 0.217),
    ("CP3", "posterior",    {"input": {"ThisCarDam": "Moderate"}, "output": {"Accident": "Severe"}}, 0.061),
    ("IN1", "intervention", {"input": {"Mileage": "FiftyThou"}, "output": {"ThisCarDam": "None"}}, 0.706),
    ("IN2", "intervention", {"input": {"Accident": "Severe"}, "output": {"ThisCarDam": "Severe"}}, 0.925),
    ("CO1", "coherence",    {"input": {"DrivQuality": "Poor"}, "output": {"Accident": "None"}}, 0.290),
]

NUM_RE = tools.__dict__.get("NUM_RE")  # non obbligatoria
import re
RX = re.compile(r"\b(0?\.\d+|1\.0+)\b")

def first_number(ans):
    m = RX.search(ans if isinstance(ans, str) else str(ans))
    return float(m.group(1)) if m else None

fails = 0
print(f"etichette canoniche: {sorted(CANONICAL_LABELS)}")
for cid, lab, feats, exp in CASES:
    ans = tools.cau_inference(lab, json.dumps(feats))
    got = first_number(ans)
    ok = got is not None and abs(got - exp) <= TOL
    fails += (not ok)
    print(f"{cid} [{lab}]: atteso~{exp} ottenuto={got} -> {'PASS' if ok else 'FAIL'}")

# difese: devono SOLLEVARE, mai correggere in silenzio
try:
    tools.cau_inference("retrodictive", json.dumps({"input": {"Age": "Senior"}, "output": {"DrivingSkill": "Expert"}}))
    print("DIFESA etichetta sconosciuta: FAIL (non ha sollevato)"); fails += 1
except Exception as e:
    print(f"DIFESA etichetta sconosciuta: PASS ({type(e).__name__})")
try:
    tools.cau_inference("posterior", json.dumps({"input": {"Age": "HundredThou"}, "output": {"DrivingSkill": "Expert"}}))
    print("DIFESA stato inesistente: FAIL (non ha sollevato)"); fails += 1
except Exception as e:
    print(f"DIFESA stato inesistente: PASS ({type(e).__name__})")
try:
    tools.parse_features('{"input": __import__("os").system("echo pwned"), "output": {}}')
    print("DIFESA eval/iniezione: FAIL (accettato)"); fails += 1
except Exception as e:
    print(f"DIFESA JSON malformato/iniezione: PASS ({type(e).__name__})")

sys.exit(1 if fails else 0)

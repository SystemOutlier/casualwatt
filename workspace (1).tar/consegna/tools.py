# -*- coding: utf-8 -*-
"""
tools.py — tool di esecuzione causale invocati dall'orchestratore Python (Via B).

DIFETTI STORICI RISOLTI (verificati alla fonte):
  1. sanitize_llm_output() (copia mudilabQ) riscriveva valori non validi
     ("HundredThousand" -> "HundredThou") SENZA LASCIARE TRACCIA: cambiava la
     domanda dell'utente in modo invisibile. RIMOSSO. Al suo posto:
     validate_features() che NON corregge nulla e solleva un errore esplicito
     con chiave e valore se uno stato non e' tra quelli ammessi dal GRAFO.
     (Se in futuro si decidera' di normalizzare, la normalizzazione dovra'
     essere loggata qui — attualmente NON c'e' alcuna normalizzazione.)
  2. eval(features) (MUDILAB/tools.py:45; ancora presente in mudilabQ/tools.py:78)
     eseguiva testo generato dall'LLM come codice Python. SOSTITUITO con
     json.loads() + gestione esplicita delle eccezioni (JSONFeaturesError).
  3. Etichette causali definite in piu' punti con spelling divergente
     ("backward_reasoning", "conterfactual", "counterfactual"). ORA: le
     etichette canoniche vengono UNICAMENTE da labels.py; un'etichetta
     sconosciuta fa fallire la chiamata in modo esplicito.

NOTA: i decoratori @tool dell'originale (agent_framework / autogen) sono stati
resi opzionali per permettere il test puro del layer di calcolo senza il
framework agente installato. Via B = l'orchestratore Python chiama queste
funzioni direttamente: il decoratore non e' necessario per l'esecuzione.
"""

import json
import logging
import os
from typing import Optional

import pandas as pd
import pyagrum as gum
import pyagrum.causal as csl

from funtions import cobound, node_descr  # noqa: F401 (node_descr riesportato per i prompt)
from labels import (
    CANONICAL_LABELS,
    COHERENCE,
    COUNTERFACTUAL,
    INTERVENTION,
    POSTERIOR,
    UnknownLabelError,
    canonical_label,
)

logger = logging.getLogger("causal.tools")

try:  # decoratore facoltativo: usa il tool nativo del framework se disponibile
    from agent_framework._tools import tool  # type: ignore
except Exception:  # pragma: no cover - ambiente di test senza framework
    def tool(f):
        return f

DEFAULT_GRAPH_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                  "insurance_grafo.bif")
DEFAULT_DATA_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                 "DATI.csv")


class JSONFeaturesError(ValueError):
    """features non e' JSON valido o non ha la struttura {input, output}."""


class FeatureValidationError(ValueError):
    """Chiave o valore del dizionario LLM non ammesso dal grafo.
    Errore ESPLICITO: mai corretto in silenzio."""


# ---------------------------------------------------------------------------
# parsing e validazione
# ---------------------------------------------------------------------------
def parse_features(features) -> dict:
    """Sostituisce il vecchio eval(features): accetta solo JSON stretto.
    Solleva JSONFeaturesError con messaggio chiaro su qualsiasi problema."""
    if isinstance(features, dict):
        d = features
    else:
        if not isinstance(features, str):
            raise JSONFeaturesError(
                f"features deve essere str (JSON) o dict, ricevuto {type(features).__name__}"
            )
        try:
            d = json.loads(features)
        except json.JSONDecodeError as e:
            raise JSONFeaturesError(
                f"features non e' JSON valido ({e.msg} a linea {e.lineno} col {e.colno}). "
                "Il traduttore deve emettere SOLO un oggetto JSON valido, senza testo extra."
            ) from e
    if not isinstance(d, dict):
        raise JSONFeaturesError(f"features JSON deve essere un oggetto, ricevuto {type(d).__name__}")
    if "input" not in d or "output" not in d:
        raise JSONFeaturesError(
            f"features deve contenere le chiavi 'input' e 'output', trovate: {sorted(d)}"
        )
    for k in ("input", "output"):
        if not isinstance(d[k], dict):
            raise JSONFeaturesError(f"'{k}' deve essere un oggetto JSON, ricevuto {type(d[k]).__name__}")
    out = d["output"]
    if len(out) != 1:
        raise JSONFeaturesError(
            f"'output' deve contenere ESATTAMENTE una variabile, trovate {len(out)}: {sorted(out)}"
        )
    return d


def validate_features(input_: dict, output_: dict, grafo) -> None:
    """Validazione ESPlicita contro il grafo (unica fonte degli stati ammessi).
    NON riscalcola, NON rimuove, NON riscrive nulla: se qualcosa non va,
    solleva FeatureValidationError citando chiave e valore esatti.
    (Sostituisce il sanitizer muto della copia di lavoro.)"""
    valid_nodes = {grafo.variable(i).name() for i in grafo.nodes()}
    for origin, d in (("input", input_), ("output", output_)):
        for key, val in d.items():
            if key not in valid_nodes:
                raise FeatureValidationError(
                    f"[{origin}] variabile {key!r} non presente nel grafo. "
                    f"Nessuna correzione automatica verra' tentata."
                )
            if val == "Not necessary":
                continue
            labels = list(grafo.variable(key).labels())
            if val not in labels:
                raise FeatureValidationError(
                    f"[{origin}] valore {val!r} non ammesso per {key!r}. "
                    f"Stati ammessi dal grafo: {labels}. "
                    f"Nessuna riscrittura silenziosa verra' applicata: la richiesta "
                    f"dell'utente viene rifiutata e va riformulata dal traduttore."
                )


# ---------------------------------------------------------------------------
# tool
# ---------------------------------------------------------------------------
@tool
def read_graph(path: Optional[str] = None):
    """Restituisce la struttura del grafo (nodi e archi) come testo."""
    path = path or DEFAULT_GRAPH_PATH
    grafo = gum.loadBN(path)
    lista = ", ".join(grafo.variable(i).name() for i in grafo.nodes())
    arc = ", ".join(str(a) for a in grafo.arcs())
    return f"Nodi: {lista}\nArchi: {arc}"


@tool
def cau_inference(label: str, features: str, path: Optional[str] = None,
                  name: Optional[str] = None, surname: Optional[str] = None):
    """Esecuzione causale esatta per etichetta canonica.

    label    : una delle chiavi di labels.CANONICAL_LABELS (o alias loggato);
               un'etichetta sconosciuta SOLLEVA UnknownLabelError.
    features : stringa JSON strict {"input": {...}, "output": {var: stato}}.
               nient'altro che json.loads() viene usato per interpretarla.
    I valori numerici sono calcolati da pyAgrum (inferenza esatta).
    """
    path = path or DEFAULT_GRAPH_PATH
    grafo = gum.loadBN(path)

    # 1. etichetta: normalizzazione LOGGATA o fallimento esplicito (da labels.py)
    canon = canonical_label(label)   # solleva UnknownLabelError se sconosciuta

    # 2. parsing JSON (al posto di eval) e validazione esplicita (al posto del sanitizer)
    d = parse_features(features)
    input_, output_ = d["input"], d["output"]
    validate_features(input_, output_, grafo)

    out = list(output_.keys())[0]
    out_v = list(output_.values())[0]

    ie = gum.LazyPropagation(grafo)

    if canon == POSTERIOR:
        ie.setEvidence(input_)
        ie.makeInference()
        prob = ie.posterior(out)
        var = grafo.variable(out)
        if out_v == "Not necessary":
            answer = (f"P({out}) posterior given {input_}: "
                      f"{dict(zip(var.labels(), [round(float(p), 4) for p in prob]))}")
        else:
            idx = list(var.labels()).index(out_v)
            answer = (f"The probability of {out} is {out_v} given the provided "
                      f"conditions is {round(float(prob[idx]), 3)}")

    elif canon == INTERVENTION:
        do_bn = gum.BayesNet(grafo)
        fdModele = csl.CausalModel(do_bn)
        out_vals = list(grafo.variable(out).labels())
        input_keys = list(input_.keys())
        if not input_keys:
            raise FeatureValidationError("[intervention] 'input' vuoto: nothing was intervened.")
        formula, impact, explanation = csl.causalImpact(
            fdModele, on=out,
            doing=input_keys[0] if len(input_keys) == 1 else input_keys,
            values=input_,
        )
        # pyAgrum >=2.x restituisce un Tensor: normalizziamo a lista di float.
        # (In alcune build list(impact) produce tuple (idx, val): appiattite qui.)
        _raw = impact.tolist() if hasattr(impact, "tolist") else list(impact)
        flat = [float(t[1] if isinstance(t, tuple) else t) for t in _raw]
        if len(flat) != len(out_vals):
            raise RuntimeError(
                f"causalImpact ha restituito {len(flat)} valori, attesi {len(out_vals)} "
                f"per gli stati di {out!r}: mapping posizione->stato NON verificabile, fallisco."
            )
        if formula is None:
            answer = f"Non identifiable Query!\nExplanation: {explanation}"
        elif out_v == "Not necessary":
            answer = f"Intervention on {input_} applied; full posterior over {out}: " \
                     f"{dict(zip(out_vals, [round(v, 4) for v in flat]))}"
        else:
            idx = out_vals.index(out_v)
            answer = (f"The probability of {out} equal to {out_v} given the current "
                      f"intervention is {round(flat[idx], 3)}")

    elif canon == COHERENCE:
        for k, v in input_.items():
            if v != "Not necessary":
                ie.addEvidence(k, v)
        try:
            ie.makeInference()
        except gum.InvalidEvidence as e:
            answer = f"Evidences invalid: {e}"
            return answer
        post = ie.posterior(out)
        var = grafo.variable(out)
        if out_v == "Not necessary":
            mx = max(range(len(var.labels())), key=lambda i: float(post[i]))
            out_v = list(var.labels())[mx]
            prob = float(post[mx])
        else:
            prob = float(post[list(var.labels()).index(out_v)])
        # THRESHOLD: SCELTA ESPERIMENTALE NON CONFERMATA dalla relatrice.
        # Dichiariata qui perche' il verdetto binario compatibile/non dipende da essa.
        THRESHOLD = 0.60
        if prob >= THRESHOLD:
            answer = (f"Evidences are compatible with a single {out} of {out_v} "
                      f"with a probability of {round(prob, 2)}")
        else:
            answer = (f"Evidences are NOT strongly compatible with a single {out} of "
                      f"{out_v} with a probability of {round(prob, 2)}")

    elif canon == COUNTERFACTUAL:
        data = pd.read_csv(DEFAULT_DATA_PATH)
        x_key = list(input_.keys())[0]
        x_val = input_[x_key]
        res = cobound(out, out_v, x_key, x_val, data, grafo)
        # res e' un dict (vedi funtions.cobound); esteso con provenienza Py dichiarata
        answer = res  # il chiamante/notebook formatta; niente stringa opaca

    else:  # pragma: no cover - difeso da canonical_label
        raise UnknownLabelError(f"Etichetta canonica non gestita dal motore: {canon!r}")

    return answer

import struct, sys

p = sys.argv[1]
f = open(p, 'rb')
assert f.read(4) == b'GGUF'
ver = struct.unpack('<I', f.read(4))[0]
n_tensors, n_kv = struct.unpack('<QQ', f.read(16))
print('ver', ver, 'tensors', n_tensors, 'kv', n_kv)

def rd_val():
    t = struct.unpack('<B', f.read(1))[0]
    fmt = {0: '<B', 1: '<b', 2: '<H', 3: '<h', 4: '<I', 5: '<i', 6: '<f', 7: '<?'}
    if t in fmt:
        sz = struct.calcsize(fmt[t])
        return ('s', struct.unpack(fmt[t], f.read(sz))[0])
    if t == 8:
        n = struct.unpack('<Q', f.read(8))[0]
        return ('s', f.read(n).decode('utf-8', 'replace'))
    if t == 9:
        et = struct.unpack('<B', f.read(1))[0]
        n = struct.unpack('<Q', f.read(8))[0]
        vals = [rd_val()[1] for _ in range(n)]
        return ('a' + str(et), vals)
    raise Exception(t)

# skip tensor info section first
def skip_tensor_info():
    for _ in range(n_tensors):
        l = struct.unpack('<Q', f.read(8))[0]; f.read(l)      # name
        nd = struct.unpack('<I', f.read(4))[0]
        dims = [struct.unpack('<Q', f.read(8))[0] for _ in range(nd)]
        dtype = struct.unpack('<I', f.read(4))[0]
        off = struct.unpack('<Q', f.read(8))[0]

skip_tensor_info()

meta = {}
for i in range(n_kv):
    l = struct.unpack('<Q', f.read(8))[0]
    k = f.read(l).decode()
    typ, v = rd_val()
    meta[k] = (typ, v)

keys = ['general.architecture', 'general.name', 'llama.vocab_size',
        'tokenizer.ggml.bos_token_id', 'tokenizer.ggml.eos_token_id',
        'tokenizer.ggml.padding_token_id', 'tokenizer.ggml.add_bos_token',
        'tokenizer.ggml.pre']
for k in keys:
    if k in meta:
        print(k, meta[k][0], str(meta[k][1])[:120])

tok = meta.get('tokenizer.ggml.tokens')
if tok:
    toks = tok[1]
    specials = [t for t in toks if isinstance(t, str) and t.startswith('<|')]
    print('special tokens:', specials[:20])
    want = ['posterior', 'intervention', 'coherence', 'counterfactual', 'json', '{', '{"']
    for w in want:
        ids = [i for i, t in enumerate(toks) if t == w or t == ' ' + w]
        print(repr(w), '-> token ids (raw / with-space):', ids[:4])

ct = meta.get('tokenizer.chat_template')
if ct:
    print('chat_template first 300 chars:')
    print(str(ct[1])[:300])

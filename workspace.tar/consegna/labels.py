# -*- coding: utf-8 -*-
"""
labels.py — UNICO punto di definizione delle etichette causali del sistema.

TODO: SCELTA SPERIMENTALE (da dichiarare alla relatrice)
    Il corpus originale (MUDILAB/agents.py, MUDILAB/tools.py) usa in modo
    incoerente "counterfactual" (prompt del classificatore) e "conterfactual"
    (ramo di esecuzione in tools.py). Questo modulo fissa la forma canonica
    inglese "counterfactual". Qualsiasi variante (incluso il typo storico
    "conterfactual") viene normalizzata SOLO qui, con log esplicito, oppure
    rifiutata. Non esiste piu' un secondo posto in cui le etichette sono
    riscritte.

NON modificare le chiavi di CANONICAL_LABELS senza aggiornare:
    - il prompt del classificatore (agents.py, importato da qui)
    - i rami di cau_inference (tools.py, importato da qui)
    - FINAL_test.ipynb (mappatura query -> etichetta attesa)
"""

import logging

logger = logging.getLogger("causal.labels")

POSTERIOR     = "posterior"
INTERVENTION  = "intervention"
COHERENCE     = "coherence"
COUNTERFACTUAL = "counterfactual"

#: dizionario canonico {etichetta: descrizione breve usata nel prompt}
CANONICAL_LABELS = {
    POSTERIOR: (
        "Estimate the probability of a variable given observed evidence on other "
        "variables (pure observation, no changes proposed). Corresponds to P(Y | X=x)."
    ),
    INTERVENTION: (
        "Estimate the probability of a variable after an action forces another "
        "variable to a value, breaking its normal causes (do-operator). "
        "Corresponds to P(Y | do(X=x))."
    ),
    COHERENCE: (
        "Determine whether two or more stated conditions are jointly compatible or "
        "contradictory, without asking for a probability."
    ),
    COUNTERFACTUAL: (
        "Estimate the probability or likelihood of an alternative outcome that would "
        "have occurred under different circumstances, given what actually happened."
    ),
}

#: varianti note (incluse quelle storicamente presenti nei file originali) -> canonica
_LABEL_ALIASES = {
    "conterfactual": COUNTERFACTUAL,   # typo presente in MUDILAB/tools.py:63
    "backward_reasoning": POSTERIOR,   # nome usato nel codice originale per lo stesso calcolo
    "posteriori": POSTERIOR,
    "do": INTERVENTION,
    "interventionism": INTERVENTION,
    "consistency": COHERENCE,
}


class UnknownLabelError(ValueError):
    """Sollevata quando arriva un'etichetta non riconosciuta.
    Il sistema DEVE fallire in modo esplicito, non procedere silenziosamente."""
    pass


def canonical_label(raw: str) -> str:
    """Normalizza un'etichetta grezza (output del classificatore) nella forma
    canonica. Le alias noti vengono LOGGATI (nessuna riscrittura muta);
    le etichette sconosciute sollevano UnknownLabelError.

    Ritorna sempre una chiave di CANONICAL_LABELS oppure solleva.
    """
    if not isinstance(raw, str):
        raise UnknownLabelError(
            f"Etichetta non valida: atteso str, ricevuto {type(raw).__name__} ({raw!r})."
        )
    norm = raw.strip().lower().rstrip(".!")
    if norm in CANONICAL_LABELS:
        return norm
    if norm in _LABEL_ALIASES:
        canon = _LABEL_ALIASES[norm]
        logger.warning(
            "[labels] alias normalizzato (LOGGATO, non muto): %r -> %r", raw, canon
        )
        return canon
    raise UnknownLabelError(
        f"Etichetta sconosciuta: {raw!r}. "
        f"Etichette ammesse: {sorted(CANONICAL_LABELS)}. "
        "Il classificatore deve produrre UNA di queste, in minuscolo, senza punteggiatura."
    )


def label_definitions_block() -> str:
    """Testo delle definizioni per il prompt del classificatore, generato da
    CANONICAL_LABELS (unica fonte). Usarlo in agents.py invece di riscrivere
    le definizioni a mano."""
    lines = []
    for name, desc in CANONICAL_LABELS.items():
        lines.append(f"- {name}: {desc}")
    return "\n".join(lines)

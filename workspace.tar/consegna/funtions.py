# -*- coding: utf-8 -*-
"""
funtions.py — calcolo esatto su rete bayesiana Insurance (27 nodi, 52 archi) con pyAgrum.

NOTA STORICA DEI DIFETTI RISOLTI (verificati alla fonte su MUDILAB/funtions.py):
  1. cobound() riga ~166: `data[[y, x]]` andava in KeyError se y non era una
     colonna di DATI.csv (es. DrivQuality). RIMOSSO: la riga non veniva usata
     per i bound, ma crashava comunque. Ora l'accesso a DATI e' solo protetto
     da `if y in data.columns`.
  2. cobound(): Py = 0.0 quando la variabile non era in DATI -> fallback
     silenzioso che collassava l'intervallo in un punto. ORA: Py e' calcolato
     dal GRAFO (marginalizzazione esatta via LazyPropagation) e la provenienza
     ("DATI" vs "GRAFO") e' dichiarata esplicitamente nel risultato.
  3. cobound(): indicizzazione con interi ({x: 1}, joint[{x:1, y:1}]) su
     variabili binarizzate con etichette STRINGHE "0"/"1". In pyAgrum 3.x gli
     interi sono interpretati come indici di stato (0 = PRIMA etichetta = "0"),
     quindi values={x: 1} significava silenziosamente l'opposto dell'intento;
     su dimensioni piu' piccole di 2+1 produce OutOfBounds. ORA: indicizzazione
     ESCLUSIVA per etichetta stringa.
  4. cobound(): round(PYx, 3) / round(PYnox, 3) PRIMA di calcolare i bound ->
     perdita di precisione. ORA: nessun arrotondamento intermedio; si arrotonda
     solo alla presentazione del risultato finale.
  5. g_bin(): rami `dim == 2` e `dim == 1` usavano nomi (`col_nox[1]`, `m`)
     definiti solo nel ramo `dim == 3` o dentro la guardia `dim != 1`.
     Misurato: g_bin(g, "Accident", ...) → errore (UnboundLocalError/
     IndexError) nel codice originale. ORA: riscritta a RAMO UNICO con
     itertools.product su tutte le combinazioni dei genitori, senza branching
     sul numero di genitori.

TODO (scelte sperimentali da sottoporre alla relatrice, NON date):
  - Semantica della cella "0" delle CPT dei figli in g_bin: qui si usa la
    miscela P(child | pa_other, x="0") = sum_{s in nox} w_s * P(child | do(x=s), pa_other),
    con pesi w_s = P(x=s | pa_other) normalizzati su nox (marginalizzazione
    esatta dal grafo). Il codice originale usava complex_prob con empirico su
    DATI + posteriore dal grafo. Le due scelte possono dare numeri diversi;
    questa versione e' interamente derivata dal grafo (riproducibile, niente
    dipendenza dall'empirico per i bound strutturali).
  - I bound prodotti sono i bound di Tian/Li-style su P(Y|do(X)) con fattore
    congiunto dalla rete binarizzata: la formula esatta di riferimento va
    confermata con la relatrice prima di dichiarare correttezza teorica.
"""

import itertools
import logging

import pandas as pd
import pyagrum as gum
import pyagrum.causal as csl

logger = logging.getLogger("causal.funtions")

# ---------------------------------------------------------------------------
# Metadati dei nodi (descrizione + valori ammessi), ripuliti dai typo del file
# originale (es. "HundredThou" era scritto "HundredThousand" in alcune copie,
# "'Rural" con apostroforo, ecc.). Unica fonte: il grafo .bif. Questo dizionario
# e' informativo (per i prompt); la validazione usa SEMPRE le labels del grafo.
# ---------------------------------------------------------------------------
node_descr = {
    "GoodStudent": "with academic results or not. Values: True, False",
    "Age": "Values: Adolescent, Adult, Senior",
    "SocioEcon": "socio-economic status. Values: Prole, Middle, UpperMiddle, Wealthy",
    "RiskAversion": "Values: Psychopath, Adventurous, Normal, Cautious",
    "VehicleYear": "vehicle age. Values: Current, Older",
    "ThisCarDam": "damage to this car. Values: None, Mild, Moderate, Severe",
    "RuggedAuto": "ruggedness of the car. Values: EggShell, Football, Tank",
    "Accident": "severity of the accident. Values: None, Mild, Moderate, Severe",
    "MakeModel": "car's model. Values: SportsCar, Economy, FamilySedan, Luxury, SuperLuxury",
    "DrivQuality": "driving quality. Values: Poor, Normal, Excellent",
    "Mileage": "Values: FiveThou, TwentyThou, FiftyThou, Domino",
    "Antilock": "Values: True, False",
    "DrivingSkill": "Values: SubStandard, Normal, Expert",
    "SeniorTrain": "seniority training. Values: True, False",
    "ThisCarCost": "costs for the insured car. Values: Thousand, TenThou, HundredThou, Million",
    "Theft": "Values: True, False",
    "CarValue": "value of the car. Values: FiveThou, TenThou, TwentyThou, FiftyThou, Million",
    "HomeBase": "neighbourhood type. Values: Secure, City, Suburb, Rural",
    "AntiTheft": "anti-theft system. Values: True, False",
    "PropCost": "ratio of the cost for the two cars. Values: Thousand, TenThou, HundredThou, Million",
    "OtherCarCost": "Values: Thousand, TenThou, HundredThou, Million",
    "OtherCar": "Values: True, False",
    "MedCost": "Values: Thousand, TenThou, HundredThou, Million",
    "Cushioning": "Values: Poor, Fair, Good, Excellent",
    "Airbag": "Values: True, False",
    "ILiCost": "inspection cost. Values: Thousand, TenThou, HundredThou, Million",
    "DrivHist": "driving history. Values: Zero, One, Many",
}


def pulisci_output(l: str) -> str:
    """Pulisce testo markdown/code-fence dall'output dell'LLM (invariante functionale)."""
    l = l.replace("\n", "")
    l = l.replace("python", "")
    l = l.replace("`", "")
    import re
    l = re.sub(r"\(node ([1-9][0-9]?)\s*\)", "", l)
    return l


# ---------------------------------------------------------------------------
# Helper interni: accesso per ETICHETTA, mai per intero
# ---------------------------------------------------------------------------
def _labels(bn, v):
    return list(bn.variable(v).labels())


def _p_state(bn, varname, state, evidence=None):
    """P(varname = state | evidence) calcolata per marginalizzazione ESATTA dal
    grafo `bn` (LazyPropagation). Indicizzazione per etichetta."""
    ie = gum.LazyPropagation(bn)
    if evidence:
        ie.setEvidence(evidence)
    ie.makeInference()
    post = ie.posterior(varname)
    labs = _labels(bn, varname)
    if state not in labs:
        raise KeyError(f"stato {state!r} non tra le etichette di {varname}: {labs}")
    return float(post[labs.index(state)])


def _p_do(graph, x, xval, child, yy, extra_evidence=None):
    """P(child = yy | do(x = xval), extra_evidence) calcolata ESATTAMENTE dal
    grafo originale: si rende x deterministica (CPT degenerata sull'etichetta
    xval, indicizzata PER ETICHETTA) e si propaga l'evidenza."""
    gb = gum.BayesNet(graph)
    cptx = gb.cpt(x)
    cptx.fillWith(0.0)
    cptx[{x: xval}] = 1.0          # etichetta, non intero
    ie = gum.LazyPropagation(gb)
    if extra_evidence:
        ie.setEvidence(extra_evidence)
    ie.makeInference()
    post = ie.posterior(child)
    labs = _labels(gb, child)
    return float(post[labs.index(yy)])


# ---------------------------------------------------------------------------
# g_bin: binarizzazione a RAMO UNICO
# ---------------------------------------------------------------------------
def _nox_weights(grafo, x, nox, evidence):
    """Pesi normalizzati w_s ∝ P(x=s | evidence) per s in nox, calcolati per
    marginalizzazione esatta dal grafo. Cella irraggiungibile (evidenza
    incompatibile o massa zero) -> pesi uniformi, con log INFO."""
    try:
        ie = gum.LazyPropagation(grafo)
        if evidence:
            ie.setEvidence(evidence)
        ie.makeInference()
        post_x = ie.posterior(x)
        lx = _labels(grafo, x)
        w = {s: float(post_x[lx.index(s)]) for s in nox}
    except gum.InvalidEvidence:
        logger.info("[g_bin] evidenza %r incompatibile per %s: uso pesi uniformi", evidence, x)
        return {s: 1.0 / len(nox) for s in nox}
    tot = sum(w.values())
    if tot <= 0.0:
        logger.info("[g_bin] massa nulla su nox per %s con evidenza %r: pesi uniformi", x, evidence)
        return {s: 1.0 / len(nox) for s in nox}
    return {s: w[s] / tot for s in nox}


def g_bin(grafo, x, xval, nox):
    """Binarizza la variabile `x` della rete `grafo`: stato "1" := x == xval,
    stato "0" := x in nox (= tutti gli altri stati). Ritorna una NUOVA rete;
    quella originale non viene modificata.

    Implementazione a ramo unico: nessuna diramazione sul numero di genitori
    (il difetto storico era nei rami dim==1/dim==2 che referenziavano nomi
    definiti solo nel ramo dim==3). Le CPT dei figli sono riscritte cella per
    cella sulle COMBINAZIONI COMPLETE dei genitori (itertools.product),
    verificando il ramo "1" contro la CPT originale e calcolando il ramo "0"
    per marginalizzazione esatta dal grafo.

    Richiede: xval ∈ labels(x), nox = labels(x) \\ {xval}.
    """
    labs_x = _labels(grafo, x)
    if xval not in labs_x:
        raise ValueError(f"g_bin: xval {xval!r} non tra le etichette di {x}: {labs_x}")
    missing = [s for s in nox if s not in labs_x]
    if missing:
        raise ValueError(f"g_bin: stati in nox non presenti in {x}: {missing}")

    new_bn = gum.BayesNet(grafo)                          # copia
    id_x = new_bn.idFromName(x)
    id_childx = list(new_bn.children(id_x))
    id_pax = list(new_bn.parents(id_x))
    pa_names = [new_bn.variable(p).name() for p in id_pax]

    new_bn.erase(x)
    new_bn.add(gum.LabelizedVariable(x, x, ["0", "1"]))   # etichette STRINGHE
    for i in id_childx:
        new_bn.addArc(x, new_bn.variable(i).name())
    for i in id_pax:
        new_bn.addArc(new_bn.variable(i).name(), x)

    # ---- CPT di x: P("1"|pa) = P(x=xval|pa);  P("0"|pa) = sum_{s in nox} P(x=s|pa)
    cptx_orig = grafo.cpt(x)
    for combo in itertools.product(*[_labels(grafo, v) for v in pa_names]):
        padict = dict(zip(pa_names, combo))
        new_bn.cpt(x)[{**padict, x: "1"}] = float(cptx_orig[{**padict, x: xval}])
        new_bn.cpt(x)[{**padict, x: "0"}] = sum(
            float(cptx_orig[{**padict, x: s}]) for s in nox
        )

    # ---- CPT dei figli: ramo unico su itertools.product di TUTTI i genitori
    for i in id_childx:
        child = new_bn.variable(i).name()
        parents_new = [new_bn.variable(p).name() for p in new_bn.parents(i)]
        other_parents = [v for v in parents_new if v != x]
        child_labels = _labels(grafo, child)
        cpt_child_orig = grafo.cpt(child)

        for combo in itertools.product(*[_labels(grafo, v) for v in other_parents]):
            opd = dict(zip(other_parents, combo))

            # pesi della miscela sul ramo "0": P(x=s | opd) rinormalizzati su nox.
            # Calcolati per marginalizzazione ESATTA dal grafo originale.
            w = _nox_weights(grafo, x, nox, opd)

            for yy in child_labels:
                # ramo "1": identico alla CPT originale in x=xval (verifica cella-per-cella)
                v1 = float(cpt_child_orig[{**opd, x: xval, child: yy}])
                # ramo "0": miscela esatta di P(child | do(x=s), opd) per s in nox
                v0 = sum(w[s] * _p_do(grafo, x, s, child, yy, opd) for s in nox)
                new_bn.cpt(child)[{**opd, x: "1", child: yy}] = v1
                new_bn.cpt(child)[{**opd, x: "0", child: yy}] = v0

    return new_bn


# ---------------------------------------------------------------------------
# cobound: bound controfattuali corretti
# ---------------------------------------------------------------------------
def cobound(y, yval, x, xval, data, graph):
    """Bound su P(Y=yval | do(X=xval)) dati i fatti osservati (approccio
    'causal effect bounds' su rete binarizzata, come nell'impianto originale).

    Differenze rispetto alla versione storica (MUDILAB/funtions.py):
      - nessun accesso nudo `data[[y,x]]` (KeyError se colonna assente);
      - Py: se la colonna y esiste in DATI.csv, Py e' empirica (N.yval/N) E la
        provenienza viene dichiarata; ALTRIMENTI Py e' calcolata DAL GRAFO per
        marginalizzazione esatta — MAI impostata a 0.0;
      - indicizzazione di impact[] e joint[] ESCLUSIVAMENTE per etichetta
        ("1"/"0"), mai per intero;
      - PYx/PYnox NON arrotondati prima di calcolare i bound; l'arrotondamento
        avviene solo nella stringa di output.

    Ritorna una dict (strutturato, testabile) invece di una stringa libera:
      {"lower": float, "upper": float, "Py": float, "Py_source": "DATI"|"GRAFO",
       "PYx": float, "PYnox": float, "message": str}
    """
    # --- validazione esplicita contro il grafo (unica fonte degli stati ammessi)
    y_vals = _labels(graph, y)
    x_vals = _labels(graph, x)
    if yval not in y_vals:
        raise ValueError(
            f"cobound: stato {yval!r} non ammesso per {y!r}. Stati ammessi: {y_vals}"
        )
    if xval not in x_vals:
        raise ValueError(
            f"cobound: stato {xval!r} non ammesso per {x!r}. Stati ammessi: {x_vals}"
        )

    nox = [s for s in x_vals if s != xval]
    noy = [s for s in y_vals if s != yval]

    bingraph = g_bin(graph, x, xval, nox)
    bingraph = g_bin(bingraph, y, yval, noy)

    mod = csl.CausalModel(gum.BayesNet(bingraph))

    # causalImpact sul grafo binarizzato: Y ha SOLO gli stati "0"/"1".
    # Indicizzazione PER ETICHETTA (non imp[1]).
    _, imp, _ = csl.causalImpact(mod, on=y, doing=x, values={x: "1"})
    PYx = float(imp[{y: "1"}])
    _, imp2, _ = csl.causalImpact(mod, on=y, doing=x, values={x: "0"})
    PYnox = float(imp2[{y: "1"}])

    # --- Py: mai 0.0 di default. DATI se la colonna c'e', altrimenti GRAFO.
    if y in getattr(data, "columns", []):
        ny = int((data[y].astype(str) == str(yval)).sum())
        Py = ny / len(data)
        Py_source = "DATI"
    else:
        Py = _p_state(graph, y, yval)   # marginalizzazione esatta dal grafo
        Py_source = "GRAFO"
        logger.info(
            "[cobound] colonna %r assente in DATI.csv: Py=%.6f calcolata dal GRAFO "
            "(provenienza dichiarata, nessun fallback a 0.0)", y, Py,
        )

    low_B = max(0.0, PYx - PYnox, Py - PYnox, PYx - Py)

    ie = gum.LazyPropagation(bingraph)
    ie.makeInference()
    joint = ie.jointPosterior({x, y})
    # indicizzazione per ETICHETTA
    p_xy   = float(joint[{x: "1", y: "1"}])
    p_noxy = float(joint[{x: "0", y: "0"}])
    Pxny   = float(joint[{x: "1", y: "0"}])
    Pnxy   = float(joint[{x: "0", y: "1"}])

    upper_B = min(PYx, 1.0 - PYnox, p_xy + p_noxy, PYx - PYnox + Pxny + Pnxy)
    upper_B = max(upper_B, 0.0)
    low_B = min(low_B, 1.0)
    if low_B > upper_B:  # guard numerica anti round-off
        mid = 0.5 * (low_B + upper_B)
        low_B = upper_B = mid

    msg = (
        f"The answer is between {round(low_B, 4)} and {round(upper_B, 4)} "
        f"(Py source: {Py_source})"
    )
    return {
        "lower": low_B,
        "upper": upper_B,
        "Py": Py,
        "Py_source": Py_source,
        "PYx": PYx,
        "PYnox": PYnox,
        "message": msg,
    }


# ---------------------------------------------------------------------------
# legacy helper (non usata piu' da cobound/g_bin; mantenuta per compatibilita'
# con notebook precedenti). complex_prob storica dipendeva da colonne di DATI
# potenzialmente assenti: ora ritorna nan con log esplicito invece di crashare.
# ---------------------------------------------------------------------------
def complex_prob(df, grafo, y, yval, x, nox, j=None, jval=None, z=None, zval=None):
    """P(Y=yval | X in nox, evidenze) con mistura peso*valore. Versione robusta:
    colonne mancanti in df => fallback sul grafo con log INFO (niente KeyError)."""
    ie = gum.LazyPropagation(grafo)
    ev = {}
    if j is not None and jval is not None:
        ev[j] = jval
    if z is not None and zval is not None:
        ev[z] = zval
    if ev:
        ie.setEvidence(ev)
    ie.makeInference()
    labels = _labels(grafo, x)
    den, num = 0.0, 0.0
    for s in nox:
        wx = float(ie.posterior(x)[labels.index(s)])
        den += wx
        if y in df.columns and all(c in df.columns for c in ev):
            mask = (df[x] == s)
            for k, v in ev.items():
                mask &= (df[k] == v)
            sub = df[mask]
            n1 = float((sub[y] == yval).mean()) if len(sub) else float("nan")
            if n1 != n1:  # nan -> fallback grafo
                n1 = _p_do(grafo, x, s, y, yval, ev or None)
        else:
            n1 = _p_do(grafo, x, s, y, yval, ev or None)
            logger.info("[complex_prob] colonne mancanti in DATI: uso grafo per P(%s=%s|do(%s=%s))", y, yval, x, s)
        num += n1 * wx
    return num / den if den > 0 else float("nan")

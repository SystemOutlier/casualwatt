# -*- coding: utf-8 -*-
"""
agents.py — definizione dei tre agenti (traduttore, classificatore, esecutore
causale) sull'architettura DATA dalla relatrice (MUDILAB/agents.py).

VINCOLI RISPETTATI:
  - separazione in agenti: traduttore (To_Math), classificatore, esecutore
    causale (Causal_Relator) — invariata;
  - LLM locale via Ollama endpoint OpenAI-compatibile /v1 (Via B: l'orchestratore
    Python chiama i tool; il tool-calling nativo dell'LLM NON e' usato per
    l'esecuzione — misura: 0 run validi su 15 con Via A);
  - decodifica a temperatura 0 (misura: a temperatura default il dizionario
    cambia 1 volta su 3);
  - modello 8B per traduttore/classificatore (misure: modelli <3B falliscono la
    classificazione). NOTA: la scelta Qwen-vs-Llama NON e' benchmarkata sulle 9
    query del test-set: qui il nome del modello e' CONFIGURAZIONE DI DEFAULT,
    non verdetto sperimentale.

LE ETICHETTE CAUSALI NON SONO PIU' DEFINITE QUI: vengono importate da labels.py
(unica fonte). Il prompt del classificatore e' generato da CANONICAL_LABELS.

Il modulo richiede `agent_framework` (o autogen) installato; in ambiente di
test puro (solo pyAgrum) le costanti di prompt sono comunque ispezionabili e
gli agenti vengono creati solo se il framework e' disponibile.
"""

import os

from labels import CANONICAL_LABELS, label_definitions_block  # UNICA FONTE etichette

OLLAMA_BASE_URL = os.getenv("OLLAMA_BASE_URL", "http://localhost:11434/v1")
MODEL_MAIN = os.getenv("CAUSAL_MODEL_MAIN", "qwen2.5:7b")   # default, NON benchmark
MODEL_EXEC = os.getenv("CAUSAL_MODEL_EXEC", "qwen2.5:7b")   # opz. 1B (ibrido, misurato: dimezza energia)
TEMPERATURE = 0.0  # SCELTA MISURATA: temperatura 0, non negoziabile nel presente setup

# ---------------------------------------------------------------------------
# Prompt del classificatore — costruito dalle etichette canoniche di labels.py.
# Se un modello produce un'etichetta fuori da questo insieme, canonical_label()
# (in tools.py) FALLISCE in modo esplicito: nessun ramo silenzioso.
# ---------------------------------------------------------------------------
label_inst = (
    "You are an expert in causal inference. Classify the user's task into "
    "EXACTLY ONE of these four labels: " + ", ".join(sorted(CANONICAL_LABELS)) + ".\n\n"
    "Definitions:\n" + label_definitions_block() + "\n\n"
    "Disambiguation rules:\n"
    "- If the question describes something actively changed/forced/set, choose intervention, "
    "not posterior.\n"
    "- If the question refers to a hypothetical past ('had X been different', 'if it had...'), "
    "choose counterfactual, not intervention.\n"
    "- If the question asks only whether two facts can hold together, not their probability, "
    "choose coherence.\n\n"
    "Output format: respond with ONLY the label, lowercase, no punctuation, no explanation.\n\n"
    "Examples:\n"
    "User: 'If I observe fever, what is the probability of infection?'\nAssistant: posterior\n\n"
    "User: 'If we force the patient to take the drug, what is the probability of recovery?'\n"
    "Assistant: intervention\n\n"
    "User: 'Is it possible for someone to have a fever but no infection?'\nAssistant: coherence\n\n"
    "User: 'Given that the patient did not take the drug and did not recover, what is the "
    "probability they would have recovered had they taken it?'\nAssistant: counterfactual"
)

translator_inst = (
    "You must rewrite the user's query as a structured dictionary with exactly two keys: "
    "'input' (evidence/known facts) and 'output' (target variable to infer).\n\n"
    "Allowed variable names and values come from the insurance network; use EXACT state "
    "labels (e.g. 'TwentyThou', NOT 'Twenty Thousand'). Do NOT expand or rename values: "
    "an invalid value will be REJECTED by the executor, not corrected.\n\n"
    "Rules for 'output': exactly ONE key: the variable the user wants to infer; its value "
    "is the specific state mentioned, or 'Not necessary'.\n"
    "Rules for 'input': every other variable mentioned in the task, with its state or "
    "'Not necessary'. Do not invent variables.\n\n"
    "Output format: return ONLY the final dictionary as valid strict JSON (double quotes), "
    "no explanation, no markdown fences."
)

causal_prompt = (
    "You are an expert in causal inference. The numerical computation is performed by the "
    "Python executor (tool cau_inference) with exact inference on the Bayesian network; you "
    "must NEVER compute or guess numbers yourself.\n"
    "Procedure:\n"
    "1. Call cau_inference passing the label and the JSON dictionary EXACTLY as given. Do "
    "not modify, rename, or drop any key/value.\n"
    "2. If the tool returns an error (invalid label, invalid value, non-identifiable query), "
    "report the error explicitly. Never substitute a plausible number.\n"
    "Final answer format:\n"
    "1. State the numerical result returned by cau_inference.\n"
    "2. Give a short causal explanation (2-4 sentences)."
)

# ---------------------------------------------------------------------------
# Istanze degli agenti (solo se il framework agentico e' installato).
# L'orchestrazione effettiva usata nei test e' Via B: e' il notebook/script
# Python che chiama sequenzialmente i tre componenti, non il tool-calling
# nativo del modello.
# ---------------------------------------------------------------------------
classificator = translator = causal_A = None

def build_agents():
    """Crea (e ritorna) i tre agenti sul client OpenAI-compatibile di Ollama.
    Richiede: pip install autogen-agentchat autogen-ext[openai] (o agent_framework)."""
    global classificator, translator, causal_A
    from autogen_agentchat.agents import AssistantAgent           # noqa: WPS433
    from autogen_ext.models.openai import OpenAIChatCompletionClient
    from tools import cau_inference, read_graph

    def _client(model):
        return OpenAIChatCompletionClient(
            model=model,
            api_key="ollama",
            base_url=OLLAMA_BASE_URL,
            temperature=TEMPERATURE,          # SCELTA MISURATA: 0
            model_info={
                "vision": False,
                "function_calling": True,
                "json_output": True,
                "structured_output": True,
                "family": None,               # NON dichiarare famiglia senza benchmark
            },
        )

    classificator = AssistantAgent(name="Classificator",
                                   model_client=_client(MODEL_MAIN),
                                   system_message=label_inst)
    translator = AssistantAgent(name="To_Math",
                                model_client=_client(MODEL_MAIN),
                                system_message=translator_inst)
    causal_A = AssistantAgent(name="Causal_Relator",
                              model_client=_client(MODEL_EXEC),
                              tools=[cau_inference, read_graph],
                              system_message=causal_prompt)
    return classificator, translator, causal_A

# consegna/ — versione pulita del sistema multi-agente per inferenza causale

Rete bayesiana: **Insurance** (27 nodi, 52 archi, `insurance_grafo.bif`).
Calcolo: **pyAgrum** (inferenza esatta). Semantica: **LLM locale via Ollama** (`/v1`).
Nessuna API cloud. Esecuzione puramente locale.

---

## 1. Cosa è DATO (architettura della relatrice — NON modificata)

| Elemento | Stato |
|---|---|
| Separazione in 3 agenti: traduttore (`To_Math`), classificatore, esecutore causale (`Causal_Relator`) | invariata (definizioni prompt in `agents.py`, esecuzione in `tools.py`) |
| LLM locale per la semantica + pyAgrum per il calcolo esatto | invariato |
| Rete Insurance 27×52 | verificata a runtime nel notebook: `27 nodi, 52 archi` |
| Orchestrazione "Via B": è il codice Python che chiama i tool, non il tool-calling nativo dell'LLM | preservata (misura precedente: Via A = 0 run validi su 15) |

I file originali restano intatti in `../MUDILAB/`; le copie di lavoro sperimentali in `../mudilabQ/`.
Questa cartella `consegna/` è la versione pulita; **non** sostituisce gli originali.

## 2. Cosa è SCELTA SPERIMENTALE (misurata, ma scelta — da confermare con la relatrice)

| Scelta | Valore usato | Base misurata |
|---|---|---|
| Orchestrazione | Via B (Python chiama i tool) | Via A: 0 run validi su 15 |
| Modello per passo | 8B per traduttore/classificatore; 1B opzionale per l'esecutore | modelli <3B falliscono la classificazione; ibrido 8B+1B dimezza l'energia |
| Decodifica | temperatura 0 | a temperatura default il dizionario cambia 1 volta su 3 |

**NON implementate** (perché non misurate, sono opzioni da proporre, non decisioni):
retry automatico, constrained decoding / JSON schema, endpoint `/api/chat`,
modelli proprietari. Il nome del modello in `agents.py` è un **default di
configurazione**, non un verdetto: Qwen vs Llama **non** è benchmarkato sulle 9 query.

## 3. Cosa è stato CORRETTO qui (difetti verificati alla fonte sui file di lavoro)

Tutti i riferimenti sono a `MUDILAB/funtions.py` e `mudilabQ/tools.py`, ispezionati riga per riga.

1. **`cobound()` (ramo controfattuale)** — `funtions.py`:
   - rimosso laccesso nudo `data[[y,x]]` (KeyError se colonna assente, es. DrivQuality nella copia MUDILAB di DATI.csv);
   - `Py` mai più posto a `0.0` per colonne assenti: viene calcolato **dal grafo** per marginalizzazione esatta e la provenienza è dichiarata nel risultato (`Py_source: "DATI"|"GRAFO"`);
   - indicizzazione di `impact[]`, `joint[]` e dei valori `do=` **per etichetta stringa** ("1"/"0"), mai per intero (in pyAgrum 3.x l'intero è indice di stato: `1` sulla variabile binaria etichettata `["0","1"]` significava silenziosamente il ramo opposto);
   - nessun `round(...,3)` di `PYx`/`PYnox` prima del calcolo dei bound; arrotondamento solo in presentazione.
2. **Sanitizer muto** — rimosso `sanitize_llm_output()`. Al suo posto `validate_features()`: se una chiave o uno stato non sono negli stati ammessi **del grafo**, la chiamata fallisce con errore esplicito che cita chiave e valore. Nessuna riscrittura (es. `HundredThousand → HundredThou`) avviene più in silenzio. Non esiste alcuna normalizzazione implicita; se in futuro se ne aggiunge una, dovrà essere loggata (il meccanismo di log per gli alias etichette in `labels.py` mostra il pattern richiesto).
3. **`eval()` su testo dell'LLM** — rimosso. `parse_features()` usa `json.loads()` con eccezioni gestite esplicitamente (`JSONFeaturesError`). Test nel notebook: payload stile-eval viene rifiutato.
4. **Etichette** — definite in **un solo punto**: `labels.py` (`CANONICAL_LABELS`). `agents.py` genera il prompt del classificatore da lì; `tools.py` importa le costanti canoniche da lì. Etichetta sconosciuta → `UnknownLabelError` (fallimento esplicito). Alias storici (`backward_reasoning`, typo `conterfactual`) sono normalizzati **solo** in `labels.py` e **loggati**.
5. **`g_bin()`** — riscritta a **ramo unico** con `itertools.product` su tutte le combinazioni dei genitori: niente più rami `dim==1/2/3` con nomi non definiti (era misurato il crash su `g_bin(g,"Accident",...)`). Verifica cella-per-cella del ramo "1" contro la CPT originale: **76/76 celle identiche** (ricalcolata a runtime nel notebook, non hardcodata).

## 4. Cosa è MISURATO ora, in questa cartella (riproducibile eseguendo `FINAL_test.ipynb`)

- Grafo caricato: 27 nodi, 52 archi ✔ (stampa a runtime).
- `g_bin("Accident")`: nessun crash; 76/76 celle ramo "1" = CPT originale; 38/38 righe CPT normalizzate.
- `cobound(DrivQuality,...)` con colonna assente: nessun KeyError, `Py=0.3714` dal GRAFO, intervallo `[0.0000, 0.3714]` non collassato artificialmente.
- Metrica N (±0.01 **assoluto**, reference ricalcolati dal grafo a runtime):
  - sottoinsieme **confermato** (CP1, CP3): 2/2 dentro tolleranza;
  - sottoinsieme **da confermare** (CP2, IN1, IN2, IN3, CO1, CO2, CO3): i numeri confrontano motore vs reference **sullo stesso dizionario ground-truth**; la conferma della *mappatura* query→dizionario resta pendente.
- Errori espliciti funzionanti: JSON invalido rifiutato, stato inesistente rifiutato con messaggio, etichetta sconosciuta rifiutata, alias loggato.

## 5. Cosa **NON** è misurato / limitazioni note (onestà obbligatoria)

- **6 query su 9 hanno mappatura non confermata dalla relatrice** (CP2, IN1, IN2, CO1, CO2, CO3 marcate `review` in `ground_truth.csv`). I risultati vanno letti separatamente per i due sottoinsiemi, come fa il notebook.
- **Il ramo controfattuale NON è validato**: `cobound()` gira senza crash e dichiara la provenienza di ogni quantità, ma la formula di riferimento dei bound e la semantica della miscela sul ramo "0" di `g_bin` (scelta dichiarata nei docstring) devono essere confermate con la relatrice. **Nessuna dichiarazione di accuratezza numerica controfattuale è fatta o accettabile.**
- **Metriche D e L (dizionario ed etichetta prodotti dall'LLM) NON misurabili su questa macchina** (Ollama assente): il notebook le riporta come `NOT-MEASURED` e fornisce la cella pronta per misurarle sul PC con i modelli.
- La soglia `THRESHOLD=0.60` del verdetto *coherence* è una scelta ereditata/sperimentale **non confermata**: dichiarata in `tools.py`; il verdetto binario dipende da essa.
- Nessun confronto Qwen-vs-Llama dichiarato (servirebbe un benchmark controllato sulle stesse 9 query).
- Non dichiarare mai: "accuratezza >99%", "tutti e quattro i livelli validati", "matematicamente infallibile", "zero crash", "graceful degradation" per casi in cui il sistema calcola una domanda diversa da quella posta.

## 6. File

```
consegna/
├── labels.py          # unica fonte delle etichette causali (+ canonical_label, log alias)
├── funtions.py        # g_bin a ramo unico, cobound corretto (Py dal grafo, indici per etichetta)
├── tools.py           # parse_features (json.loads), validate_features (no sanitizer), cau_inference
├── agents.py          # prompt degli agenti costruiti da labels.py; build_agents() con autogen/Ollama
├── FINAL_test.ipynb   # test separati: mappatura confermata vs da confermare; 3 metriche separate
├── README.md          # questo file
├── insurance_grafo.bif  # copiato identico da MUDILAB/ (verificato: hash uguale)
└── DATI.csv             # copiato identico da MUDILAB/ (verificato: hash uguale)
```

Nota su `DATI.csv`: la copia in `MUDILAB/` contiene anche la colonna `DrivQuality`
(verificato: 30 colonne incluso indice); la copia in `mudilabQ/` no (29 colonne).
Il codice **non dipende** dalla presenza di alcuna colonna: se manca, `Py` arriva
dal grafo con provenienza dichiarata.

## 7. Come eseguire i test

```bash
cd consegna
jupyter nbconvert --to notebook --execute FINAL_test.ipynb   # senza LLM: N + check difetti
# con Ollama attivo (localhost:11434) la cella 2b misura anche D e L
```

Dipendenze: `pyAgrum>=3.x` (incluso modulo `causal`), `pandas`, `jupyter`;
per la parte LLM: `ollama` in locale + `autogen-agentchat`/`autogen-ext[openai]`.

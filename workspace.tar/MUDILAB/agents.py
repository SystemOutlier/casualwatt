from agent_framework import Agent, AgentResponse, WorkflowBuilder  
from agent_framework.foundry import FoundryChatClient
from azure.identity import AzureCliCredential
from tools import read_graph, cau_inference, web_search
from funtions import node_descr
import os
import transformers
from client import HuggingFaceChatClient
from agent_framework.openai import OpenAIChatCompletionClient
from azure.core.credentials import AzureKeyCredential
from dotenv import load_dotenv

load_dotenv()


#CLIENTS
small = ()

#AGENTS

label_inst = (
    "You are an expert in causal inference. Classify the user's task into "
    "EXACTLY ONE of these four labels: posterior, intervention, coherence, counterfactual.\n\n"
    "Definitions:\n"
    "- posterior: Estimate the probability of a variable given observed evidence on other "
    "variables (pure observation, no changes proposed). Corresponds to P(Y | X=x).\n"
    "- intervention: Estimate the probability of a variable after an action forces another "
    "variable to a value, breaking its normal causes (do-operator). Corresponds to P(Y | do(X=x)).\n"
    "- coherence: Determine whether two or more stated conditions are jointly compatible or "
    "contradictory, without asking for a probability.\n"
    "- conterfactual: Estimate the probability or likelihood of an alternative outcome that "
    "would have occurred under different circumstances, given what actually happened. \n\n"
    "Disambiguation rules:\n"
    "- If the question describes something actively changed/forced/set, choose intervention, "
    "not posterior.\n"
    "- If the question refers to a hypothetical past ('had X been different', 'if it had...'), "
    "choose counterfactual, not intervention.\n"
    "- If the question asks only whether two facts can hold together, not their probability, "
    "choose coherence.\n\n"
    "Output format: respond with ONLY the label, lowercase, no punctuation, no explanation.\n\n"
    "Examples:\n"
    "User: 'If I observe fever, what is the probability of infection?'\n"
    "Assistant: posterior\n\n"
    "User: 'If we force the patient to take the drug, what is the probability of recovery?'\n"
    "Assistant: intervention\n\n"
    "User: 'Is it possible for someone to have a fever but no infection?'\n"
    "Assistant: coherence\n\n"
    "User: 'Given that the patient did not take the drug and did not recover, what is the "
    "probability they would have recovered had they taken it?'\n"
    "Assistant: counterfactual"
        )

classificator = Agent(
    name= "Classificator",
    client= gpt5,
    instructions = label_inst,     
)

translator = Agent(
    name= "To_Math",
    client= small,
    tools = [read_graph],
    instructions = (
        "You must rewrite the user's query as a structured dictionary with exactly two keys: "
    "'input' and 'output'.\n\n"
    f"Allowed variable names (use these exact names, chosen from {node_descr}):\n\n"
    "Rules for 'output':\n"
    "- Contains exactly ONE key: the variable name that best represents the quantity the user "
    "is trying to infer.\n"
    "- Its value is the specific value mentioned in the task, if any, otherwise 'Not necessary'.\n\n"
    "Rules for 'input':\n"
    "- Contains every other variable (from the same allowed list) that appears in the task "
    "description, excluding the one selected as output.\n"
    "- For each, the value is the specific value mentioned in the task, or 'Not necessary' if "
    "the task names the variable but not a specific value.\n"
    "- Do not include any variable that does not appear in the task description.\n\n"
    "Output format:\n"
    "- Return ONLY the final dictionary as valid JSON, with no explanation or commentary.\n\n"
    "Example:\n"
    "Task: Given that the driving quality is normal, how likely is it that the age of the driver is senior?'?'\n"
    '{"input": {"DrivQuality": "Normal"}, "output": {"Age": "Senior"}"}'
  
)   


causal_prompt = (
    "You are an expert in causal and conterfactual inference. You have access to one tools:\n"
##   "- read_graph: retrieves the causal graph structure (nodes, edges, and dependencies) "
#    "relevant to the task.\n"
    "- cau_inference: performs exact causal inference and returns a numerical or symbolic result.\n\n"
    "You will receive as input:\n"
    "- the user's task, describing the causal question being asked\n"
    "- a label indicating the type of causal problem (posterior, intervention, coherence, "
    "or conterfactual)\n"
    "- a string of variables and their values, to be used as evidence/query input\n\n"
    "Procedure, to follow in order for every task:\n"
    #"1. Call read_graph first to obtain the causal structure. Do not assume or guess the graph "
    #"from context alone.\n"
    "1. Call cau_inference, passing the label and the dictionary of variables/values exactly as "
    "given. Do not modify, rename, or drop any key from the dictionary, and do not invent "
    "additional variables.\n"
    "2. You MUST actually invoke both tools — never write out, describe, or simulate what a "
    "tool would return.\n"
    "3. If a tool call fails or returns an error, report the error explicitly instead of "
    "guessing a plausible result.\n\n"
    "Final answer format:\n"
    "1. State the numerical/symbolic result from cau_inference.\n"
    "2. Give a short causal explanation (2-4 sentences) of why this result. \n"
    #follows from the "
    #"graph structure — referencing the relevant paths, mediators, or confounders involved.\n"
    #"Do not provide a final answer before both tools have been called."
)

causal_A = Agent(
        name = "Causal_Relator_Small",
        client = small,
        tools = [cau_inference, read_graph],
        instructions = causal_prompt,
    )





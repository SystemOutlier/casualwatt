# CasualWatt Energy Benchmark

Framework di benchmark energetico per LLM locali (Ollama) e cloud, con interfaccia grafica Tkinter. Misura l'energia del package CPU dal contatore cumulativo EMI del processore Intel (metodo principale su Windows, `emi-counter`: ioctl via ctypes, nessuna integrazione, nessuna elevazione), senza secondo percorso su Windows — LibreHardwareMonitor è uscito dall'implementazione il 27/10/2026 (D18) — e con RAPL su Linux; misura la GPU NVIDIA via NVML, stima l'energia incrementale attribuibile al processo Ollama (baseline idle calibrata + ripartizione del tempo CPU busy), l'energia di rete dal traffico NIC e l'energia dell'inferenza cloud tramite EcoLogits. Le componenti sono riportate separatamente (local / network / cloud), con metodo e confine di misura espliciti in ogni riga CSV.

Target principale: **Windows 11**, Python 3.14 x64. L'app gira **senza privilegi amministrativi**: il contatore EMI si apre a privilegi standard e non esiste più un percorso che richieda l'elevazione (UAC).

**Qual è il documento che serve.** Il metodo vigente, con le decisioni congelate P1-P4 e il formulario F.0-F.17, è in `experiment_results/protocollo_v4_20261024.md`; le regole vincolanti per chi lavora nel repository sono in `AGENTS.md`. `RELAZIONE.md` **non** è la relazione di questo framework: è la verifica del 15/10/2026 del tool monofile legacy `consumi_ollama.py`, che stima la potenza dal TDP e sta fuori dal percorso di misura (`AGENTS.md:135-136`, `AGENTS.md:318-320`).

## Caratteristiche

- GUI a 3 pannelli: selezione modelli (locali/cloud), esecuzione benchmark, risultati + grafici; sezioni Log e Risultati ridimensionabili (PanedWindow).
- Lettura dinamica dei modelli Ollama (`GET /api/tags`) e cloud (Groq, OpenRouter, Google Gemini, OpenAI, Anthropic) con badge `[Gratuito]`.
- Configurazione chiavi API dalla GUI (combobox provider, campi oscurati, persistenza in `.casualwatt_keys.json`).
- Calibrazione idle empirica (mediana di 3 finestre >=30 s sul sensore `CPU Package`).
- Sorgente test universale: dataset CSV esterno (con ground truth opzionale) o prompt manuali a blocchi dinamici.
- Valutazione: similarità semantica (sentence-transformers multilingue) vs ground truth, estrazione triple causali con F1, LLM-as-a-Judge via Ollama; regime senza GT etichettato esplicitamente.
- Export CSV dettagliato (~100 colonne): energia, token, latenza, emissioni CO2, metodo e boundary di misura per riga.

## Installazione (Windows 11)

```powershell
py -m pip install -r cwEnergyModular/requirements.txt        # nucleo: gira anche senza elevazione
py -m pip install -r cwEnergyModular/requirements-lhm.txt    # solo per gli harness storici LHM (non per l'app)
```

La prima riga basta per misurare: il metodo principale `emi-counter` usa `ctypes` dalla libreria standard. La seconda aggiunge `pythonnet`, che dal 27/10/2026 **non serve all'applicazione**: nessun modulo di `cwEnergyModular` fa più `import clr` (verificato con un grep su tutti i `.py`), e `energy/energy_session.py` e `diagnostics.py` — che prima lo importavano — sono stati riscritti su EMI e RAPL. `requirements-lhm.txt` resta solo per gli harness tracciati alla radice (`experiment_validate_lhm.py`, `four_way_test.py`, ...) che rigenerano gli artefatti LHM citati in `experiment_results/` e nella tesi. `wmi` e `pywin32`, che una versione di questa istruzione elencava, non sono importati da nessun file di `cwEnergyModular` (grep su `import wmi` e `win32api|win32com|win32file`: nessun risultato); l'unico consumatore nel repository è lo script legacy `consumi_ollama.py`, che dichiara la propria riga di installazione. Lo stesso vale per `codecarbon`: non è usato dall'applicazione, l'unico import è nell'harness una tantum `four_way_test.py:259`, dove è dentro un `try/except` che registra una nota e degrada a "sorgente non disponibile" se il pacchetto manca; le righe in `experiment_results/codecarbon_four_way/` vengono da lì, non dalla misura di CasualWatt.

Le DLL di LibreHardwareMonitor (`LibreHardwareMonitorLib.dll`, `HidSharp.dll`, `Microsoft.Win32.TaskScheduler.dll`) restano archiviate in `cwEnergyModular/LibreHardwareMonitorLib/LibreHardwareMonitor/` per quegli harness storici: non fanno parte del percorso di misura. `LibreHardwareMonitorLib.dll` è distribuita senza modifiche sotto **MPL-2.0**: il testo integrale della licenza è allegato in `cwEnergyModular/LibreHardwareMonitorLib/LibreHardwareMonitor/MPL-2.0.txt` ( preso da mozilla.org, verificato il 23/10 sul `LICENSE` upstream), con gli avvisi third-party in `THIRD-PARTY-NOTICES.md` nella stessa cartella; per `HidSharp.dll` e `Microsoft.Win32.TaskScheduler.dll` la licenza va ri-verificata presso i rispettivi upstream prima di qualsiasi ridistribuzione.

## Avvio

Con doppio clic su `cwEnergyModular/avvia_casualwatt.bat` (nessuna elevazione: il launcher non chiede UAC), oppure manualmente:

```powershell
cd cwEnergyModular
py main.py            # GUI (senza amministratore)
py diagnostics.py     # report del canale EMI/RAPL e sonda PMI/WMI
py test_calibrazione.py  # verifica rapida calibrazione idle
py main.py --selftest    # test logici senza hardware
```

## Variabili d'ambiente / .env

| Variabile | Descrizione |
|---|---|
| `GROQ_API_KEY`, `OPENROUTER_API_KEY`, `GOOGLE_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY` | chiavi provider cloud |
| `ELECTRICITY_MAPS_API_TOKEN` | intensità carbonio live |
| `OLLAMA_HOST` | default `http://localhost:11434` |
| `CW_SEMANTIC_THRESHOLD` | soglia is_correct (default 0.75) |
| `CW_EMBED_MODEL_DIR` | cache offline modello embeddings |
| `CW_IDLE_WINDOW_S` | finestra calibrazione idle |
| `CW_JUDGE_MODEL` | modello Ollama per LLM Judge |

## Struttura

```
cwEnergyModular/
├── main.py                 # entry point GUI / CLI
├── benchmark_unified.py    # orchestrazione benchmark
├── evaluator.py            # valutazione (GT semantica, triple causali, judge)
├── cloud_estimator.py      # fetch modelli + stima EcoLogits
├── casualwatt_csv_export.py# export CSV
├── gui/                    # pannelli Tkinter
└── energy/                 # sessioni energetiche (EMI/RAPL/NVML/rete/carbonio)
```

## Metodologia energetica

```
E_attiva = max(0, E_package − P_idle·Δt)          [Δ contatore cumulativo EMI, bordi dal buffer @0,05s; senza il device il canale e' unavailable, mai un secondo percorso]
E_Ollama = E_attiva · Δt_cpu_Ollama / Δt_cpu_busy [cpu-time-share attribution]
end_to_end = local + network + cloud              [baseline idle ESCLUSA]
```

La `baseline_energy_j` è salvata separatamente e non viene mai attribuita al modello. L'energia della chiamata LLM Judge è contabilmente separata (`judge_energy_j`).

## Note

- Su Linux la misurazione locale usa il contatore RAPL (`/sys/class/powercap`, backend implementato; validazione di scala ancora aperta); su macOS è disabilitata con messaggio esplicito (future work). GUI, Ollama, cloud, valutazioni e CSV restano utilizzabili ovunque.
- Progetto di ricerca (tesi): metriche e confini di misura sono dichiarati riga per riga nel CSV.

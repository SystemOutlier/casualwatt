# -*- coding: utf-8 -*-
"""
gui/benchmark_panel.py — Pannello 2: esecuzione benchmark (sez. 4.2).

Contiene: Avvia/Ferma, barra di avanzamento, area log testuale, campi
numero prompt / temperatura / timeout, pulsante "Calibra idle" e campo di
lettura della potenza idle calibrata. Il lavoro pesante gira in un thread;
la comunicazione con Tk avviene solo via ``after()``.

Sorgente dei Test (Modalita' di Input Universale): radiobutton con due
opzioni dinamiche — A) Dataset Esterno CSV (pulsante "Sfoglia..." per file
generati da tool esterni tipo MUDILab, colonna prompt + eventuale
ground_truth/expected_result) oppure B) Prompt Manuale: blocchi dinamici
numerati ("Test 1", "Test 2", ...) in un'area scrollabile, ognuno con due
campi espliciti Domanda + Risposta Attesa (opzionale), "+ Aggiungi Prompt"
e "✕" per rimuovere. I test NON sono mai hardcodati nel framework.
"""
from __future__ import annotations

import queue
import threading
import time
import tkinter as tk
from tkinter import ttk
from typing import List, Optional, Tuple


class BenchmarkPanel(ttk.Frame):
    """Pannello 'Esecuzione benchmark' + Log, con sotto-pannelli regolabili.

    Il log e' separato dal resto del pannello tramite un PanedWindow
    verticale: l'utente puo' trascinare il divisore per espandere o ridurre
    la console senza perderla di vista (richiesta UX).
    """

    def __init__(self, master, get_selections=None, **kw):
        super().__init__(master, **kw)
        self.get_selections = get_selections or (lambda: ([], []))
        self._stop_event = threading.Event()
        self._worker = None
        self._q: queue.Queue = queue.Queue()
        self._running = False

        # sotto-pannello superiore: controlli di esecuzione
        # sotto-pannello inferiore: console log (regolabile col drag)
        # NOTE (Tk 8.6 / Python Windows): le pane di ttk::panedwindow
        # ammettono SOLO -weight; "paneconfigure" e "-minsize" NON esistono
        # -> TclError. Il vincolo minimo viene quindi applicato con un
        # divisorio custom trascinabile (frame-stretta con bind B1-Motion)
        # che CLAMP-A la posizione alle altezze minime: nessuna sezione puo'
        # sparire o schiacciare l'altra. Nessun comando ttk::panedwindow
        # "pane" invocato: layout identico su Tcl/Tk 8.6 e 8.7+.
        MIN_TOP_H, MIN_LOG_H = 200, 72

        inner = tk.Frame(self)
        inner.pack(fill="both", expand=True)
        inner.columnconfigure(0, weight=1)
        # Il Log ha peso 0 + minsize: la griglia gli riserva SEMPRE un'altezza
        # fissa (>= 108px) qualunque sia lo spazio disponibile; i controlli in
        # alto si comprimono per primi. Il drag regola solo la parte alta.
        inner.rowconfigure(0, weight=1, minsize=150)
        inner.rowconfigure(1, weight=0)
        inner.rowconfigure(2, weight=0, minsize=108)

        # FIX: top e log_frame devono essere figli di inner, NON di self.
        # Usare grid(..., in_=inner) su widget creati con parent self fa
        # sparire i widget (pitfall Tkinter: reparenting via in_ non funziona
        # in modo affidabile su tutte le piattaforme).
        top = ttk.LabelFrame(inner, text="Esecuzione benchmark")
        log_frame = ttk.LabelFrame(inner, text="Log / Console")
        sash_log = tk.Frame(inner, height=6, bd=1, relief="raised",
                            background="#d8d8d8")
        try:
            sash_log.configure(cursor="sb_vdouble_arrow")
        except Exception:
            pass
        top.grid(row=0, column=0, sticky="nsew")
        sash_log.grid(row=1, column=0, sticky="ew")
        log_frame.grid(row=2, column=0, sticky="nsew")

        # drag: regola solo il minsize della riga alta; la riga log resta
        # weight=0 -> mantiene sempre il suo spazio naturale (>=90px)
        def _apply(pos_y):
            try:
                h_top = top.winfo_height()
                h_log = log_frame.winfo_height()
                span = max(h_top + h_log, MIN_TOP_H + MIN_LOG_H, 1)
                new_top = max(MIN_TOP_H, min(span - MIN_LOG_H, pos_y))
                inner.rowconfigure(0, weight=1, minsize=int(new_top))
            except Exception:
                pass
        _st = {"y0": None}
        def _press(e): _st["y0"] = e.y_root
        def _drag(e):
            if _st["y0"] is not None:
                _apply(top.winfo_height() + (e.y_root - _st["y0"]))
        def _rel(_e): _st["y0"] = None
        sash_log.bind("<ButtonPress-1>", _press)
        sash_log.bind("<B1-Motion>", _drag)
        sash_log.bind("<ButtonRelease-1>", _rel)

        self.pane_log = inner          # retro-compatibilita' (riferimenti)
        self._log_children = {"top": top, "log": log_frame}

        # ------------------------- parametri ---------------------------------
        params = ttk.Frame(top)
        params.pack(fill="x", padx=6, pady=4)

        ttk.Label(params, text="Numero prompt:").grid(row=0, column=0, sticky="w")
        self.var_num_prompts = tk.IntVar(value=self._default("DEFAULT_NUM_PROMPTS", 3))
        ttk.Spinbox(params, from_=1, to=50, width=6, textvariable=self.var_num_prompts).grid(row=0, column=1, padx=(2, 14))

        ttk.Label(params, text="Temperatura:").grid(row=0, column=2, sticky="w")
        self.var_temperature = tk.DoubleVar(value=self._default("DEFAULT_TEMPERATURE", 0.2))
        ttk.Spinbox(params, from_=0.0, to=2.0, increment=0.1, width=6, textvariable=self.var_temperature).grid(row=0, column=3, padx=(2, 14))

        ttk.Label(params, text="Timeout (s):").grid(row=0, column=4, sticky="w")
        self.var_timeout = tk.DoubleVar(value=self._default("DEFAULT_TIMEOUT_S", 60))
        ttk.Spinbox(params, from_=5, to=600, increment=5, width=6, textvariable=self.var_timeout).grid(row=0, column=5, padx=(2, 14))

        # etichetta su colonna propria (no overlap coi campi della row 0) e
        # box di lettura largo quanto basta per "non calibrata" e per il
        # valore "xx.xx W" post-calibrazione
        ttk.Label(params, text="Potenza idle calibrata (W):").grid(row=1, column=0, sticky="w")
        self.var_idle = tk.StringVar(value="non calibrata")
        self.idle_label = ttk.Entry(params, textvariable=self.var_idle, width=18, state="readonly")
        self.idle_label.grid(row=1, column=1, columnspan=2, padx=(2, 14), sticky="w")

        btns = ttk.Frame(top)
        btns.pack(fill="x", padx=6, pady=2)
        self.btn_start = ttk.Button(btns, text="Avvia benchmark", command=self.start)
        self.btn_start.pack(side="left", padx=2)
        self.btn_stop = ttk.Button(btns, text="Ferma benchmark", command=self.stop, state="disabled")
        self.btn_stop.pack(side="left", padx=2)
        ttk.Button(btns, text="Calibra idle", command=self.calibrate_idle).pack(side="left", padx=8)
        # Pulsante di test rapido: salta la calibrazione empirica (~92 s) e
        # imposta un valore fisso dichiarato. Utile durante lo sviluppo per
        # iterare velocemente senza dover attendere le 3 finestre da 30 s.
        ttk.Button(
            btns, text="Calibra idle a 65 W", command=self._force_idle_65w,
        ).pack(side="left", padx=2)

        # ----------------------- stato privilegi UAC ------------------------
        # Il contatore EMI legge il device senza token elevato: lo stato dei
        # privilegi resta visibile come informazione, non come prerequisito
        # della misura (l'elevazione serviva al vecchio percorso LHM).
        try:
            from elevation import is_admin

            _admin = is_admin()
        except Exception:  # pragma: no cover - degradazione protetta
            _admin = False
        if _admin:
            self.lbl_uac = ttk.Label(
                btns, text="\u2714 Amministratore", foreground="#1a7f37")
        else:
            self.lbl_uac = ttk.Label(
                btns, text="privilegi standard (la misura non richiede admin)",
                foreground="gray")
        self.lbl_uac.pack(side="right", padx=6)

        # ---------------- sorgente dei test (universale) ---------------------
        src = ttk.LabelFrame(top, text="Sorgente dei Test")
        src.pack(fill="x", padx=6, pady=(4, 2))

        self.var_test_mode = tk.StringVar(value="csv")
        rb_csv = ttk.Radiobutton(
            src, text="Dataset Esterno (File CSV)", value="csv",
            variable=self.var_test_mode, command=self._on_test_mode_change,
        )
        rb_manual = ttk.Radiobutton(
            src, text="Prompt Manuale", value="manual",
            variable=self.var_test_mode, command=self._on_test_mode_change,
        )
        rb_csv.grid(row=0, column=0, sticky="w", padx=6, pady=(2, 0))
        rb_manual.grid(row=0, column=1, sticky="w", padx=12, pady=(2, 0))

        # --- A) fila CSV: entry percorso + Sfoglia + info parsing ------------
        self.csv_frame = ttk.Frame(src)
        self.csv_frame.grid(row=1, column=0, columnspan=2, sticky="ew", padx=6, pady=2)
        self.var_csv_path = tk.StringVar(value="")
        self.csv_entry = ttk.Entry(self.csv_frame, textvariable=self.var_csv_path)
        self.csv_entry.pack(side="left", fill="x", expand=True, padx=(0, 4))
        ttk.Button(self.csv_frame, text="Sfoglia...", width=10,
                   command=self.browse_csv).pack(side="left")
        self.csv_info = ttk.Label(src, text="Nessun CSV caricato. Colonne attese: "
                                            "prompt (o text/question/input/query); opzionale "
                                            "ground_truth (o expected_result).",
                                  foreground="gray")
        self.csv_info.grid(row=2, column=0, columnspan=2, sticky="w", padx=8, pady=(0, 2))

        # --- B) fila manuale: blocchi dinamici Domanda + Risposta Attesa ------
        # UI esplicita a campi separati: niente parsing del separatore " / ",
        # rischio di errori azzerato anche con prompt lunghi. La lista interna
        # e' persistente tra i cambi di modalita' (grid_forget non distrugge).
        self.manual_frame = ttk.Frame(src)
        self._manual_rows: List[dict] = []

        man_head = ttk.Frame(self.manual_frame)
        man_head.pack(fill="x", padx=6, pady=(4, 2))
        ttk.Button(man_head, text="+ Aggiungi Prompt", width=16,
                   command=self._manual_add_row).pack(side="left")
        ttk.Label(
            man_head,
            text="Inserisci la domanda nel campo \"Domanda\"; la risposta attesa "
                 "in \"Risposta Attesa\" (opzionale: se vuota -> accuratezza N/A, "
                 "salvate solo metriche energetiche/latenza/token).",
            foreground="gray", wraplength=560, justify="left",
        ).pack(side="left", padx=12)

        # contenitore scrollabile (canvas + inner frame + scrollbar verticale)
        man_body = ttk.Frame(self.manual_frame)
        man_body.pack(fill="both", expand=True, padx=6, pady=(0, 4))
        self._man_canvas = tk.Canvas(man_body, height=132, highlightthickness=0)
        man_vsbar = ttk.Scrollbar(man_body, orient="vertical",
                                  command=self._man_canvas.yview)
        self._man_inner = ttk.Frame(self._man_canvas)
        self._man_inner.bind(
            "<Configure>",
            lambda e: self._man_canvas.configure(scrollregion=self._man_canvas.bbox("all")),
        )
        self._man_win = self._man_canvas.create_window((0, 0), window=self._man_inner, anchor="nw")
        self._man_canvas.bind(
            "<Configure>", lambda e: self._man_canvas.itemconfigure(self._man_win, width=e.width)
        )
        self._man_canvas.configure(yscrollcommand=man_vsbar.set)
        self._man_canvas.pack(side="left", fill="both", expand=True)
        man_vsbar.pack(side="right", fill="y")
        # rotellina del mouse dentro il canvas (Windows/Tk standard)
        self._man_canvas.bind_all("<MouseWheel>", self._man_on_wheel)
        self._man_canvas.bind_all("<Button-4>", self._man_on_wheel)   # X11 fallback
        self._man_canvas.bind_all("<Button-5>", self._man_on_wheel)   # X11 fallback

        self._manual_add_row()  # primo blocco "Test 1" gia' pronto

        src.columnconfigure(0, weight=1)
        src.columnconfigure(1, weight=1)
        self._on_test_mode_change()  # stato iniziale widget dinamici

        # ------------------------- progress + log ----------------------------
        self.progress = ttk.Progressbar(log_frame, mode="determinate", maximum=100)
        self.progress.pack(fill="x", padx=6, pady=(4, 2))

        self.log_text = tk.Text(log_frame, height=6, wrap="word", state="disabled",
                                font=("Consolas", 9))
        self.log_text.pack(fill="both", expand=True, padx=6, pady=(2, 6))

        self._poller = None

    @staticmethod
    def _default(name, fallback):
        try:
            import config

            return getattr(config, name, fallback)
        except Exception:
            return fallback

    # ------------------------------------------------- sorgente dei test -----
    def _on_test_mode_change(self):
        """Mostra SOLO i widget della modalita' selezionata (pulito/dinamico)."""
        mode = self.var_test_mode.get()
        for frame in (self.csv_frame, self.manual_frame):
            frame.grid_forget()
        if mode == "manual":
            self.manual_frame.grid(row=1, column=0, columnspan=2, sticky="ew", padx=0, pady=2)
            self.csv_info.grid_remove()
        else:
            self.csv_frame.grid(row=1, column=0, columnspan=2, sticky="ew", padx=6, pady=2)
            self.csv_info.grid()

    def browse_csv(self):
        """Apre il file dialog e precarica/valida il dataset esterno."""
        try:
            from tkinter import filedialog

            path = filedialog.askopenfilename(
                title="Seleziona dataset CSV (output tool esterni, es. MUDILab)",
                filetypes=[("CSV", "*.csv"), ("Tutti i file", "*.*")],
            )
            if not path:
                return
            self.var_csv_path.set(path)
            self._preview_csv(path)
        except Exception as exc:
            self.log(f"Errore apertura file dialog: {exc}")

    def _preview_csv(self, path: str):
        """Validazione immediata del CSV: mostra n. prompt e presenza GT."""
        try:
            from test_source import load_prompts_from_csv

            items, err = load_prompts_from_csv(path)
        except Exception as exc:
            items, err = [], f"{type(exc).__name__}: {exc}"
        if items:
            n_gt = sum(1 for it in items if it.get("ground_truth"))
            txt = (f"CSV OK: {len(items)} prompt caricati; ground_truth presente "
                   f"per {n_gt}" + (" (accuratezza valutata dove disponibile)"
                                    if n_gt else " (accuratezza -> N/A: solo metriche energetiche)"))
            self.csv_info.config(text=txt, foreground="#1a7f37")
            self.log(txt + f" — file: {path}")
        else:
            self.csv_info.config(text=f"CSV non valido: {err}", foreground="#b35900")
            self.log(f"CSV non valido: {err}")

    def get_test_source_kwargs(self) -> dict:
        """Estrapola la selezione corrente per il runner (usato anche da CLI).

        Modalita' manuale: costruisce un testo compatibile con il parser di
        test_source ('prompt / ground_truth' per riga) dai campi espliciti.
        Gli a capo dentro i singoli campi vengono appiattiti con uno spazio
        per non corrompere il formato one-per-line; il separatore ' / ' e'
        generato SOLO noi blocchi con risposta attesa compilata, quindi il
        parsing downstream e' deterministico (niente ambiguita' utente).
        NB: questo metodo viene invocato dal thread del benchmark -> legge i
        widget Tk in modo thread-safe via invoke sul thread principale.
        """
        mode = self.var_test_mode.get()
        if mode == "manual":
            return {"test_mode": "manual", "manual_text": self._collect_manual_text()}
        return {"test_mode": "csv", "csv_path": self.var_csv_path.get().strip()}

    # ----------------------------------------------------- righe manuali -----
    def _man_on_wheel(self, event):
        """Scrolla la lista dei blocchi con la rotellina (Windows delta 120)."""
        try:
            if getattr(event, "num", None) == 4:      # X11 scroll giu'
                self._man_canvas.yview_scroll(1, "units")
            elif getattr(event, "num", None) == 5:    # X11 scroll su'
                self._man_canvas.yview_scroll(-1, "units")
            else:
                step = -1 if getattr(event, "delta", 0) > 0 else 1
                self._man_canvas.yview_scroll(step, "units")
        except Exception:
            pass

    def _manual_add_row(self):
        """Aggiunge un blocco numerato 'Test N' con Domanda + Risposta Attesa."""
        idx = len(self._manual_rows) + 1
        row_frame = ttk.Frame(self._man_inner, padding=(2, 2))
        row_frame.pack(fill="x", padx=2, pady=1)

        lbl_num = ttk.Label(row_frame, text=f"Test {idx}:", width=8)
        lbl_num.grid(row=0, column=0, sticky="w")

        var_q = tk.StringVar()
        var_gt = tk.StringVar()
        ent_q = ttk.Entry(row_frame, textvariable=var_q)
        ent_q.grid(row=0, column=1, sticky="ew", padx=(2, 6))
        ttk.Label(row_frame, text="Risposta Attesa (opz.):").grid(
            row=0, column=2, sticky="e", padx=(0, 2))
        ent_gt = ttk.Entry(row_frame, textvariable=var_gt, width=22)
        ent_gt.grid(row=0, column=3, sticky="ew", padx=(0, 6))
        row_frame.columnconfigure(1, weight=3)
        row_frame.columnconfigure(3, weight=1)

        entry = {"frame": row_frame, "label": lbl_num, "var_q": var_q,
                 "var_gt": var_gt, "ent_q": ent_q, "ent_gt": ent_gt}
        btn_rm = ttk.Button(row_frame, text="✕", width=3,
                            command=lambda e=entry: self._manual_remove_row(e))
        btn_rm.grid(row=0, column=4, sticky="e")
        entry["btn_rm"] = btn_rm
        self._manual_rows.append(entry)
        ent_q.focus_set()
        self._man_canvas.update_idletasks()
        try:  # porta la vista sull'ultima riga aggiunta
            self._man_canvas.yview_moveto(1.0)
        except Exception:
            pass

    def _manual_remove_row(self, entry):
        """Rimuove un blocco e rinumeria i restanti (Test 1..N)."""
        try:
            self._manual_rows.remove(entry)
        except ValueError:
            return
        entry["frame"].destroy()
        for i, row in enumerate(self._manual_rows, start=1):
            row["label"].config(text=f"Test {i}:")

    def _read_manual_entries(self) -> List[Tuple[str, Optional[str]]]:
        """Legge le coppie (domanda, risposta_attesa) dai campi Tk.

        Chiamato solo dal thread principale (start() prima di avviare il
        worker); lettura diretta degli StringVar, niente cross-thread.
        """
        out: List[Tuple[str, Optional[str]]] = []
        for row in self._manual_rows:
            q = row["var_q"].get().replace("\n", " ").replace("\r", " ").strip()
            gt = row["var_gt"].get().replace("\n", " ").replace("\r", " ").strip()
            out.append((q, gt or None))
        return out

    def _collect_manual_text(self) -> str:
        """Serializza i blocchi nel formato parseato da test_source."""
        lines = []
        for q, gt in self._read_manual_entries():
            if not q:
                continue
            lines.append(f"{q} / {gt}" if gt else q)
        return "\n".join(lines)

    def count_manual_prompts(self) -> int:
        """Numero di blocchi con domanda compilata (per log/validazione GUI)."""
        return sum(1 for q, _ in self._read_manual_entries() if q)

    # ------------------------------------------------------------------- log
    def log(self, msg: str):
        self._q.put(("log", msg))

    def _drain_queue(self):
        try:
            while True:
                kind, payload = self._q.get_nowait()
                if kind == "log":
                    stamp = time.strftime("%H:%M:%S")
                    self.log_text.configure(state="normal")
                    self.log_text.insert("end", f"[{stamp}] {payload}\n")
                    self.log_text.see("end")
                    self.log_text.configure(state="disabled")
                elif kind == "progress":
                    done, total = payload
                    self.progress["maximum"] = max(total, 1)
                    self.progress["value"] = done
                elif kind == "idle":
                    self.var_idle.set(f"{payload:.2f} W")
                elif kind == "done":
                    self._set_running(False)
                    summary = payload
                    self.log(
                        f"Benchmark terminato: {summary.get('records', 0)} record, "
                        f"{summary.get('errors', 0)} errori"
                        + (" (ANNULLATO)" if summary.get("cancelled") else "")
                    )
        except queue.Empty:
            pass
        finally:
            # Il poller DEVE restare attivo finche' la coda e' vuota: i
            # messaggi di calibrazione (idle/log) arrivano dal worker thread
            # e, senza questa guardia, il campo GUI non si aggiornava.
            if self._running or not self._q.empty():
                self.after(120, self._drain_queue)
            else:
                self._poller = None

    def _ensure_poller(self):
        if self._poller is None:
            self._poller = True
            self.after(50, self._drain_queue)

    def _set_running(self, running: bool):
        self._running = running
        self.btn_start.config(state="normal" if not running else "disabled")
        self.btn_stop.config(state="normal" if running else "disabled")

    # --------------------------------------------------------------- actions
    def start(self):
        if self._running:
            return
        local_models, cloud_sel = self.get_selections()
        if not local_models and not cloud_sel:
            self.log("Seleziona almeno un modello locale o cloud prima di avviare.")
            return

        # convalida sorgente dei test PRIMA di avviare il thread (GUI: niente
        # fallback silenzioso, errore esplicito a video)
        src_kwargs = self.get_test_source_kwargs()
        try:
            from test_source import load_test_source

            items, err = load_test_source(
                mode=src_kwargs["test_mode"],
                csv_path=src_kwargs.get("csv_path"),
                manual_text=src_kwargs.get("manual_text"),
                fallback_config=False,
            )
        except Exception as exc:
            items, err = [], f"{type(exc).__name__}: {exc}"
        if not items:
            self.log(f"Impossibile avviare: sorgente test non valida — {err}")
            return
        n_gt = sum(1 for it in items if it.get("ground_truth"))
        self.log(
            f"Sorgente test selezionata: {len(items)} prompt "
            f"({src_kwargs['test_mode']}); ground truth per {n_gt} "
            + ("-> accuratezza valutata tramite confronto"
               if n_gt else "-> accuratezza N/A: verranno salvate solo le metriche energetiche/di latenza")
        )

        self._stop_event.clear()
        self.progress["value"] = 0
        self._set_running(True)
        self._ensure_poller()

        # AVVISO IMPORTANTE: isolamento sistema
        self.log("=" * 70)
        self.log("⚠ ATTENZIONE: BENCHMARK ENERGETICO IN CORSO")
        self.log("=" * 70)
        self.log(
            "Per garantire misure accurate, NON utilizzare il PC durante il benchmark.\n"
            "Evitare di aprire applicazioni, spostare finestre, copiare file o eseguire\n"
            "altri programmi. Qualsiasi attività aggiuntiva altera le misure energetiche.\n"
            "Il benchmark durerà alcuni minuti (calibrazione + query)."
        )
        self.log("=" * 70)

        self.log(
            f"Avvio benchmark — locali: {local_models or '-'} | "
            f"cloud: {[c['model'] for c in cloud_sel] or '-'} | "
            f"sorgente: {src_kwargs['test_mode']} | "
            f"prompt: {self.var_num_prompts.get()} T={self.var_temperature.get()} "
            f"timeout={self.var_timeout.get()}s"
        )
        kwargs = dict(
            local_models=local_models,
            cloud_selection=cloud_sel,
            num_prompts=int(self.var_num_prompts.get()),
            temperature=float(self.var_temperature.get()),
            timeout_s=float(self.var_timeout.get()),
            on_log=lambda m: self._q.put(("log", m)),
            on_progress=lambda i, n: self._q.put(("progress", (i, n))),
            stop_event=self._stop_event,
            skip_idle_calibration=SESSION_has_idle(),
            **src_kwargs,
        )
        self._worker = threading.Thread(
            target=self._run_worker, kwargs=kwargs, daemon=True, name="cw-benchmark"
        )
        self._worker.start()

    def _run_worker(self, **kwargs):
        try:
            from benchmark_unified import run_unified_benchmark

            summary = run_unified_benchmark(**kwargs)
            self._q.put(("done", summary))
        except Exception as exc:  # doppia rete difensiva
            self._q.put(("log", f"ERRORE FATALE benchmark: {type(exc).__name__}: {exc}"))
            self._q.put(("done", {"records": 0, "errors": 1, "cancelled": True}))

    def stop(self):
        if not self._running:
            return
        self._stop_event.set()
        self.log("Interrupt richiesto: atteso completamento della richiesta corrente…")

    # ------------------------------------------------------------ calibrazione
    def _force_idle_65w(self):
        """Imposta P_idle a 65 W con provenienza 'manual_override' (test rapido).

        Salta la calibrazione empirica (~92 s) e inietta un valore fisso
        dichiarato. Utile durante lo sviluppo per iterare velocemente; il
        valore e' marcato come non calibrato nelle note della riga CSV
        (idle_provenance='manual_override'), quindi distinguibile da una
        calibrazione reale.
        """
        from energy.energy_session import SESSION

        SESSION.idle_power_w = 65.0
        SESSION.idle_provenance = "manual_override"
        self.var_idle.set("65.00 W")
        self.log(
            "P_idle impostata a 65.00 W (manual_override, test rapido): "
            "la riga CSV sara' marcata idle_provenance='manual_override' "
            "e distinguibile da una calibrazione empirica"
        )

    def calibrate_idle(self):
        from energy.energy_session import SESSION

        def worker():
            was_running = SESSION.running
            try:
                if not was_running:
                    SESSION.start()
                    time.sleep(SESSION.interval_s * 2)
                # avanzamento live nel log GUI (finestre da 30 s x 3: senza
                # questi messaggi sembra un blocco, invece e' in misura)
                SESSION.on_progress = lambda m: self._q.put(("log", m))
                self._q.put((
                    "log",
                    "Calibrazione idle EMPIRICA: NON generare carico sul PC… "
                    "(durata prevista: ~92 s = stabilizzazione + 3 finestre "
                    "da 30 s; progressivo sotto)",
                ))
                pw = SESSION.calibrate_idle()
                # FIX: il campo 'Potenza idle calibrata (W)' non si aggiornava
                # perche' il poller della coda veniva fermato appena la
                # calibrazione terminava prima che il messaggio ("idle", W)
                # venisse consumato. Si inserisce il valore DIRETTAMENTE nel
                # thread worker con after() (marco Tcl e' thread-safe per
                # StringVar.set da thread non-Tk? no: serve after), e si tiene
                # vivo il poller finche' la coda e' prosciugata.
                def _apply_idle(value=pw):
                    try:
                        self.var_idle.set(f"{value:.2f} W")
                    except Exception:  # pragma: no cover - widget distrutto
                        pass
                try:
                    self.after(0, _apply_idle)
                except Exception:
                    self._q.put(("idle", pw))
                reps = getattr(SESSION, "_idle_reps", None) or []
                det = (
                    " | rep: " + ", ".join(f"{r:.2f} W" for r in reps)
                    if reps else ""
                )
                n_camp = getattr(SESSION, "_idle_samples_count", None)
                camp_txt = f"; finestre misurate: {n_camp}" if n_camp else ""
                self._q.put((
                    "log",
                    f"P_idle = {pw:.2f} W misurata a riposo "
                    f"(mediana di 3 ripetizioni; contatore: "
                    f"{SESSION.source_method}){det}{camp_txt} — campo GUI aggiornato",
                ))
            except Exception as exc:
                self._q.put(("log", f"Calibrazione fallita: {exc}"))
                # niente fallimento silenzioso: se il contatore non legge i
                # Joule, la causa e' il device EMI (o RAPL su Linux): esegui
                # la diagnostica completa (console + log GUI).
                try:
                    import diagnostics

                    self._q.put(("log", "--- Diagnostica del contatore in corso (console + qui) ---"))
                    summary = diagnostics.run_diagnostics(
                        log_callback=lambda m: self._q.put(("log", m))
                    )
                    method = summary.get("method_expected", "n/d")
                    self._q.put(("log", f"--- Fine diagnostica: metodo atteso = {method} ---"))
                except Exception as d_exc:
                    self._q.put(("log", f"Diagnostica non disponibile: {d_exc}"))
            finally:
                if not was_running:
                    SESSION.stop()

        t = threading.Thread(target=worker, daemon=True, name="cw-idle-calib")
        t.start()
        self._ensure_poller()


def SESSION_has_idle() -> bool:
    try:
        from energy.energy_session import SESSION

        return SESSION.idle_power_w is not None
    except Exception:
        return False

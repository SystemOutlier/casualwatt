# AGENTS.md — regole vincolanti per chi lavora in questo repository

CasualWatt misura l'energia di una singola inferenza LLM locale su Windows,
leggendo il contatore energetico del package CPU. Il repository contiene insieme
il codice di produzione, i dati sperimentali e una tesi di laurea; le regole qui
sotto esistono perche' ognuna di esse corrisponde a un errore gia' commesso o a
una decisione gia' presa e documentata.

I numeri e gli ancoraggi di questo file sono verificati al **24-10-2026**; i tre
conteggi (suite di test, script `.py` di radice, file di `experiment_results/`) sono
riverificati al **26-10-2026** perche' erano stantii, e il conteggio della suite
e gli ancoraggi di `local_energy.py`/`energy_session.py` sono riverificati al
**27-10-2026** dopo l'uscita di LHM dall'implementazione (D18, 8 test rimossi) e
di nuovo al **28-10-2026** dopo NVML, AMD SMI, le tre colonne per token, il
controllo di timestamp del contatore AMD, il fallback `pawnio-counter` e il flag
`external_counter` (D14).
Se un ancoraggio non torna, il file e' stantio: va corretto, non ignorato.

Fonti primarie, in ordine di autorita':

1. `experiment_results/protocollo_v4_20261024.md` — decisioni congelate P1-P4,
   formulario consolidato F.0-F.17 e sezione preparatoria P6 (derivata, senza
   decisioni);
2. il codice in `cwEnergyModular/`;
3. gli artefatti tracciati in `experiment_results/`;
4. questo file.

---

## Regole dure

- **Mai `git push`** se non richiesto esplicitamente. Il lavoro e' locale.
- **Mai toccare `.casualwatt_keys.json`**: non crearlo, non leggerlo, non
  scriverlo, non forzarne l'aggiunta, non rimuovere la sua riga da `.gitignore`.
  Oggi non esiste sul disco ed e' ignorato.
- **Un commit per punto.** Ogni punto del protocollo congelato, e ogni modifica
  concettualmente unitaria, ha il suo commit con messaggio che dice cosa e'
  cambiato e perche'.
- **Se c'e' un problema, fermarsi.** Riportare il problema invece di aggirarlo.
  Nessun workaround silenzioso, nessun test disattivato, nessuna soglia spostata.
- **Mai `git add -A` ne' `git add .`**: aggiungere i percorsi esplicitamente. Alla
  radice ci sono materiali dell'utente (`.DOCX`, `.txt`), archivi e directory
  sottoposte ad audit che non devono entrare nel repo.
- **Un claim e' valido solo se ancorato**: `file:riga`, artefatto tracciato, o
  fonte esterna verificata alla fonte primaria con la data della verifica. Il
  materiale fornito dall'utente e le descrizioni prodotte da altri LLM sono
  **spunti, non evidenza**: vanno verificati prima di entrare in un documento.
- **Non sostituire il metodo in produzione senza evidenza sperimentale.**
  Tenere l'attuale finche' un esperimento non dimostra che l'alternativa e'
  migliore. Confrontare non significa adottare.

## Stato corrente del lavoro

P1 (baseline), P2 (token e terminazione), P3 (geometria e modello), P4
(incertezza e validazione) e P5 (schema CSV e runner, 2026-10-26) sono
**congelati**. P6 (esecuzione e analisi) e' **aperto**. P6 contiene P6.1
(pavimento di tempo a muro) e P6.2 (obblighi del pilota), derivati, e tre
requisiti adottati come
vincolanti: P6.3 (audit idle), P6.4 (simulazione Monte Carlo) e P6.6 (prova di
attribuzione ripetibile, 2026-10-25, con la banda di concordanza ancora da
congelare prima del primo run).

C'e' una sola eccezione dichiarata al congelamento: la **forma di combinazione**
di `budget_base_w` (quadratura o somma aritmetica) e' una decisione operativa
provvisoria, rinviata ai dati del pilota P2.9 e da chiudere **prima** della
campagna principale (protocollo P1.7, P1.13). La formula non si tocca nel
frattempo.

**Il codice sorgente di produzione e' sbloccato dal congelamento di P5**
(2026-10-26): la v4 si implementa contro il protocollo congelato, non contro la
descrizione che ne dava questo file. Lo stato aggiornato e' nella tabella in
testa al protocollo, non qui.

---

## Metodologia congelata

Le formule sono tutte in `protocollo_v4_20261024.md`, sezione *Formulario
consolidato* (F.0-F.17), con applicazione e giustificazione per ciascuna. Qui
stanno solo le regole che un agente puo' violare senza accorgersene.

- **Nessun fallback silenzioso.** La catena locale e' corta e va dichiarata: su
  Windows il contatore EMI (`emi-counter`), poi il contatore MSR del package
  letto via PawnIO (`pawnio-counter`, fallback dichiarato dal 28-10-2026), poi
  `unavailable`. LibreHardwareMonitor e' fuori dall'implementazione dal
  2026-10-27 (D18, metodo provato e superato) e non torna; su Linux i contatori
  RAPL. `CW_ENERGY_FILE` (DEV/TEST) ha precedenza su tutto. Non esiste piu'
  `CW_PRIMARY_CHANNEL`. **Il fallback non e' un secondo canale da sommare ne' una
  validazione di EMI**: `0x611` e `0xC001029B` sono lo stesso registro che legge
  EMI, quindi un accordo a finestra uguale e' coerenza di implementazione. La
  lettura via PawnIO **richiede un processo elevato**: da token UAC filtrato o
  SAFER `pawnio_open` risponde `0x80070005` e la ragione e' `access_denied`
  (misurato il 28-10-2026). EMI non ha questo requisito. Il canale va scritto per
  riga in `energy_calculation_method` (`energy/local_energy.py:148`), la finestra
  in `package_window_source` (`exact-counter | samples-fallback | unavailable`,
  `:138`), l'origine della baseline in `idle_provenance` (`:139`) e, dalla v4, in
  `baseline_backend` — campo del protocollo P1.3, non ancora presente nel codice.
  Il flag `external_counter` (`:153`, D14) dice se quel numero viene da un canale
  **esterno** alla catena: vero solo per `energy-file` (`CW_ENERGY_FILE`), falso
  per EMI, PawnIO, RAPL e per le catene GPU. Serve a escludere le righe
  dell'override con un filtro booleano, non confrontando l'etichetta.
  Mai presentare un fallback come un contatore, ne' un integrale come un
  contatore.
- **Sulla GPU il token dice quale percorso ha prodotto il numero.**
  `gpu_attribution_method` comincia sempre con `nvml-energy` (delta del
  contatore cumulativo NVML, mJ) o `nvml-power-integral`, oppure con
  `amdsmi-energy` / `amdsmi-power-integral` sulla catena AMD. Il contatore si usa
  solo con delta non negativo e senza sottofinestre escluse, che un delta non
  sa sottrarre; un integrale non si presenta come contatore. Su AMD SMI la
  risoluzione si legge dall'API (`accumulator * resolution` in microjoule) e se
  manca o e' zero il contatore non si usa: non si assume. Il `timestamp` del
  device (1 ns, solo AMD SMI) e' un controllo di avanzamento, non una durata:
  timestamp fermo = lettura non valida, timestamp che avanza con contatore
  immobile = zero legittimo. Un delta negativo e' un reset o un avvolgimento e
  si copre con l'integrale, **mai clampato a zero**. La potenza dichiara
  `power=<campo> [W]` (su AMD `socket_power` prima, poi
  `current_socket_power`, poi `average_socket_power`) e il contesto
  `platform=gpu_bm_linux` quando vale. Il monitor GPU si seleziona **per
  vendor**: NVML per NVIDIA, AMD SMI per AMD; non esiste una catena
  NVML -> AMD SMI per la stessa scheda, e i due non girano mai in parallelo.
  Le due catene sono **[I]** (implementate, provate con `pynvml` e `amdsmi` finti,
  28-10-2026) con **[V] da fare**: su questa macchina non c'e' ne' una NVIDIA
  ne' una AMD, quindi l'esecuzione su GPU reale e' ancora da registrare. Qui
  `[P]` non significa "implementato ma non provato su hardware": significa
  "progettato e non implementato". `pawnio-counter` invece e' **[I] con [V] su
  questo host** (Intel, 28-10-2026: rapporto 1,000578 e 1,000576 contro EMI a
  finestra uguale); restano **[V] da fare** il ramo AMD e riporto/reset reali.
- **Solo i token di canale reali.**
  `MEASURED_METHODS = ("emi-counter", "pawnio-counter", "power-integration",
  "librehardwaremonitor-energy", "energy-file", "rapl")`
  (`energy/energy_session.py:73-74`). La lista dice **quali righe portano un
  numero**, non cosa sa fare il codice oggi: `power-integration` e
  `librehardwaremonitor-energy` restano per i CSV archiviati in
  `experiment_results/` (v1-v3, four-way, A-B-A) misurati con quei canali, e
  nessun percorso di produzione li produce piu'. **CasualWatt non ha un percorso
  di stima TDP**: quello e' il percorso di CodeCarbon, usato nella tesi come
  contrasto. Non inventare un canale `estimated`.
- **PawnIO non si somma a EMI e non si carica da un blob qualunque.** La catena
  e' una cascata: se EMI risponde, PawnIO non viene aperto. Il modulo deve essere
  la release 0.2.11 con SHA-256 pinnato; un hash diverso non si carica. Con HVCI
  attivo **o non determinabile** il firmatario del driver deve essere Microsoft
  (`fail closed`); con HVCI disattivo un terzo valido e' ammesso ma la riga lo
  dichiara. Nessuna scrittura di MSR: l'IOCTL di scrittura esiste e non si usa.
- **Nessun doppio conteggio.** PP0 e PP1 sono sottoinsiemi di PKG: non sommare
  `PKG+PP0+PP1` e non sommare `PKG+DRAM` (`energy/emi_backend.py:32-34`, `:580`;
  `DOMAIN_NAMES = ("pkg", "dram", "pp0", "pp1")` a `:116`). PP1 alimenta
  `igpu_energy_j`, informativo.
- **Baseline = mediana, non media.**
  `baseline_pre_w = mediana(P_rep,1..3)` su tre finestre da 30 s (P1.3). Con
  `n = 3` una finestra contaminata sposta la media ma non la mediana (P1.14).
  Si applica `P_pre`; `P_post` e' diagnostica (`dP`), mai applicata. La ragione e'
  causale: la richiesta e' l'intervento, quindi il post e' una grandezza
  post-trattamento e condizionarvi l'estimatore renderebbe la correzione
  dipendente dall'esito che deve correggere (P1.14, motivazione causale).
- **Nessun troncamento.** Gli incrementi negativi si conservano con il flag
  `negative_increment`. La produzione attuale applica un clamp a zero in
  tre punti (`energy/local_energy.py:512`, `:530`, `:548`); la v4
  non lo fa e la differenza va dichiarata. La regola non nasce con la v4: era
  gia' DP-A nella specifica `METODI_E_FORMULE.md` del 21-10
  (`Ê_att = E_pkg^raw − E_base`, "firmata, mai clampata"), documento che sta in
  `Tesi-latex/` e quindi **fuori da git**: la
  citazione e' di provenienza, non e' un riferimento consultabile nel repo. Il
  codice di produzione e' dunque in ritardo di una generazione di metodo rispetto
  alla specifica. Uno zero legittimo e' dichiarato, non inventato: baseline non
  calibrata -> `baseline_energy_j = 0` con `idle_provenance = "uncalibrated"`
  (`energy/local_energy.py:373-382`).
- **Linguaggio dell'incertezza.** "Semi-range conservativi", mai "deviazione
  standard": con `n = 3` non si stima una varianza. Nessun `sqrt(...)` del
  protocollo e' una propagazione di varianza: sono combinazioni in quadratura di
  budget conservativi. Ogni numero pubblicato esce con il suo `budget_pred` e con
  la sua fascia di copertura; la copertura e' un campo (`coverage_tier`,
  `hull_margin_tok`), non un aggettivo nel testo.
- **La quadratura non e' un limite conservativo garantito.** Per due termini non
  negativi, `sqrt(a^2+b^2)/(a+b)` sta fra `1/sqrt(2)` e `1`: la somma aritmetica
  e' fra 1,00 e 1,41 volte la quadratura, qualunque siano i valori. La forma scelta e'
  provvisoria (P1.7): si scrive "budget", non "limite superiore garantito", e non
  si presenta la quadratura come se fosse la scelta scientificamente obbligata. La
  scelta dipende da cosa rappresenta il budget — incertezze standard combinabili
  sotto un'ipotesi probabilistica, oppure limiti assoluti senza compensazione — e
  non da quanto e' grande il numero.
- **Nessuna colonna di deviazione standard a `n = 3`** (P4.12). Non e' una stima
  utilizzabile di varianza ed e' ridondante: la terna `(min, med, max)` **e'** la
  terna delle osservazioni riordinata, quindi `sd` ne e' una funzione
  deterministica. Si registrano i tre valori, la mediana, il minimo, il massimo e
  il range. Un indicatore ridondante suggerisce che esista una sigma stimata.
- **Un accordo fra due letture dello stesso registro NON e' una validazione
  indipendente.** EMI, LibreHardwareMonitor (oggi fuori dall'implementazione) e
  SRUM leggono tutti
  `MSR_PKG_ENERGY_STATUS` (0x611): concordano per costruzione anche se la scala
  fosse sbagliata. La scala assoluta resta **non arbitrata** senza un wattmetro
  AC/DC esterno. Questo caveat va scritto prima dei numeri, non in nota.
- **"Validata" e' una parola sola.** Si scrive solo se tutti e sei gli anelli di
  P4.9 passano (`chain_status = validated`). Altrimenti si scrive quale anello ha
  ceduto. Dal 28-10-2026 il token ha un produttore (`validation_chain.py`), che
  applica le soglie congelate e restituisce l'etichetta del **primo** anello che
  cede; non promuove nulla e nessuna riga e' `validated` finche' una campagna non
  passa tutti e sei.
- **Le soglie sono congelate prima dei dati.** 1,0 W, 10%, 20%, `err_rel <= 10%`,
  2 token, fattore 2: nessuna si sposta dopo aver visto il risultato.

---

## Comandi di verifica

```
pytest cwEnergyModular          # 526 raccolti: 523 passati, 3 saltati (10 s)
```

**Mai `pytest` nudo dalla radice**: la raccolta viene interrotta da 6 errori in
`cpuepower/` e `cpuepower2/` (`ModuleNotFoundError: No module named
'cpuepower.attribution'`).

Ogni modifica al codice va accompagnata dall'output di pytest incollato per
intero, non riassunto.

La tesi si compila con MiKTeX in `Tesi-latex/qoder-bozza/`:

```
pdflatex main && biber main && pdflatex main && pdflatex main
```

**`biber`, non `bibtex`**: il documento usa biblatex e `bibtex main` fallisce con
"I found no \citation commands", azzera `main.bbl` e produce un PDF senza
bibliografia. Requisiti di compilazione: 0 overfull hbox, 0 riferimenti
indefiniti.

---

## Struttura dei file

- `cwEnergyModular/` — codice di produzione. `energy/emi_backend.py` (contatore
  EMI via ctypes/SetupAPI, con selezione del device CPU e del canale PKG dal
  metadato), `energy/pawnio_backend.py` (contatore MSR del package via driver
  PawnIO: sonda del driver e del modulo, unita' derivata, fallback dichiarato di
  EMI), `energy/energy_session.py` (canali, integrazione di
  finestra, interpolazione ai bordi), `energy/local_energy.py` (campi per riga),
  `casualwatt_csv_export.py` (`CSV_COLUMNS`, righe 17-200;
  `BLOCK_SUMMARY_COLUMNS`, 208-223; `POINT_SUMMARY_COLUMNS`, 225-233), e il
  runner v4 `benchmark_v4.py` (sequenza di blocco di P1.5).
- **I test stanno in due posti**: `cwEnergyModular/tests/` (467 raccolti) e
  direttamente in `cwEnergyModular/` (`test_answer_type_evaluation.py`, 35;
  `test_synthetic_window.py`, 2; `test_validazione_valutazione.py`, 22);
  467 + 59 = 526. Ogni test ha una docstring che
  dice *perche'* esiste e quale relazione matematica o fisica verifica, non solo
  cosa fa. Al 28-10-2026 la norma non e' rispettata da nove funzioni (13 node
  id, tutte scritte il 27-28/10): otto in `tests/test_pawnio_backend.py`, una in
  `tests/test_diagnostics_pmi.py`. E' debito registrato, e l'Appendice D lo
  stampa come "nessuna docstring" invece di mascherarlo. Dal 27-10-2026 la cartella contiene anche `tests/test_rapl_zone.py`
  (8, logica RAPL su un finto sysfs), `tests/test_diagnostics_pmi.py` (7,
  sonda PMI/WMI) e `tests/test_emi_selezione.py` (16, metadati EMI sintetici:
  metadato V2, scelta del device CPU, canale PKG per nome, V1 scartato): girano
  su Windows, senza host Linux. Dal 28-10-2026 ci sono
  `tests/test_gpu_nvml_energy.py` (8, catena `nvml-energy` ->
  `nvml-power-integral` con `pynvml` finto), `tests/test_gpu_amdsmi.py` (19,
  catena `amdsmi-energy` -> `amdsmi-power-integral`, conversione da microjoule,
  timestamp come controllo di avanzamento, delta negativo, provenienza di
  potenza e piattaforma, precedenza di NVML, con `amdsmi` finto) e
  `tests/test_metriche_per_token.py`
  (4, le tre colonne per token accodate al CSV) e
  `tests/test_external_counter.py` (6, D14: `external_counter` vero solo per
  `energy-file`, falso per `emi-counter`, `pawnio-counter`, `rapl` e per una
  riga con GPU `nvml-energy`) e `tests/test_chain_status.py` (17, il produttore
  di `chain_status` di P4.9: ordine degli anelli, confini delle soglie, quorum
  del test load-versus-control, vocabolario chiuso). Dal 28-10-2026 ci sono anche
  `tests/test_pawnio_backend.py` (25, catena `pawnio-counter`: sonda HVCI e
  firma con i due firmatari, hash del modulo, ramo Intel e ramo AMD mai su
  `0x611`, unita' derivata, riporto, reset, `access_denied`) e
  `tests/test_pawnio_selezione.py` (9, precedenza EMI -> PawnIO nella sessione,
  nessuna somma dei due canali) e `tests/test_diagnostics_pawnio.py` (4, la
  diagnostica dichiara `pawnio-counter` solo quando il contatore risponde,
  `unavailable` con la ragione altrimenti, e `CW_ENERGY_FILE` ha la precedenza).
  Nello stesso giorno `tests/test_cw_energy_file_override.py` (3) fissa il
  significato di quella precedenza: con un file valido la catena si ferma e
  EMI/PawnIO non vengono tentati, mentre file assente o valore non numerico
  lasciano proseguire la selezione di piattaforma.
  L'Appendice D della tesi e' stata rigenerata il 2026-10-28 con
  `cwEnergyModular/tools/dump_tests_latex.py`: 526 node id, 523 passati, 3
  saltati, docstring 513/526 (le nove funzioni senza docstring elencate sopra).
  Il documento compila: 176 pagine, 0 overfull. I conteggi non si aggiornano a
  mano: si rigenera dopo ogni test aggiunto, rimosso o rinominato. La verifica
  del conteggio e' in `experiment_results/appD_conteggio_20261028.md`. Il file
  generato (`Tesi-latex/qoder-bozza/generated/test_suite_appD.tex`) sta fuori
  da git.
  I 17 test di `tests/test_protocollo_p4_geometry.py` (2026-10-26, quinto turno
  di revisione esterna) congelano la geometria di copertura di P4.7 e la scala
  di `budget_pred`
  di P4.6 senza hardware né dati: sono i test da eseguire quando qualcuno propone
  di cambiare i vertici dell'inviluppo o la formula del budget.
- **Alla radice del repo stanno 35 script `.py` tracciati**: sono gli harness
  degli esperimenti (`emi_50ms_probe.py`, `emi_resolution_check.py`,
  `four_way_test.py`, `srum.py`, `srum_emi_cross.py`, `observer_cost_probe.py`,
  `idle_floor_sensitivity.py`, `four_way_pi_audit.py`, ...). Questa e' la
  convenzione reale: **un harness il cui output e' citato dalla tesi o dal
  protocollo va tracciato**, perche' un'analisi non tracciata e' un numero che
  nessuno puo' rigenerare. Le sonde usa-e-getta non citate da nulla sono in
  `.gitignore`.
- `cwEnergyModular/tools/` — 9 file tracciati: i generatori del materiale LaTeX
  (Appendici A, D, E), l'analisi di cadenza EMI, la validazione HWiNFO e le tre
  sonde PawnIO (`fetch_pawnio_modules.py` scarica e verifica i moduli della
  release con hash pinnato, `pawnio_probe.py` confronta il contatore con EMI e
  misura il costo di osservazione A-B-A, `pawnio_priv_probe.py` misura i
  privilegi invece di dedurli).
- `experiment_results/` — dati sperimentali e analisi, tracciati (210 file: 209 in
  radice, 1 in `codecarbon_four_way/`). I
  protocolli congelati stanno qui. Un artefatto nuovo entra con il proprio commit
  e con la propria analisi. Il gruppo `pawnio_probe_20261028*` (due run di
  confronto, due A-B-A, tre token di privilegio, l'analisi) e' l'evidenza sotto
  `pawnio-counter`: senza quei file il token non si cita.
- `cpuepower/`, `cpuepower2/` — toolkit sottoposto ad audit: i suoi numeri erano
  mock, la CLI crasha, la mappa MSR era sbagliata. **Banca di esperimenti, non un
  backend di misura.** Non importarlo, non citarlo come risultato.
- **Archivi fuori dal repo** — `../casualwattMetUni/` (verificata il 27/10/2026)
  e le cartelle sorelle con la stessa struttura contengono prototipi storici su
  pythonnet + `LibreHardwareMonitorLib` (`energy_tracker*.py`,
  `consumi_ollama*.py`, `test_ollama_energy.py`). Non sono il backend di
  produzione, non si importano e i loro numeri non sono confrontabili con una
  riga `emi-counter`: misurano una potenza gia' derivata dallo stesso registro
  0x611. La dichiarazione sta nel loro `README.md`, non qui. Resta in questo repo
  solo `consumi_ollama.py` alla radice, strumento legacy a stima TDP/WMI, anch'esso
  fuori dal percorso di misura.
- `Tesi-latex/` — **fuori da git**, ora anche in `.gitignore`. Compilazione
  locale, mai push. `\include` per i capitoli, `\input` per le appendici; nei
  capitoli gli accenti italiani sono ASCII-escapati (`\`e` per "e'", `\'e` per
  "é"), non Unicode.
- `.casualwatt_keys.json` — vedi Regole dure.
- CSV: `cwEnergyModular/results/*.csv` e' ignorato. I CSV di benchmark sotto
  `Tesi-latex/test-emi/` seguono la regola della tesi e restano fuori. Cio' che la
  tesi cita va in `experiment_results/` e viene committato.
- **Non esiste una directory `Temp/`** e non esiste questa convenzione: non
  inventarla.

---

## Scrittura accademica

- Usare le chiavi esistenti di `references.bib`; **mai inventare una citazione**.
  Le voci marcate `IN VERIFICA` (`dalerci2026move`) non vanno
  citate finche' non sono verificate alla fonte primaria. Ogni voce ha una `note`
  con gli ancoraggi e la data della verifica. `mlenergy2025` **non e' piu' IN
  VERIFICA**: verificata 26-10-2026 alla fonte primaria (Chung et al.,
  arXiv:2505.06371, NeurIPS 2025 D&B Spotlight). Attenzione alla confusione
  gia' commessa: `mlenergy2025` e' il *ML.ENERGY Benchmark* (J/token in steady
  state, misura con Zeus), `tschand2025mlperfpower` e' *MLPerf Power*
  (arXiv:2410.12032, J/campione, strumentazione certificata) e non fornisce
  J/token.
- Mantenere distinta in ogni tabella l'energia **misurata** da quella
  **attribuita**: l'attribuzione e' una procedura con una sua assunzione
  dichiarata (quota di tempo CPU come proxy della quota di energia), non una
  lettura del contatore.
- Terminologia unica: **baseline** per la stima della potenza idle del package.
  "Idle floor" compare una sola volta come sinonimo dichiarato; "fondo" non si usa
  come sostantivo tecnico.
- Le fonti non peer-reviewed (preprint, white paper, blog, repository) sono
  etichettate come tali nel testo, mai presentate come letteratura.
- Italiano formale nella tesi; identificatori di codice e token in inglese cosi'
  come compaiono nel sorgente.

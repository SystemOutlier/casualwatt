# Rapporto comparativo — Interfacce WMI / MSR / EMI per i consumi CPU su Windows 11 (i9-13900HK)

**Data:** venerdì 23/10/2026 · **Macchina di riferimento:** MINI_IT13, Intel Core i9-13900HK, Windows 11
**Vincolo di questo documento:** è un *rapporto + proposta di test*, non una modifica funzionale.
CasualWatt e `cpuepower/` NON sono stati modificati in questa fase (vedi §8).

> ⚠️ **Dichiarazione di onestà sul metodo.** Le attività 1–5 del brief ("verifica",
> "confronta con intervalli sincronizzati") vanno eseguite **sulla macchina target**.
> Questo ambiente di sviluppo è Linux/Debian: qui è impossibile enumerare i provider
> WMI reali di MINI_IT13 o interrogare il device EMI. Il rapporto quindi distingue
> esplicitamente, per ogni riga di tabella, tra:
> - **[MISURATO]** = evidenza raccolta su MINI_IT13 (dai collaudi del 23/10/2026);
> - **[VERIFICARE]** = da confermare con gli script forniti in `scripts/` (§7);
> - **[NOTO]** = comportamento documentato/stabile della piattaforma, non ancora
>   confermato su questa macchina.
> Nessun valore è stato assunto esistente prima della verifica: le classi WMI sono
> trattate come *candidati* finché lo sweep dello Step 0 non le conferma.

---

## 1. Provider WMI installati e classi candidato (nessuna presunzione d'esistenza)

### 1.1 Cosa sappiamo già da prove dirette su MINI_IT13

| Canale | Esito | Fonte evidenza |
|---|---|---|
| `root\wmi::ProcessorPowerMetrics` | **[VERIFICARE]** — citata nel brief come tentativo; la sua esistenza non è confermata: dipende da OEM/firmware (alcune piattaforme Dell/HP la pubblicano, la maggior parte no). Se assente, lo sweep dello Step 0 deve dirlo esplicitamente. | classi non enumerata qui (Linux) |
| `root\wmi::MSAcpi_ThermalZoneTemperature` | **[NOTO]** esiste quasi sempre (ACPI thermal zone), ma espone **temperature**, non energia/potenza. Utile solo come correlato, mai come misura di consumo. | — |
| `root\wmi::BatteryMeter` (classe base `MSAcpi_PowerMeter`) | **[NOTO]** espone potenza/energia **del sistema elettrico** (batteria/adattatore DC), non della CPU. Granularità tipicamente 0,1–1 W con aggiornamento lento (secondi/minuti): candidabile come *ground-truth secondario* sul totale di platform, non sui domini CPU. | — |
| `root\cimv2::Win32_Processor` (`CurrentClockSpeed`, `MaxClockSpeed`, `LoadPercentage`, …) | **[NOTO]** presente su ogni Windows. Nessuna informazione energetica: frequenza e utilizzo, cioè materia da *stime*, non misure. | — |
| Performance counters PDH `\Processor Utility (%)` (\_PCM Information) | **[NOTO]** nativo Win10+/Win11, nessun privilegio. È una **stima normalizzata del produttore** (workload-adjusted utilization), talvolta usata da tool terzi per derivare potenza via TDP: ricade nella categoria "stime", §2. | — |
| Registro `HKLM\...\Intel(R) RAPL ...` (letto dal nostro driver `rapl_registry`) | **[VERIFICARE]** esiste solo se un tool terzo (Intel Power Gadget, Turbo Mode Tool…) ha scritto lì i suoi valori. In tal caso la fonte NON è indipendente: è l'output di un altro lettore MSR/RAPL. | — |

### 1.2 Sweep completo richiesto (Step 0) — comandi esatti

Da eseguire **elevati** (la lettura delle definizioni di classe in `root\wmi` richiede admin) su MINI_IT13:

```powershell
# 1. Namespace WMI realmente presenti
Get-CimInstance -Namespace root -ClassName __Namespace | Select Name

# 2. Provider registrati (per capire QUALI fonti alimentano le classi)
Get-CimInstance -Namespace root -ClassName __Provider | Select Name,Class

# 3. Tutte le classi in root\wmi (solo NOME, senza istanze)
Get-CimClass -Namespace root/wmi | Select-Object CimClassName, CimClassProperties |
  Where-Object { $_.CimClassName -match 'Power|Energy|Meter|Thermal|Rapl|Processor|Battery|ACPI' }

# 4. Candidati specifici (NON dare per scontata nessuna risposta)
Get-CimInstance -Namespace root\wmi -ClassName ProcessorPowerMetrics -ErrorAction SilentlyContinue
Get-CimClass -Namespace root\wmi -ClassName MSAcpi_* | Select CimClassName
Get-CimInstance -Namespace root\wmi -ClassName BatteryMeter -ErrorAction SilentlyContinue

# 5. Contatori energetici in root\cimv2 (rari ma possibili su OEM custom)
Get-CimClass -Namespace root/cimv2 | Where-Object { ($_.CimClassProperties.Name |
  Where-Object { $_ -match 'Energy|Power|Joule|Watt' }) } | Select CimClassName -Unique
```

Criterio di accettazione dei risultati: una classe è **ammissibile** come sorgente
energetica solo se espone proprietà con unità dichiarata di energia (J/mJ/pWh) o
potenza (mW/W) **e** restituisce istanze popolate a regime variabile (idle vs carico).
Classi che restituiscono istanze vuote o costanti vanno scartate e tracciate come tali.

---

## 2. Distinzione tassonomica obbligatoria (cumulativo ≠ istantaneo ≠ stima)

| Tipo | Grandezza | Unità tipica | Esempi sul nostro stack | Cumulativo? |
|---|---|---|---|---|
| **Contatore di energia** | ∫P·dt | J, mJ, pWh, LSB×unit | EMI (pWh), MSR 0x611/0x639/0x641/0x619 (LSB×2^-14 J), LHM *se* esponesse sensori Energy | ✅ Sì — delta inizio/fine = Joule reali (protocollo CSV EMI) |
| **Misura/sensore di potenza** | P(t) | W, mW | LHM Rapl power sensors, `BatteryMeter` AC power, PDH `Processor Utility`→W (derivata) | ❌ No — richiede integrazione numerica (∑ P·Δt) → errore di discretizzazione, dipendenza dal periodo di campionamento |
| **Stima del produttore / modello** | f(clocks, C-states, TDP) | adimensionale o W modellati | PDH % Processor Utility, `Win32_Processor.LoadPercentage`, chiave registro RAPL scritta da tool terzi, il nostro `estimate` driver (TDP×utilizzo) | ❌ No — non è una misura; va sempre etichettata `estimated` |

Conseguenze operative già recepite nel codice (nessuna nuova modifica):
- `LibreHardwareMonitorBackend.source = "power_integration"`, `provides_package_energy = False` (P0-5): è un'**integrazione di potenza**, non un contatore; su MINI_IT13 LHM non espone alcun sensore Energy (misurato), quindi produce solo integrali.
- La cascata di back-end rifiuta `real_rapl` su sorgenti non-contatore (P0-5/P0-6).

## 3. Verifica accesso MSR RAPL in sola lettura (Windows user-mode)

Fatto 0 (non negoziabile): **Windows non espone alcuna API user-mode per RdMSR**.
Qualsiasi lettura MSR richiede un driver kernel firmato che esponga un device.

| Via | Stato su MINI_IT13 | Note |
|---|---|---|
| **WinRing0 (`\\.\WINRING0`)** | **[MISURATO]** CreateFile riesce, DeviceIoControl RDMSR 0x606 **fallisce** → ioctl non valido per quella versione del .sys; inoltre WinRing0 è nella **Vulnerable Driver Blocklist** e con HVCI attivo viene bloccato all'avvio. | Da marcare NON FUNZIONANTE salvo validazione EMI al 2% (già codificato in `msr_backends.py`). Non installare nulla di nuovo senza autorizzazione. |
| **LibreHardwareMonitorLib.dll (pythonnet)** | **[MISURATO]** funziona, ma espone **potenze integrate**, non i contatori energy (il sensore Energy RAPL non è pubblicato dalla LHM su questa CPU). Usa internamente un proprio driver kernel firmato. | Complemento utile per potenze istantanee Package/PP0/PP1/DRAM, non per Joule cumulativi "come nei CSV EMI". Condividere l'istanza `Computer()` con `energy_session.SESSION` (costo Update() raddoppiato, risoluzione degradata a 0,32 s misurata). |
| **OpenHardwareMonitor / RuCore / RWEverything** | **[VERIFICARE]** stessa famiglia di approcci "driver firmato + device". RWE ha un suo `.sys` ma è anch'esso soggetto a blocklist/HVCI. | Stessi vincoli di sicurezza di WinRing0. |
| **Driver custom (WDK, `\\.\RAPLReader`)** | Non necessario. | Punto 8 del brief: non sviluppare un kernel driver se le interfacce esistenti sono sufficienti. Nel nostro caso **esistono**: EMI nativo (§4) è sufficiente e migliore. |
| **EMI nativo (`\\?\acpi#genuineintel…i9-13900hk#0#{45bd8344-…}`)** | **[MISURATO]** IOCTL_EMI_GET_MEASUREMENT = 0x22400C, 4 record × 16 B, PKG a offset 0, energia in pWh (1 pWh = 3,6e-9 J), tempo in tick da 100 ns. Lettura **user-mode, zero privilegi admin, zero driver extra**. | È la sorgente di riferimento. Ground truth: idle 16,9 W; PL1 35 W / PL2 55 W (OEM). |

## 4. Confronto sincronizzato con EMI — matrice da compilare (test T2/T3, §7)

Schema di registrazione obbligatorio per ogni run (CSV generato dagli script proposti):

```
timestamp_utc_iso | source | domain | raw_value | unit | value_J_or_W | sample_period_s | error_code | notes
```

| Sorgente | Domini esposti | Unità | Frequenza max reale | Privilegi | Errore noto | Indipendenza da EMI (§5) |
|---|---|---|---|---|---|---|
| **EMI nativo** | PKG (+core/GPU/DRAM secondo spec) | pWh + tick 100 ns | [VERIFICARE] (ioctl-driven, ~ms) | nessuno | — | — (è il riferimento) |
| **MSR 0x611 via driver firmato** | PKG energy counter | LSB × 2^-14 J | ~kHz teorico, limitata dal driver | Admin + driver | WinRing0: ioctl errato/bloccato | ❌ **NO**: legge lo stesso identico contatore hardware che EMI campiona |
| **LHM power-integration** | Package/PP0/PP1/DRAM power (W) | W integrati | 0,32 s effettivi (misurato) | Admin (driver LHM) | nessun sensore Energy su 13900HK | ❌ NO: legge gli stessi MSR di potenza o loro derivate |
| **PDH % Processor Utility** | whole CPU | % | 1 s | nessuno | stima, non misura | ❌ NO: telemetria derivata dagli stessi contatori HW |
| **Registro RAPL (tool terzi)** | dipende dal tool | dipende | lento | Admin | assente se tool non installato | ❌ NO: output di un altro lettore MSR |
| **BatteryMeter / MSAcpi** | platform AC/battery | W | secondi-minuti | Admin | granularità grezza | ✅ **PARZIALE**: misura il punto di alimentazione AC, monte diverso dai contatori CPU → valida il bilancio energetico globale, non i singoli domini CPU |

Regola derivata dal punto 5 del brief: **accordo EMI↔MSR-diretto non è una validazione indipendente** (entrambi leggono IA32_PKG_ENERGY_STATUS 0x611 / i contatori package da cui EMI deriva i suoi record). Serve come *sanity check di unità e scaling* (deve stare entro 2%, criterio P0-4), mentre la vera validazione incrociata indipendente può venire solo da BatteryMeter (bilancio AC) o da una bilancia/analizzatore esterno.

## 5. Risposta sintetica alle domande del brief

1. **Esiste qualcosa oltre EMI?** Sì, ma tutto in **derivazione dalla stessa fonte hardware** (contatori RAPL/MSR) oppure in forma di **stima** (PDH, registro, TDP). Nessuna interfaccia WMI nativa nota pubblica Joule cumulativi CPU su Win11; `ProcessorPowerMetrics` è da verificare (probabilmente assente su MINI_IT13 — il fatto che il brief chieda di "provare" ne conferma lo status di ipotesi).
2. **EMI è complementare?** EMI **copre già** ciò che un RdMSR diretto darebbe (PKG/cores/GPU/DRAM, energia cumulativa), con in più timestamp in tick 100 ns, senza admin e senza driver aggiuntivo. Le alternative hanno senso solo se EMI non fosse disponibile (macchine senza estensione EMI) o per domini che EMI non espone.
3. **Driver custom:** **non serve** (punto 8 del brief soddisfatto dalle interfacce esistenti). Rinuncia motivata al Test Signing.

## 6. Compatibilità, privilegi, firma, rischi, manutenzione, overhead

| Aspetto | Valutazione |
|---|---|
| Windows 11 compat | EMI: nativo (feature Intel, esposizione Windows 11 recente). WMI root\wmi: stabile. PDH: stabile. WinRing0/LHM-driver: soggetti a blocklist/HVCI — rischio rottura ad ogni feature update. |
| Privilegi | EMI: **nessuno**. WMI query: admin per enumerazione root\wmi, spesso user per istanze. LHM/WinRing0/RWE: admin. |
| Firma driver | LHM: driver firmato e mantenuto. WinRing0: firmato ma **in vulnerable blocklist**. Custom WDK: richiederebbe EV cert + attestation signing o Test Signing (da evitare). |
| Sicurezza | Ogni driver che espone RdMSR/WrMSR arbitrari è superficie d'attacco (CVE note su WinRing0). Principio del minimo privilegio → preferire EMI. |
| Manutenzione | EMI: zero (OS-managed). pythonnet+LHM: due dipendenze pesanti (.NET runtime, DLL). win32com/CIM: fragile (vedi bug P0-1 con `__properties__` vs `Properties_`). |
| Overhead di misura | EMI: ioctl singolo, trascurabile. LHM: `hw.Update()` ≈ decine di ms e **raddoppia** se due Computer() attivi. PDH: ~0,1 ms/query. WinRing0: ~ms per RdMSR. |

## 7. Proposta di piano di test (da approvare — non eseguito)

**Ambiente:** MINI_IT13, PowerShell + Python 3.12 (repo `cpuepower`), protocollo A−B−A dell'harness esistente `CWProject/four_way_test.py` (idle 45 s → 90 s Ollama `num_predict=32, temperature=0` → idle2 45 s). Nessuna installazione di nuovi driver. Nessuna scrittura MSR.

- **T0 — Inventory (governa §1.2).** Esegui lo sweep CIM; output `inventory_wmi.csv`. *Passa se:* lista completa con esito per ogni classe candidata (presente/assente/vuota).
- **T1 — EMI ground truth.** 180 s di lettura EMI continua (script proposto `scripts/t1_emi_baseline.py`): registra timestamp UTC, ΔpWh, tick, frequenza reale, errori. *Output:* baseline idle/carico/idle in J e W medi.
- **T2 — Finestra sincronizzata.** Stesso run di T1 con campionatori paralleli: LHM (istanza condivisa!), PDH, eventuale backend MSR funzionante, BatteryMeter se presente. Allineamento ai timestamp EMI ±50 ms. *Output:* CSV multi-sorgente (schema §4).
- **T3 — Analisi di concordanza.** Per ogni coppia (X vs EMI): ΔE sulla finestra, scarto %, regressione P_X(t) vs P_EMI(t), lag. Soglie: contatore reale ≤2%; power-integration ≤5% (ma etichettato stima); stime: solo correlazione attesa ρ>0,8 senza pretese di valore assoluto. *Criterio:* una sorgente X è "validata" solo se passa T3 **e** §5 ne ammette l'utilità (indipendente o complementare).
- **T4 — Overhead & stabilità.** Misura costo CPU/tempo di ogni sampler durante T2; ripeti 3 volte; verifica assenza crash/degradazioni (risoluzione LHM, errori CIM).
- **Gate finale:** nessun numero di cpuepower esce come "reale" se non prodotto da un canale passato T3 contro EMI. Mock ⇒ banner + suffisso `*_MOCK.*` (P1-1).

Script minimi previsti (da scrivere dopo approvazione): `t0_inventory.ps1`, `t1_emi_baseline.py`, `t2_sync_window.py`, `t3_agreement.py`. Nessuno tocca CasualWatt.

## 8. Conformità ai vincoli del brief

- Punto 7: **nessun write MSR, nessuna modifica di power profile, nessun driver installato** (ambiente dev Linux, e comunque gli script proposti sono read-only).
- Punto 8: **nessun kernel driver custom sviluppato**; decisione motivata al §5.3.
- "Non modificare CasualWatt": nessun file fuori da `/workspace/docs` toccato in questa consegna.
- "Nessuna新功能 fino ad approvazione": questo documento + 0 modifiche funzionali. Nota di trasparenza: la suite `tests/` del repo snapshot mostra 5 fallimenti residui dal lavoro precedente (rinomina `real_rapl→cpu_time_share` e decode 0x606 non ancora propagati ai test); sono fuori dallo scope di questa consegna e verranno risolti solo dopo approvazione del piano.

## Appendice A — Correzioni già applicate al codice (richiamo dal brief precedente, per contesto)

- P0-1: probe() difensivo anche su `win32com` (`Properties_`, non `__properties__`), cascata non crasha più.
- P0-2/P0-3: mappa MSR verificata contro `arch/x86/include/asm/msr-index.h` (PP0=0x639, PP1=0x641, PLATFORM=0x64D, DRAM=0x619, PKG=0x611) e decode 0x606 conforme a `rapl_check_hw_unit()` (client 0x000A0E03 → 2^-14 J, 2^-3 W, 2^-10 s).
- P0-5: LHM marcato `power_integration`, `provides_package_energy=False`.
- P0-6: formula rinominata `cpu_time_share`, confidence low, differenziale E_inc = E_pkg − P_base·dt, disclaimer obbligatorio.

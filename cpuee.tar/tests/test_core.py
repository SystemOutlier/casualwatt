"""Test unitari per cpuepower.

Eseguibili su qualsiasi OS: i driver Windows vengono mockati; la logica di
attribuzione, delta e stima viene validata con dati finti deterministici.
"""

from __future__ import annotations

import time
import unittest
from typing import Dict, List, Optional

from cpuepower.attribution import AttributionMethod, TreeEnergyEstimator
from cpuepower.drivers.base import DriverCapability, EnergyDriver
from cpuepower.process_tree import compute_tree_delta
from cpuepower.sampler import best_driver_for
from cpuepower.types import (
    CoreEnergy,
    PackageEnergy,
    ProcessCpuTimes,
    ReadingSource,
)


class FakePkgDriver(EnergyDriver):
    """Driver finto con contatore package sintetico e utility per-core opzionale."""

    name = "fake_pkg"
    description = "fake"
    source = ReadingSource.WMI_MSR

    def __init__(self, power_w: float = 50.0, cores_util: Optional[List[float]] = None):
        self.power_w = power_w
        self.cores_util = cores_util or []
        self._last_ts: Optional[float] = None
        self._acc_mj = 0.0

    def probe(self) -> DriverCapability:
        return DriverCapability(name=self.name, description=self.description,
                                available=True, provides_package_energy=True,
                                provides_core_utility=bool(self.cores_util))

    def read_package(self) -> PackageEnergy:
        ts = time.time()
        if self._last_ts is not None:
            self._acc_mj += self.power_w * (ts - self._last_ts) * 1000.0
        self._last_ts = ts
        return PackageEnergy(timestamp=ts, energy_mj=self._acc_mj, available=True,
                             source=self.source)

    def read_cores(self) -> List[CoreEnergy]:
        ts = time.time()
        return [CoreEnergy(core_id=i, timestamp=ts, perf_utility_pct=u)
                for i, u in enumerate(self.cores_util)]


def make_deltas() -> tuple:
    before_tree = {
        100: ProcessCpuTimes(100, user_s=10.0, kernel_s=2.0),
        101: ProcessCpuTimes(101, user_s=5.0, kernel_s=1.0),
        102: ProcessCpuTimes(102, user_s=1.0, kernel_s=0.5),
    }
    after_tree = {
        100: ProcessCpuTimes(100, user_s=12.0, kernel_s=2.5),   # +2.5 s
        101: ProcessCpuTimes(101, user_s=6.0, kernel_s=1.0),    # +1.0 s
        # 102 morto durante la finestra: ignorato nel delta
        103: ProcessCpuTimes(103, user_s=0.4, kernel_s=0.1),    # nuovo: +0.5 s
    }
    before_sys = dict(before_tree)
    before_sys.update({
        1: ProcessCpuTimes(1, user_s=100.0, kernel_s=50.0),
        2: ProcessCpuTimes(2, user_s=30.0, kernel_s=10.0),
    })
    after_sys = dict(after_tree)
    after_sys.update({
        1: ProcessCpuTimes(1, user_s=104.0, kernel_s=52.0),     # +6 s
        2: ProcessCpuTimes(2, user_s=31.0, kernel_s=10.5),      # +1.5 s
    })
    return before_tree, after_tree, before_sys, after_sys


class TestTreeDelta(unittest.TestCase):
    def test_delta_basic(self):
        bt, at, bs, asys = make_deltas()
        pids = set(bt) | set(at)
        delta = compute_tree_delta(pids, bt, at, bs, asys, window_s=5.0, root_name="root.exe")
        # albero: 2.5 + 1.0 + 0.5 = 4.0 s ; sistema: 4.0 + 6.0 + 1.5 = 11.5 s
        self.assertAlmostEqual(delta.total_cpu_s, 4.0, places=6)
        self.assertAlmostEqual(delta.system_total_cpu_s, 11.5, places=6)
        self.assertAlmostEqual(delta.cpu_fraction, 4.0 / 11.5, places=6)
        self.assertEqual(delta.n_processes_in_tree, 3)
        self.assertIn(103, delta.per_pid_delta_s)   # nuovo processo incluso
        self.assertNotIn(102, delta.per_pid_delta_s)  # morto escluso (limite documentato)

    def test_negative_delta_clamped(self):
        bt = {7: ProcessCpuTimes(7, 5.0, 1.0)}
        at = {7: ProcessCpuTimes(7, 3.0, 0.5)}   # PID riciclato
        delta = compute_tree_delta([7], bt, at, bt, at, window_s=1.0)
        self.assertEqual(delta.total_cpu_s, 0.0)


class TestAttribution(unittest.TestCase):
    def _delta(self):
        bt, at, bs, asys = make_deltas()
        return compute_tree_delta(set(bt) | set(at), bt, at, bs, asys,
                                  window_s=5.0, root_name="root.exe")

    def test_apodictic_exact_value(self):
        drv = FakePkgDriver(power_w=50.0)
        est = TreeEnergyEstimator(drv)
        delta = self._delta()
        a = drv.read_package()
        time.sleep(0.05)
        b = drv.read_package()
        res = est.estimate(delta, a, b, method=AttributionMethod.APPODICTIC)
        d_pkg_mj = (b.energy_mj - a.energy_mj)
        self.assertIsNotNone(res.energy_mj)
        self.assertAlmostEqual(res.energy_mj, d_pkg_mj * delta.cpu_fraction, places=3)
        self.assertEqual(res.method, "apodictic")

    def test_heuristic_uses_core_weights(self):
        drv = FakePkgDriver(power_w=50.0, cores_util=[80.0, 60.0, 20.0, 0.0])
        est = TreeEnergyEstimator(drv)
        delta = self._delta()
        a = drv.read_package()
        time.sleep(0.05)
        b = drv.read_package()
        res = est.estimate(delta, a, b, method=AttributionMethod.AUTO)
        # auto deve scegliere heuristic quando ci sono utility per-core
        self.assertEqual(res.method, "heuristic")
        self.assertIsNotNone(res.energy_mj)
        self.assertLessEqual(res.energy_mj, (b.energy_mj - a.energy_mj) + 1e-6)

    def test_tdp_estimate_fallback_without_pkg(self):
        class NoPkgDriver(FakePkgDriver):
            def read_package(self):
                return PackageEnergy.unavailable(time.time(), ReadingSource.PDH_COUNTER)

        drv = NoPkgDriver()
        est = TreeEnergyEstimator(drv, tdp_w=65.0, idle_w=10.0)
        delta = self._delta()
        a = drv.read_package()
        b = drv.read_package()
        res = est.estimate(delta, a, b, method=AttributionMethod.AUTO)
        self.assertEqual(res.method, "tdp_estimate")
        self.assertIsNotNone(res.power_w)
        # active_frac = 4.0s / (5.0s * ncpu) => potenza tra idle e tdp
        self.assertGreaterEqual(res.power_w, 10.0)
        self.assertLessEqual(res.power_w, 65.0 + 1e-9)

    def test_per_pid_split_sums_to_total(self):
        drv = FakePkgDriver(power_w=40.0)
        est = TreeEnergyEstimator(drv)
        delta = self._delta()
        a = drv.read_package()
        time.sleep(0.05)
        b = drv.read_package()
        res = est.estimate(delta, a, b, method=AttributionMethod.APPODICTIC)
        total = sum(res.per_pid_energy_mj.values())
        self.assertAlmostEqual(total, res.energy_mj, places=3)


class TestBestDriver(unittest.TestCase):
    def test_prefers_package_driver(self):
        class Pkg(EnergyDriver):
            name = "pkg"
            def probe(self):
                return DriverCapability("pkg", "", True, True, False)
            def read_package(self):
                raise NotImplementedError

        class Util(EnergyDriver):
            name = "util"
            def probe(self):
                return DriverCapability("util", "", True, False, True)
            def read_package(self):
                raise NotImplementedError

        chosen = best_driver_for(True, drivers=[Util(), Pkg()])
        self.assertEqual(chosen.name, "pkg")

    def test_falls_back_to_first_available(self):
        class Unavail(EnergyDriver):
            name = "x"
            def probe(self):
                return DriverCapability("x", "", False, False, False, reason="no")
            def read_package(self):
                raise NotImplementedError

        class Util(EnergyDriver):
            name = "util"
            def probe(self):
                return DriverCapability("util", "", True, False, True)
            def read_package(self):
                raise NotImplementedError

        chosen = best_driver_for(True, drivers=[Unavail(), Util()])
        self.assertEqual(chosen.name, "util")


if __name__ == "__main__":
    unittest.main()

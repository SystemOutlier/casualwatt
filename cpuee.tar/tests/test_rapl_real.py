"""Test per la catena RAPL reale: decodifica MSR -> Joule -> attribuzione albero."""

import time

import pytest

from cpuepower.attribution import AttributionMethod, TreeEnergyEstimator
from cpuepower.drivers.rapl_msr import RealRaplDriver
from cpuepower.msr_backends import MockRaplBackend, integrate_power, select_backend
from cpuepower.process_tree import ProcessTree, measure_window
from cpuepower.rapl_units import (
    COUNTER_WRAP,
    RaplSnapshot,
    RaplUnits,
    counter_delta_to_joules,
    counter_to_joules,
    diff_snapshots,
)
from cpuepower.types import ReadingSource


# --------------------------------------------------------------------------- #
# rapl_units: matematica degli MSR                                              #
# --------------------------------------------------------------------------- #
def test_pkg_unit_msr_decoding():
    # valore tipico Skylake: units_joules=14 (bits0-3), units_watts=13(bits16-23),
    # time_unit=20? (max 0xF->15; uso 10), data_wrapped=0
    raw = (14 << 0) | (13 << 16) | (10 << 24)
    u = RaplUnits.from_msr(raw)
    assert u.joule_unit_j == 2.0 ** -14
    assert u.watt_unit_w == 2.0 ** -13
    assert u.time_unit_s == 2.0 ** -10
    assert not u.data_wrapped


def test_pkg_unit_data_wrapped_bit():
    raw = 14 | (1 << 30)
    u = RaplUnits.from_msr(raw)
    assert u.data_wrapped


def test_counter_to_joules_exact():
    u = RaplUnits(joule_unit_j=2.0 ** -14, watt_unit_w=1, time_unit_s=1)
    assert counter_to_joules(65536, u) == pytest.approx(4.0)   # 2^16 LSB * 2^-14 = 4 J
    assert counter_to_joules(1, u) == pytest.approx(2.0 ** -14)  # ~15.26 mJ/LSB


def test_counter_delta_wraparound():
    u = RaplUnits(joule_unit_j=2.0 ** -14, watt_unit_w=1, time_unit_s=1)
    # contatore che wrap-a: prev vicino a 2^32, cur piccolo
    prev = COUNTER_WRAP - 1000
    cur = 512
    d = counter_delta_to_joules(prev, cur, u)
    assert d == pytest.approx(1512 * 2.0 ** -14)
    assert d >= 0


def test_diff_snapshots_multi_domain():
    u = RaplUnits(joule_unit_j=2.0 ** -14, watt_unit_w=1, time_unit_s=1)
    b = RaplSnapshot(ts=0.0, units=u, counters={"package": 100000, "pp0": 50000,
                                               "pp1": None, "dram": 20000})
    a = RaplSnapshot(ts=2.0, units=u, counters={"package": 231072, "pp0": 115536,
                                               "pp1": None, "dram": 33107})
    w = diff_snapshots(b, a)
    assert w.window_s == 2.0
    # package: 231072-100000 = 131072 LSB * 2^-14 = 8.0 J
    assert w.package_j == pytest.approx(8.0)
    assert w.pp0_j == pytest.approx(4.0)              # 65536 LSB * 2^-14
    assert w.dram_j == pytest.approx(13107 * 2.0 ** -14)  # ~0.79999 J
    assert w.pp1_j is None
    assert w.package_w == pytest.approx(4.0)


# --------------------------------------------------------------------------- #
# mock backend + integrazione potenza                                           #
# --------------------------------------------------------------------------- #
def test_mock_backend_monotonic_and_scales():
    be = MockRaplBackend(base_w=10.0)
    ok, _ = be.probe()
    assert ok
    s1 = be.read_snapshot()
    time.sleep(0.05)
    s2 = be.read_snapshot()
    assert s2.counters["package"] > s1.counters["package"]
    w = diff_snapshots(s1, s2)
    # ~10 W su ~0.05 s => ~0.5 J, tolleranza larga (thread scheduling)
    assert 0.0 < w.package_j < 5.0


def test_integrate_power_trapezoid_simple():
    samples = [(0.0, 10.0), (1.0, 10.0), (2.0, 20.0)]
    out = integrate_power(samples)
    assert out[0][1] == 0.0
    assert out[1][1] == pytest.approx(10.0)
    assert out[2][1] == pytest.approx(30.0)


# --------------------------------------------------------------------------- #
# driver + attribuzione formula EMI                                             #
# --------------------------------------------------------------------------- #
def test_real_rapl_driver_read_package_source():
    drv = RealRaplDriver(backend=MockRaplBackend(base_w=20.0))
    caps = drv.probe()
    assert caps.available and caps.provides_package_energy
    pkg = drv.read_package()
    assert pkg.available
    assert pkg.source is ReadingSource.RAPL_MSR
    assert pkg.energy_mj > 0


def test_select_backend_falls_back_when_no_windows():
    backend, ok, reason = select_backend()
    # su Linux nessun backend reale e' disponibile
    import sys
    if sys.platform != "win32":
        assert not ok
        assert "Windows" in reason or "nessun backend" in reason


def test_attribution_formula_real_rapl():
    """E_tree = E_pkg_REALE * (CPU_albero / CPU_sistema), con valori noti."""
    from cpuepower.types import PackageEnergy

    drv = RealRaplDriver(backend=MockRaplBackend())
    est = TreeEnergyEstimator(drv)
    before = PackageEnergy(timestamp=0, energy_mj=1_000_000.0, available=True,
                           source=ReadingSource.RAPL_MSR)
    after = PackageEnergy(timestamp=10, energy_mj=1_100_000.0, available=True,
                          source=ReadingSource.RAPL_MSR)

    class FakeDelta:
        root_pid = 1
        root_name = "test"
        window_s = 10.0
        total_cpu_s = 2.5
        system_total_cpu_s = 10.0
        cpu_fraction = 0.25
        per_pid_delta_s = {1: 2.0, 2: 0.5}
        n_processes_in_tree = 2

    res = est.estimate(FakeDelta(), before, after, method=AttributionMethod.REAL_RAPL)
    assert res.method == "real_rapl"
    assert res.confidence == "high"
    # delta pkg = 100 J; quota albero = 25% => 25 J = 25000 mJ
    assert res.energy_mj == pytest.approx(25_000.0)
    assert res.power_w == pytest.approx(2.5)
    # split per pid proporzionale
    assert res.per_pid_energy_mj[1] == pytest.approx(20_000.0)
    assert res.per_pid_energy_mj[2] == pytest.approx(5_000.0)


def test_auto_picks_real_rapl_with_msr_source():
    from cpuepower.types import PackageEnergy

    drv = RealRaplDriver(backend=MockRaplBackend())
    est = TreeEnergyEstimator(drv)
    pkg = PackageEnergy(timestamp=0, energy_mj=5000.0, available=True,
                        source=ReadingSource.RAPL_MSR)

    class FakeDelta:
        root_pid = 1
        root_name = "x"
        window_s = 1.0
        total_cpu_s = 0.5
        system_total_cpu_s = 2.0
        cpu_fraction = 0.25
        per_pid_delta_s = {1: 0.5}
        n_processes_in_tree = 1

    chosen = est._resolve_method(AttributionMethod.AUTO, pkg, [])
    assert chosen is AttributionMethod.REAL_RAPL


def test_end_to_end_tree_with_mock_rapl():
    """Catena completa: albero processo reale (questo PID) + RAPL mock -> energia."""
    import os

    drv = RealRaplDriver(backend=MockRaplBackend(base_w=30.0))
    assert drv.probe().available
    tree = ProcessTree(os.getpid())
    snap_a = drv.read_snapshot()
    pkg_a = drv.read_package()
    # un po' di lavoro CPU nell'albero corrente
    x = sum(i * i for i in range(300_000))
    delta = measure_window(tree, window_s=0.4)
    pkg_b = drv.read_package()
    snap_b = drv.read_snapshot()
    est = TreeEnergyEstimator(drv)
    res = est.estimate(delta, pkg_a, pkg_b, method=AttributionMethod.AUTO)
    assert res.method in ("real_rapl", "tdp_estimate")
    if res.method == "real_rapl":
        assert res.energy_mj is not None and res.energy_mj >= 0
        win = drv.read_rapl_window(snap_a, snap_b)
        assert win.package_j is not None and win.package_j > 0
        assert x > 0

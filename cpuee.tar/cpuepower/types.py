"""Tipi dati condivisi tra i driver e il modulo di attribuzione."""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Dict, List, Optional


class ReadingSource(str, Enum):
    """Da dove proviene materialmente una misura/deriva di energia."""

    RAPL_MSR = "rapl_msr"              # Contatori MSR RAPL REALI (WinRing0/LHM/CIM) - Joule hardware
    WMI_MSR = "wmi_msr"                # Lettura MSR via WMI Root\wmi (RAPL esposto dal firmware)
    PDH_COUNTER = "pdh_counter"        # Performance Data Helper (% Processor Utility ecc.)
    REGISTRY_RAPL = "registry_rapl"    # Valori scritti nel registro da tool terzi (IPG, AIDA64...)
    ESTIMATED = "estimated"            # Stima CPU-time x profilo TDP
    UNKNOWN = "unknown"


@dataclass
class PackageEnergy:
    """Energia cumulativa del package CPU (domain RAPL PKG), in millijoule.

    ``energy_mj`` e' un contatore monotono: per ottenere potenza e delta energia
    bisogna fare la differenza fra due letture (vedi :mod:`cpuepower.sampler`).
    Se il valore e' assente perche' il driver non lo espone, ``available`` sara' False.
    """

    timestamp: float
    energy_mj: Optional[float]
    available: bool
    source: ReadingSource
    note: str = ""

    @classmethod
    def unavailable(cls, timestamp: float, source: ReadingSource, note: str = "") -> "PackageEnergy":
        return cls(timestamp=timestamp, energy_mj=None, available=False, source=source, note=note)


@dataclass
class CoreEnergy:
    """Energia/stato di un singolo core logico/fisico.

    I driver Windows raramente espongono energia per-core reale; spesso si ha solo
    ``perf_utility_pct`` (% Processor Utility del core, ponderato per frequenza),
    che viene usato come peso per l'attribuzione euristica.
    """

    core_id: int
    timestamp: float
    energy_mj: Optional[float] = None
    perf_utility_pct: Optional[float] = None   # 0..100, da PDH/WMI
    frequency_ghz: Optional[float] = None
    cstate_residency_ms: Optional[float] = None


@dataclass
class ProcessCpuTimes:
    """Tempi CPU (secondi) di un processo, stile GetProcessTimes/psutil."""

    pid: int
    user_s: float
    kernel_s: float

    @property
    def total_s(self) -> float:
        return self.user_s + self.kernel_s


@dataclass
class ProcessInfo:
    """Snapshot identita' + tempi CPU di un processo (nodo dell'albero)."""

    pid: int
    ppid: Optional[int]
    name: str
    create_time: float
    cpu: ProcessCpuTimes
    threads: int = 0
    num_cpus: int = 0                     # affinita' (numero di core consentiti)
    cmdline: str = ""
    children: List["ProcessInfo"] = field(default_factory=list)


@dataclass
class ProcessTreeDelta:
    """Differenziale di CPU time fra due snapshot per ogni nodo dell'albero."""

    root_pid: int
    root_name: str
    window_s: float
    per_pid_delta_s: Dict[int, float]     # pid -> secondi CPU consumati nella finestra
    per_pid_user_delta_s: Dict[int, float]
    total_cpu_s: float                    # somma dei delta dell'albero
    system_total_cpu_s: float             # somma delta di TUTTI i processi del sistema
    n_processes_in_tree: int

    @property
    def cpu_fraction(self) -> float:
        """Frazione di CPU di sistema consumata dall'albero nella finestra (0..1)."""
        if self.system_total_cpu_s <= 0:
            return 0.0
        return min(1.0, self.total_cpu_s / self.system_total_cpu_s)


@dataclass
class ProcessTreeEnergy:
    """Risultato finale: stima energia/potenza attribuibile a un albero di processo."""

    root_pid: int
    root_name: str
    window_s: float
    method: str                           # exact | apodictic | heuristic | tdp_estimate
    source: ReadingSource
    energy_mj: Optional[float]            # energia attribuita nella finestra
    power_w: Optional[float]              # potenza media nella finestra
    cpu_fraction: float                   # frazione di CPU dell'albero
    package_power_w: Optional[float]      # potenza totale package misurata (contesto)
    confidence: str                       # high | medium | low
    notes: List[str] = field(default_factory=list)
    per_pid_energy_mj: Dict[int, float] = field(default_factory=dict)

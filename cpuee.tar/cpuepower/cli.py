"""CLI: ``python -m cpuepower.cli <probe|package|tree>``."""

from __future__ import annotations

import argparse
import sys
import time

from .attribution import AttributionMethod, TreeEnergyEstimator
from .process_tree import ProcessTree, measure_window, tree_for_exe
from .sampler import EnergySampler, all_drivers, best_driver_for


def cmd_probe(_args: argparse.Namespace) -> int:
    from .msr_backends import all_backends, make_mock_backend

    print("== Backend MSR RAPL (Joule reali, come EMI) ==")
    any_real = False
    for b in all_backends():
        ok, reason = b.probe()
        print(f"[{'OK ' if ok else '-- '}] {b.name:<28} {reason}")
        any_real = any_real or ok
    if not any_real:
        print("  Suggerimento: installa pythonnet + LibreHardwareMonitorLib.dll "
              "(approccio 1), oppure carica WinRing0x64.sys (approccio 3), "
              "o verifica `Get-CimInstance -Namespace root\\wmi -ClassName "
              "ProcessorPowerMetrics` (approccio 2).")
    print("\n== Driver energia ==")
    drivers = all_drivers()
    for d in drivers:
        print(d.probe().format())
    best_pkg = best_driver_for(need_package_energy=True, drivers=drivers)
    print(f"\nBest driver for package energy: {best_pkg.name if best_pkg else 'nessuno'}")
    return 0


def cmd_package(args: argparse.Namespace) -> int:
    drivers = all_drivers()
    drv = None
    if args.driver:
        drv = next((d for d in drivers if d.name == args.driver), None)
        if drv is None:
            print(f"driver '{args.driver}' inesistente", file=sys.stderr)
            return 2
    else:
        drv = best_driver_for(True, drivers)
    if drv is None:
        print("Nessun driver disponibile", file=sys.stderr)
        return 1

    caps = drv.probe()
    print(f"Uso driver: {drv.name} ({caps.description})")

    def cb(cur, prev):
        if not cur.available:
            print(f"[{time.strftime('%H:%M:%S')}] non disponibile: {cur.note}")
            return
        if prev and prev.available and cur.timestamp > prev.timestamp:
            dt = cur.timestamp - prev.timestamp
            w = max(0.0, (cur.energy_mj or 0) - (prev.energy_mj or 0)) / 1000.0 / dt
            print(f"[{time.strftime('%H:%M:%S')}] pkg={w:7.2f} W   "
                  f"(cumulato {cur.energy_mj/1000.0:.1f} J) [{cur.note}]")
        else:
            print(f"[{time.strftime('%H:%M:%S')}] baseline: cumulato "
                  f"{cur.energy_mj/1000.0:.1f} J [{cur.note}]")

    sampler = EnergySampler(drv, interval_s=args.interval, on_sample=cb)
    sampler.start()
    try:
        for _ in range(args.count):
            time.sleep(args.interval)
    except KeyboardInterrupt:
        pass
    finally:
        sampler.stop()
    return 0


def cmd_tree(args: argparse.Namespace) -> int:
    method = AttributionMethod(args.method)
    trees = []
    if args.pid:
        trees = [ProcessTree(args.pid)]
    elif args.exe:
        trees = tree_for_exe(args.exe)
        if not trees:
            print(f"Nessun processo con nome {args.exe!r}", file=sys.stderr)
            return 1
    else:
        print("specificare --pid oppure --exe", file=sys.stderr)
        return 2

    drv = None
    if getattr(args, "mock", False):
        # carico un po' di CPU cosi' la frazione albero > 0 e la demo e' significativa
        import threading as _th

        def _burn(sec):
            t0 = time.time()
            while time.time() - t0 < sec:
                pass
        _th.Thread(target=_burn, args=(args.window + 0.5,), daemon=True).start()

        from .drivers.rapl_msr import RealRaplDriver
        from .msr_backends import make_mock_backend

        drv = RealRaplDriver(backend=make_mock_backend(base_w=15.0))
    elif args.driver:
        drv = next((d for d in all_drivers() if d.name == args.driver), None)
    if drv is None:
        drv = best_driver_for(True)
    estimator = TreeEnergyEstimator(drv, tdp_w=args.tdp)

    snap_before = snap_after = None
    if getattr(drv, "read_snapshot", None) is not None:
        # driver RAPL reale: catturiamo gli snapshot MSR per il delta multi-dominio
        snap_before = drv.read_snapshot()

    for tree in trees:
        root_info = tree.nodes.get(tree.root_pid)
        root_name = root_info.name if root_info else "?"
        print(f"\n=== Albero pid {tree.root_pid} ({root_name}) ===")
        if args.verbose:
            print(tree.describe())
        # letture package prima/dopo la finestra
        a = drv.read_package() if hasattr(drv, "read_package") else None
        delta = measure_window(tree, window_s=args.window)
        b = drv.read_package() if hasattr(drv, "read_package") else None
        from .types import PackageEnergy, ReadingSource
        a = a or PackageEnergy.unavailable(time.time(), ReadingSource.UNKNOWN)
        b = b or PackageEnergy.unavailable(time.time(), ReadingSource.UNKNOWN)
        res = estimator.estimate(delta, a, b, method=method)
        print(f"metodo usato     : {res.method}")
        print(f"sorgente         : {res.source.value}")
        print(f"processi albero  : {delta.n_processes_in_tree}")
        print(f"CPU albero       : {delta.total_cpu_s:.3f} s su {delta.system_total_cpu_s:.3f} s "
              f"di sistema ({res.cpu_fraction*100:.1f}%)")
        if res.power_w is not None:
            print(f"potenza stimata  : {res.power_w:.2f} W")
        if res.energy_mj is not None:
            print(f"energia stimata  : {res.energy_mj:.1f} mJ nella finestra di {res.window_s:.1f} s")
        if res.package_power_w is not None:
            print(f"potenza package  : {res.package_power_w:.2f} W (contesto)")
        if snap_before is not None and getattr(drv, "read_rapl_window", None):
            snap_after = drv.read_snapshot()
            win = drv.read_rapl_window(snap_before, snap_after)
            dom = []
            for name, val in (("PKG", win.package_j), ("PP0", win.pp0_j),
                              ("PP1", win.pp1_j), ("DRAM", win.dram_j)):
                if val is not None:
                    dom.append(f"{name}={val:.3f} J")
            if dom:
                print("contatori RAPL   : " + "  ".join(dom) + f"  [{win.window_s:.2f} s]")
            if win.wrapped_domains:
                print(f"  wrap-around rilevato su: {', '.join(win.wrapped_domains)} (gestito)")
        print(f"confidenza       : {res.confidence}")
        for n in res.notes:
            print(f"  note: {n}")
        if res.per_pid_energy_mj and args.verbose:
            for pid, mj in sorted(res.per_pid_energy_mj.items(), key=lambda kv: -kv[1]):
                print(f"    pid {pid}: {mj:.2f} mJ")
    return 0


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(prog="cpuepower",
                                     description="Driver energia CPU Windows + attribuzione ad alberi di processo")
    sub = parser.add_subparsers(dest="cmd", required=True)

    p_probe = sub.add_parser("probe", help="mostra backend MSR + driver disponibili")
    p_probe.add_argument("--mock", action="store_true", help=argparse.SUPPRESS)
    p_probe.set_defaults(fn=cmd_probe)

    p_pkg = sub.add_parser("package", help="leggi consumo package CPU")
    p_pkg.add_argument("--interval", type=float, default=1.0)
    p_pkg.add_argument("--count", type=int, default=10)
    p_pkg.add_argument("--driver", type=str, default=None)
    p_pkg.set_defaults(fn=cmd_package)

    p_tree = sub.add_parser("tree", help="isola il consumo di un albero di processo")
    g = p_tree.add_mutually_exclusive_group(required=True)
    g.add_argument("--pid", type=int)
    g.add_argument("--exe", type=str)
    p_tree.add_argument("--window", type=float, default=5.0,
                        help="durata finestra di misura in secondi")
    p_tree.add_argument("--method", choices=[m.value for m in AttributionMethod],
                        default="auto")
    p_tree.add_argument("--tdp", type=float, default=None,
                        help="forza profilo TDP (W) per tdp_estimate")
    p_tree.add_argument("--driver", type=str, default=None,
                        help="rapl_msr | wmi_msr | pdh | estimate ... "
                             "(default: auto, con priorita' ai Joule reali MSR)")
    p_tree.add_argument("--mock", action="store_true",
                        help="usa backend RAPL sintetico (demo/test senza hardware)")
    p_tree.add_argument("-v", "--verbose", action="store_true")
    p_tree.set_defaults(fn=cmd_tree)

    args = parser.parse_args(argv)
    return args.fn(args)


if __name__ == "__main__":
    raise SystemExit(main())

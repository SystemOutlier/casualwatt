"""Attribuzione dell'energia CPU (misurata a livello package) a un albero di processo.

Strategie implementate (enum :class:`AttributionMethod`):

* ``APPODICTIC``  — ripartizione lineare per frazione di CPU time:
      E_tree = E_pkg_delta * (cpu_tree / cpu_all)
  Richiede una misura reale di E_pkg (driver wmi_msr/rapl_registry) oppure la stima
  integrale del driver estimate.

* ``HEURISTIC``   — come apodictic ma pesa i core: ogni core contribuisce con la
  propria utility % (da PDH/WMI); l'albero viene distribuito sui core in proporzione
  alla somma dei tempi CPU dei suoi processi "assegnati" ai core (psutil non fornisce
  affinita' corrente thread→core, quindi si usa il numero di core consentiti dal mask
  di affinita' come proxy). Utile quando l'albero e' confinato su pochi core.

* ``TDP_ESTIMATE``— ignora il resto del sistema: potenza diretta dell'albero da
  profilo TDP e dalla sua *densita'* di utilizzo (cpu_tree_s / window_s / n_core_allocati):
      P_tree = idle_share + active_frac * (P_max - P_idle)
  dove active_frac = min(1, cpu_per_core_media). Funziona anche senza alcun driver
  Windows: serve solo psutil.

* ``AUTO``        — sceglie automaticamente il migliore disponibile:
  exact se il driver lo consente, altrimenti heuristic se ci sono metriche per-core,
  altrimenti apodictic, altrimenti tdp_estimate.
"""

from __future__ import annotations

import enum
from typing import Dict, List, Optional

from .drivers.base import EnergyDriver
from .process_tree import ProcessTreeDelta
from .types import PackageEnergy, ProcessTreeEnergy, ReadingSource


class AttributionMethod(str, enum.Enum):
    AUTO = "auto"
    REAL_RAPL = "real_rapl"      # alias retro-compatibile -> CPU_TIME_SHARE (STIMA!)
    CPU_TIME_SHARE = "cpu_time_share"  # E_inc = (E_pkg - P_base*dt) * frazione: MODELLO low-conf
    APPODICTIC = "apodictic"
    HEURISTIC = "heuristic"
    TDP_ESTIMATE = "tdp_estimate"


#: Frase OBBLIGATORIA da stampare quando si usa cpu_time_share/real_rapl
#: (brief MINI_IT13 P0-6): Windows non espone energia per-processo.
CPU_TIME_SHARE_DISCLAIMER = ("Windows non espone energia per-processo: questo e' un modello")

#: Valore di default del floor idle package in W (terra MINI_IT13: 16,9 W idle).
DEFAULT_BASE_PACKAGE_W = 16.9

#: Soglie di validazione della scalinata A-B-A vs EMI (P0-6).
VALIDATION_TOLERANCE_REL = 0.20     # ±20% sul Δ EMI
VALIDATION_MIN_SIGNAL_J = 5.0       # sotto 5 J di segnale il test non e' significativo


def _is_real_package_source(pkg: PackageEnergy) -> bool:
    """True se il PackageEnergy proviene da un VERO contatore RAPL hardware.

    Esclude esplicitamente (P0-5/P1-1):
      * backend LHM in power-integration (source="power_integration");
      * mock (source="mock", snapshot.is_mock);
      * WinRing0 su macchine dove l'ioctl RdMSR non risponde (probe fallito =>
        il PackageEnergy non arriva comunque dal driver rapl_msr).
    """
    try:
        src = getattr(pkg.source, "value", str(pkg.source))
    except Exception:
        src = str(pkg.source)
    if src == "rapl_msr":
        drv = getattr(pkg, "_driver", None) or getattr(pkg, "driver", None)
        be = getattr(drv, "_backend", None) if drv is not None else None
        if be is not None:
            from .msr_backends import backend_provides_real_energy

            real, _reason = backend_provides_real_energy(be)
            return real
        snap_src = getattr(pkg, "snapshot_source", None)
        if snap_src in ("power_integration", "mock"):
            return False
        return True
    return False


class TreeEnergyEstimator:
    """Stima energia/potenza di un albero dato il delta CPU e le letture del driver."""

    def __init__(self, driver: EnergyDriver, tdp_w: Optional[float] = None,
                 idle_w: Optional[float] = None,
                 base_package_w: Optional[float] = None) -> None:
        self.driver = driver
        self.tdp_w = tdp_w
        self.idle_w = idle_w
        #: floor idle package (W) per il differenziale A-B-A (P0-6). Su MINI_IT13
        #: valore di terra misurato via EMI: 16,9 W. Se None, stimato da idle_w/TDP.
        self.base_package_w = base_package_w

    # ------------------------------------------------------------------ public
    def estimate(self, delta: ProcessTreeDelta,
                 pkg_before: PackageEnergy, pkg_after: PackageEnergy,
                 method: AttributionMethod = AttributionMethod.AUTO) -> ProcessTreeEnergy:
        notes: List[str] = []
        chosen = self._resolve_method(method, pkg_after, notes)

        if chosen is AttributionMethod.TDP_ESTIMATE:
            result = self._tdp_estimate(delta, notes)
        elif chosen in (AttributionMethod.REAL_RAPL, AttributionMethod.CPU_TIME_SHARE):
            result = self._cpu_time_share(delta, pkg_before, pkg_after, notes)
        elif chosen is AttributionMethod.HEURISTIC:
            result = self._heuristic(delta, pkg_before, pkg_after, notes)
        else:
            result = self._apodictic(delta, pkg_before, pkg_after, notes)

        result.method = chosen.value
        return result

    def _resolve_method(self, requested: AttributionMethod, pkg: PackageEnergy,
                        notes: List[str]) -> AttributionMethod:
        # P0-5: real_rapl NON deve poter girare su backend che non forniscono un
        # vero contatore package (LHM power_integration, mock, WinRing0 rotto).
        real_pkg = _is_real_package_source(pkg)
        if requested in (AttributionMethod.REAL_RAPL, AttributionMethod.CPU_TIME_SHARE):
            if not pkg.available:
                notes.append("cpu_time_share richiede contatore package reale: fallback")
                return AttributionMethod.TDP_ESTIMATE
            if not real_pkg:
                notes.append(
                    "RIFIUTATO real_rapl: il backend corrente NON fornisce un contatore "
                    "package RAPL hardware reale (power_integration/mock/backend non "
                    "validato vs EMI). Uso cpu_time_share sul differenziale: STIMA a "
                    "bassa confidenza, non una misura.")
            return AttributionMethod.CPU_TIME_SHARE
        if requested is not AttributionMethod.AUTO:
            if requested in (AttributionMethod.APPODICTIC, AttributionMethod.HEURISTIC) \
                    and not pkg.available:
                notes.append(f"{requested.value}: pacchetto energia non disponibile, "
                             f"fallback a tdp_estimate")
                return AttributionMethod.TDP_ESTIMATE
            return requested
        if pkg.available:
            if pkg.source is ReadingSource.RAPL_MSR and real_pkg:
                # contatore hardware reale: frazione CPU applicata al differenziale
                return AttributionMethod.CPU_TIME_SHARE
            cores = self.driver.read_cores()
            if any(c.perf_utility_pct is not None for c in cores):
                return AttributionMethod.HEURISTIC
            return AttributionMethod.APPODICTIC
        notes.append("nessun driver con energia package reale: uso tdp_estimate")
        return AttributionMethod.TDP_ESTIMATE

    # ------------------------------------------------------------- strategies
    def _real_rapl(self, delta: ProcessTreeDelta, before: PackageEnergy,
                   after: PackageEnergy, notes: List[str]) -> ProcessTreeEnergy:
        """Formula finale EMI-style:

            E_tree = E_pkg_REALE_delta * (CPU_time_albero / CPU_time_sistema)

        ``E_pkg_REALE_delta`` viene dai contatori MSR (J), non da stime.
        Se il driver espone anche PP0/DRAM, li riportiamo nei notes per debug.
        """
        frac = delta.cpu_fraction
        energy_mj = None
        power_w = None
        if before.available and after.available:
            d_j = max(0.0, ((after.energy_mj or 0.0) - (before.energy_mj or 0.0)) / 1000.0)
            energy_mj = d_j * frac * 1000.0
            power_w = energy_mj / 1000.0 / delta.window_s if delta.window_s > 0 else None
            notes.append(f"RAPL reale: E_pkg_delta={d_j:.4f} J (MSR), "
                         f"cpu_tree={delta.total_cpu_s:.3f}s / cpu_sys="
                         f"{delta.system_total_cpu_s:.3f}s -> frac={frac:.4f}")
            confidence = "high"
        else:
            notes.append("real_rapl senza contatore package: impossibile attribuire")
            confidence = "low"
        return ProcessTreeEnergy(
            root_pid=delta.root_pid, root_name=delta.root_name, window_s=delta.window_s,
            method="real_rapl", source=after.source, energy_mj=energy_mj, power_w=power_w,
            cpu_fraction=frac, package_power_w=self._pkg_power(before, after),
            confidence=confidence, notes=notes,
            per_pid_energy_mj=self._split_per_pid(energy_mj, delta),
        )

    def _apodictic(self, delta: ProcessTreeDelta, before: PackageEnergy,
                   after: PackageEnergy, notes: List[str]) -> ProcessTreeEnergy:
        frac = delta.cpu_fraction
        energy_mj = None
        power_w = None
        if before.available and after.available:
            d_mj = max(0.0, (after.energy_mj or 0.0) - (before.energy_mj or 0.0))
            energy_mj = d_mj * frac
            power_w = energy_mj / 1000.0 / delta.window_s if delta.window_s > 0 else None
            notes.append(f"E_pkg_delta={d_mj:.1f} mJ, frazione_cpu={frac:.3f}")
            confidence = "medium"
        else:
            notes.append("energia package non disponibile: frazione calcolata ma non applicata")
            confidence = "low"
        return ProcessTreeEnergy(
            root_pid=delta.root_pid, root_name=delta.root_name, window_s=delta.window_s,
            method="apodictic", source=after.source, energy_mj=energy_mj, power_w=power_w,
            cpu_fraction=frac, package_power_w=self._pkg_power(before, after),
            confidence=confidence, notes=notes,
            per_pid_energy_mj=self._split_per_pid(energy_mj, delta),
        )

    def _heuristic(self, delta: ProcessTreeDelta, before: PackageEnergy,
                   after: PackageEnergy, notes: List[str]) -> ProcessTreeEnergy:
        """Utility per-core come pesi; quota dell'albero stimata per core."""
        frac = delta.cpu_fraction
        cores = self.driver.read_cores()
        energy_mj = None
        power_w = None
        if before.available and after.available:
            d_mj = max(0.0, (after.energy_mj or 0.0) - (before.energy_mj or 0.0))
            utils = [c.perf_utility_pct or 0.0 for c in cores]
            total_u = sum(utils)
            if total_u > 0 and len(utils) > 0:
                # Energia "dinamica" attribuita in proporzione all'utilità dei core
                # su cui l'albero lavora. Proxy: assumiamo che i core piu' attivi siano
                # anche quelli occupati dall'albero se la sua densita' e' alta.
                density = delta.total_cpu_s / max(1e-9, delta.window_s * max(len(utils), 1))
                weighted = min(1.0, density) * (total_u / (100.0 * len(utils)))
                energy_mj = d_mj * max(frac, weighted * frac)
                notes.append(f"heuristic: density={density:.2f} util_mean={total_u/len(utils):.1f}%")
            else:
                energy_mj = d_mj * frac
                notes.append("heuristic: utility core assenti, degradato ad apodictic")
            power_w = energy_mj / 1000.0 / delta.window_s if delta.window_s > 0 else None
            confidence = "medium"
        else:
            confidence = "low"
            notes.append("heuristic senza energia package: nessuna attribuzione assoluta")
        return ProcessTreeEnergy(
            root_pid=delta.root_pid, root_name=delta.root_name, window_s=delta.window_s,
            method="heuristic", source=after.source, energy_mj=energy_mj, power_w=power_w,
            cpu_fraction=frac, package_power_w=self._pkg_power(before, after),
            confidence=confidence, notes=notes,
            per_pid_energy_mj=self._split_per_pid(energy_mj, delta),
        )

    def _tdp_estimate(self, delta: ProcessTreeDelta,
                      notes: List[str]) -> ProcessTreeEnergy:
        tdp = self.tdp_w
        idle = self.idle_w
        if tdp is None:
            est = getattr(self.driver, "_lookup_tdp", None)
            tdp = est() if callable(est) else 65.0
            idle = self.driver.__dict__.get("_idle_w") if hasattr(self.driver, "_idle_w") else None
        if idle is None:
            idle = max(2.0, 0.15 * tdp)
        n_cores = max(1, (self.driver.read_cores().__len__() or 1)
                      if hasattr(self.driver, "read_cores") else 1)
        try:
            import os

            n_cores = os.cpu_count() or n_cores
        except Exception:
            pass
        # busy fraction: secondi CPU per core allocabile nella finestra
        active_frac = min(1.0, delta.total_cpu_s / max(1e-9, delta.window_s * n_cores))
        power_w = idle + active_frac * (tdp - idle)
        energy_mj = power_w * delta.window_s * 1000.0
        notes.append(f"tdp_estimate: TDP={tdp:.0f}W idle={idle:.1f}W "
                     f"active_frac={active_frac:.3f} cores={n_cores}")
        return ProcessTreeEnergy(
            root_pid=delta.root_pid, root_name=delta.root_name, window_s=delta.window_s,
            method="tdp_estimate", source=ReadingSource.ESTIMATED,
            energy_mj=energy_mj, power_w=power_w, cpu_fraction=delta.cpu_fraction,
            package_power_w=None, confidence="low", notes=notes,
            per_pid_energy_mj=self._split_per_pid(energy_mj, delta),
        )

    # ---------------------------------------------------------------- helpers
    @staticmethod
    def _pkg_power(before: PackageEnergy, after: PackageEnergy) -> Optional[float]:
        if before.available and after.available and after.timestamp > before.timestamp:
            dt = after.timestamp - before.timestamp
            d_mj = max(0.0, (after.energy_mj or 0.0) - (before.energy_mj or 0.0))
            return d_mj / 1000.0 / dt
        return None

    @staticmethod
    def _split_per_pid(total_mj: Optional[float],
                       delta: ProcessTreeDelta) -> Dict[int, float]:
        if total_mj is None or delta.total_cpu_s <= 0:
            return {}
        out: Dict[int, float] = {}
        for pid, d in delta.per_pid_delta_s.items():
            out[pid] = total_mj * (d / delta.total_cpu_s)
        return out

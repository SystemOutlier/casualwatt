"""Backend di trasporto per la lettura reale degli MSR RAPL su Windows.

Windows NON espone gli MSR in user-mode: serve un driver kernel firmato che faccia
``RDMSR``/``WRMSR`` al posto nostro. Questo modulo astrae il "come" si leggono i
raw counter, fornendo tre backend concrete piu' una mock per i test:

1. :class:`WinRing0Backend` (RdMSR diretto = parita' con EMI)
   Win32 ``CreateFile(.\\\\WINRING0)`` + DeviceIoControl RdMsr, come il vecchio
   OpenHardwareMonitor. Legge direttamente 0x606 e i contatori 0x611/0x639/0x641/
   0x619 -> vera parita' con EMI. ATENZIONE (brief MINI_IT13 P0-4): su quella
   macchina CreateFile riesce ma l'ioctl RDMSR fallisce perche' WINRING_RDMSR_IOCTL
   qui sotto e' una congettura (CTL_CODE generico), non l'interfaccia del .sys
   installato; inoltre WinRing0 e' nella Vulnerable Driver Blocklist/HVCI. Il
   backend va considerato NON FUNZIONANTE finche' non supera il criterio di
   accettazione: delta(0x611)*joule_unit concorde con delta PKG EMI entro il 2%.

2. :class:`LibreHardwareMonitorBackend` -- POWER-INTEGRATION, non MSR reali
   LHM via pythonnet espone sensori Power (Watt istantanei); su molti SKU (es.
   i9-13900HK) NON espone alcun sensore Energy. Noi accumuliamo val*dt: il
   risultato e' un'integrazione numerica della potenza, NON un contatore hardware.
   Per questo ``source="power_integration"`` e ``provides_package_energy=False``:
   l'attribuzione REAL_RAPL deve rifiutare questo backend (vedi attribution.py).
   NB operativo: se convive con energy_session.SESSION di CWProject, usare UN'unica
   istanza Computer() condivisa (set_shared_computer): aprirne una seconda
   raddoppia il costo di hw.Update() e degrada la risoluzione gia' misurata a 0,32 s.

3. :class:`CimProcessorPowerMetricsBackend` (nativo, zero driver)
   Interroga root\\wmi CIM ``ProcessorPowerMetrics`` / MSAcpi_PowerMeter: se il
   firmware lo popola, fornisce contatori energia cumulativi nativi. probe() non
   deve MAI sollevare (P0-1: su win32com le proprieta' si scoprono con
   Properties_, non __properties__; usiamo scoperta difensiva multi-source).

Ogni backend implementa il protocollo :class:`MsrBackend` e ritorna un
:class:`~cpuepower.rapl_units.RaplSnapshot`. La funzione :func:`select_backend`
fa il probe di tutti e restituisce il migliore disponibile; :func:`make_mock_backend`
serve per girare la pipeline su Linux/nei test: i suoi output portano SEMPRE
source="mock" e banner esplicito (P1-1).
"""

from __future__ import annotations

import ctypes
import math
import time
from dataclasses import dataclass
from typing import Dict, List, Optional, Protocol

from .rapl_units import (
    PKG_UNIT_MSR,
    RAPL_MSR_ADDRESSES,
    RaplSnapshot,
    RaplUnits,
)


class MsrBackend(Protocol):
    """Protocollo minimo: probe() -> bool, read_snapshot() -> RaplSnapshot|None.

    ``probe()`` DEVE sempre ritornare una tupla (bool, str) e non sollevare mai
    (brief MINI_IT13 P0-1): la cascata di selezione deve degradare, non crashare.
    """

    name: str

    def probe(self) -> tuple[bool, str]: ...

    def read_snapshot(self) -> Optional[RaplSnapshot]: ...

    def close(self) -> None:
        return None


def safe_probe(backend) -> tuple[bool, str]:
    """Richiama backend.probe() garantendo (bool, str) anche in caso di eccezione."""
    try:
        ok, reason = backend.probe()
        return bool(ok), str(reason)
    except Exception as exc:  # pragma: no cover - rete di sicurezza
        return False, f"probe() ha sollevato {type(exc).__name__}: {exc}"


#: Istanza Computer() LHM condivisa (criterio operativo MINI_IT13 P0-5): se il
#: modulo deve convivere con energy_session.SESSION del progetto CWProject, il
#: chiamante passa QUI la propria istanza tramite set_shared_computer(), cosi'
#: hw.Update() non viene raddoppiato da un secondo Computer().
_SHARED_LHM_COMPUTER = None


def set_shared_computer(computer) -> None:
    """Inietta un oggetto ``Computer`` LHM gia' aperto e condiviso con altri moduli."""
    global _SHARED_LHM_COMPUTER
    _SHARED_LHM_COMPUTER = computer


def get_shared_computer():
    return _SHARED_LHM_COMPUTER


# --------------------------------------------------------------------------- #
# 1) LibreHardwareMonitor via pythonnet                                          #
# --------------------------------------------------------------------------- #
class LibreHardwareMonitorBackend:
    """Sensori LHM via pythonnet: POWER-INTEGRATION, NON contatori MSR reali.

    Su MINI_IT13 (i9-13900HK) e' stato misurato che LHM non espone alcun sensore
    ``Energy``: read_snapshot() accumula quindi P(t)*dt. Il snapshot risultante
    porta ``source="power_integration"`` e il backend dichiara
    ``provides_package_energy = False``, cosi' l'attribuzione REAL_RAPL lo
    rifiuta (vedi attribution.py). Se in futuro un dominio Energy vero apparisse,
    il snapshot uscirebbe con source="librehardwaremonitor_energy_msr".

    Convivenza con energy_session.SESSION (CWProject): usare set_shared_computer()
    con l'istanza Computer() gia' aperta; aprirne una seconda raddoppia il costo
    di hw.Update() e peggiora la risoluzione temporale dell'integrazione.
    """

    name = "librehardwaremonitor"
    #: onesta' etichetta (P0-5): integrazione numerica, non contatore hardware
    provides_package_energy = False
    SOURCE_LABEL = "power_integration"

    #: Mappatura nome sensore LHM -> dominio RAPL (chiave = sottostringa nel nome sensore)
    SENSOR_MAP = {
        "cpu package": "package",
        "package": "package",
        "cpu cores": "pp0",
        "core (physical)": "pp0",
        "cpu graphics": "pp1",
        "cpu uncore": "pp1",
        "memory": "dram",
        "dram": "dram",
    }

    def __init__(self, dll_path: Optional[str] = None) -> None:
        self._dll_path = dll_path
        self._computer = None
        self._opened = False
        self._owns_computer = True
        # stato di integrazione potenza -> energia (NOTA: e' power-integration,
        # non un contatore hardware: vedi SOURCE_LABEL e provides_package_energy)
        self._last_ts: Optional[float] = None
        self._accum_j: Dict[str, float] = {}

    def _load_clr(self):
        import clr  # noqa: F401 - pythonnet (registra gli assembly .NET)

        return clr

    def open(self) -> None:
        if self._opened:
            return
        shared = get_shared_computer()
        if shared is not None:
            # istanza condivisa con energy_session.SESSION: NON apriamo/chiudiamo
            # un secondo Computer() (raddoppia hw.Update(), P0-5).
            self._computer = shared
            self._owns_computer = False
            self._opened = True
            return
        clr = self._load_clr()
        if self._dll_path:
            clr.AddReferenceToFileAndPath(self._dll_path)
        else:
            clr.AddReference("LibreHardwareMonitorLib")
        from LibreHardwareMonitor.Hardware import Computer  # type: ignore

        self._computer = Computer(
            IsCpuEnabled=True, IsGpuEnabled=False, IsMemoryEnabled=True,
            IsMotherboardEnabled=False, IsControllerEnabled=False,
            IsNetworkEnabled=False, IsStorageEnabled=False,
        )
        self._computer.Open()
        self._owns_computer = True
        self._opened = True

    def probe(self):
        import sys
        if sys.platform != "win32":
            return False, "LibreHardwareMonitor (pythonnet) disponibile solo su Windows"
        try:
            self.open()
        except Exception as exc:  # pragma: no cover - dipende da DLL/hardware
            return False, f"pythonnet/LHM non disponibile: {exc}"
        snap = self.read_snapshot()
        if snap is None or snap.counters.get("package") is None:
            self.close()
            return False, "LHM caricato ma nessun sensore CPU Power/Energy trovato (non-Intel?)"
        if snap.source == self.SOURCE_LABEL:
            return True, ("LHM OK MA SOLO power-integration (nessun sensore Energy: "
                          "su i9-13900HK misurato assente) - NON Joule MSR reali")
        return True, "LHM OK con sensori Energy nativi"

    def _iter_sensors(self):
        for i in range(self._computer.Hardware.Count):
            hw = self._computer.Hardware.Item[i]
            for j in range(hw.Sensors.Count):
                yield hw.Sensors.Item[j]
            # LHM espone i sensori anche annidati (sub-hardware)
            for k in range(hw.SubHardware.Count):
                sub = hw.SubHardware.Item[k]
                for j in range(sub.Sensors.Count):
                    yield sub.Sensors.Item[j]

    def read_snapshot(self) -> Optional[RaplSnapshot]:
        if not self._opened:
            self.open()
        # Fallback dichiarato: pkg_unit client (0x000A0E03). Se LHM in futuro
        # exposesse il raw pkg_unit, sostituirlo qui con RaplUnits.from_msr().
        units = RaplUnits.default_client()
        now = time.monotonic()
        dt = 0.0 if self._last_ts is None else max(0.0, now - self._last_ts)
        self._last_ts = now

        power_w: Dict[str, float] = {}     # watt istantanei per dominio
        energy_raw: Dict[str, int] = {}    # contatori Energy nativi (rari: assenti sul 13900HK)
        for sensor in self._iter_sensors():
            try:
                stype = str(sensor.Type)       # "Power" | "Energy" | ...
                sname = str(sensor.Name).lower()
                val = float(sensor.Value)
            except Exception:
                continue
            if val <= 0:
                continue
            dom = None
            for key, d in self.SENSOR_MAP.items():
                if key in sname:
                    dom = d
                    break
            if dom is None:
                continue
            if stype == "Energy":
                # LHM espone gia' un contatore cumulativo in J (raro): usalo raw.
                energy_raw[dom] = int(round(val / units.joule_unit_j))
            elif stype == "Power":
                # CASO COMUNE su MINI_IT13: integrazione numerica P*dt (NON MSR).
                self._accum_j[dom] = self._accum_j.get(dom, 0.0) + val * dt
                power_w.setdefault(dom, val)

        source_counters: Dict[str, Optional[int]] = {}
        for dom in ("package", "pp0", "pp1", "dram", "platform"):
            if dom in energy_raw:
                source_counters[dom] = energy_raw[dom]
            elif dom in self._accum_j:
                source_counters[dom] = int(round(self._accum_j[dom] / units.joule_unit_j))
            else:
                source_counters[dom] = None
        if source_counters["package"] is None:
            return None
        real_energy = bool(energy_raw)
        snap = RaplSnapshot(
            ts=now, units=units, counters=source_counters,
            # etichetta onesta (P0-5): power_integration finche' non vediamo sensori Energy
            source=("librehardwaremonitor_energy_msr" if real_energy
                    else self.SOURCE_LABEL),
        )
        snap.note_power_w = power_w  # tipo: annotazione dinamica per debug
        return snap

    def close(self) -> None:
        if self._opened and self._computer is not None and self._owns_computer:
            try:
                self._computer.Close()
            except Exception:
                pass
        # se l'istanza e' condivisa (set_shared_computer) NON la chiudiamo:
        # e' di proprieta' del chiamante (energy_session.SESSION).
        self._opened = False


# --------------------------------------------------------------------------- #
# 2) WinRing0 / inpoutx64 : RdMSR diretto                                        #
# --------------------------------------------------------------------------- #
# ATENZIONE (brief MINI_IT13 P0-4): WINRING_RDMSR_IOCTL qui sotto e' stato
# COSTRUITO con la macro CTL_CODE in modo generico ed E' UNA CONGETTURA: su
# MINI_IT13 CreateFile(\\.\WINRING0) riesce ma DeviceIoControl(RdMSR 0x606)
# FALLISCE, quindi il codice non corrisponde a WinRing0x64.sys installato.
# L'interfaccia reale del sorgente OpenHardwareMonitor (WinRing0/Io.h) e':
#     IOCTL_WINRING_RDMSR = CTL_CODE(FILE_DEVICE_UNKNOWN, 0x800,
#                                    METHOD_BUFFERED, FILE_READ_ACCESS)
# che e' il valore che usiamo; se il .sys sul sistema e' una variante diversa
# (es. build inpoutx64 o driver OEM), il numero cambia e va preso dal sorgente
# ESATTO di quel driver, non tirato a indovinare. Inoltre WinRing0 e' nella
# Microsoft Vulnerable Driver Blocklist: con HVCI/WDAC attivo il caricamento o
# l'uso viene bloccato a prescindere.
# CRITERIO DI ACCETTAZIONE UNICO AMMISSIBILE (P0-4): nella stessa finestra di
# 30 s, delta(MSR 0x611) * joule_unit deve concordare con delta PKG EMI entro
# il 2%. Finche' non converge, il backend va marciao NON FUNZIONANTE su questa
# CPU (probe ritorna False con motivo esplicito), mai "consigliato".
def _ctl_code(device_type: int, function: int, method: int, access: int) -> int:
    return (device_type << 16) | (access << 14) | (function << 2) | method


FILE_DEVICE_UNKNOWN = 0x00000022
METHOD_BUFFERED = 0
FILE_ANY_ACCESS = 0
FILE_READ_ACCESS = 1
WINRING_RDMSR_IOCTL = _ctl_code(FILE_DEVICE_UNKNOWN, 0x800, METHOD_BUFFERED, FILE_READ_ACCESS)

#: Criterio di validazione obbligatoria contro il contatore EMI nativo (P0-4).
EMI_CONCORDANCE_TOLERANCE = 0.02  # 2%


class EmiReferenceReader:
    """Lettore del contatore EMI nativo di riferimento su MINI_IT13 (CWProject).

    Device interface: \\\\?\\acpi#genuineintel_-_intel64_...i9-13900hk#0#{GUID}
    IOCTL_EMI_GET_MEASUREMENT = 0x22400C, 4 record da 16 byte:
      - PKG a offset 0 (poi cores/gpu/dram negli altri record, vedi EMI spec)
      - energia in pWh  -> J = pWh * 3.6e-9
      - tempo in unita' da 100 ns
    Non richiede privilegi admin ne' driver aggiuntivi: e' il GOLD STANDARD con
    cui validare qualsiasi altra sorgente su questa macchina.
    """

    DEVICE_PATH = (r"\\?\ACPI#GenuineIntel_-_Intel64_Family_6_Model_183_"
                   r"Intel_Core_i9-13900HK#0#{45bd8344-185b-4fe6-b370-435a024e7ca0}")
    IOCTL_EMI_GET_MEASUREMENT = 0x22400C
    RECORD_SIZE = 16
    N_RECORDS = 4
    PWH_TO_J = 3.6e-9          # 1 pWh = 3.6e-9 J (validato: idle 16.9 W coerenti)
    TIME_UNIT_S = 1e-7         # tick da 100 ns
    PKG_RECORD_INDEX = 0       # PKG a offset 0

    def __init__(self, device_path: Optional[str] = None) -> None:
        self.device_path = device_path or self.DEVICE_PATH
        self._handle = None

    def open(self) -> None:
        import sys
        if sys.platform != "win32":
            raise OSError("EMI disponibile solo su Windows")
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)
        GENERIC_READ = 0x80000000
        OPEN_EXISTING = 3
        h = kernel32.CreateFileW(self.device_path, GENERIC_READ, 0, None,
                                 OPEN_EXISTING, 0, None)
        INVALID = ctypes.c_void_p(-1).value
        if h == INVALID or h == 0:
            raise OSError(f"CreateFile(EMI) fallito err={ctypes.get_last_error()}")
        self._kernel32 = kernel32
        self._handle = h

    def read_pkg_joules(self) -> tuple[float, float]:
        """Ritorna (energia PKG cumulativa in J, timestamp grezzo in s)."""
        if self._handle is None:
            self.open()
        buf = ctypes.create_string_buffer(self.RECORD_SIZE * self.N_RECORDS)
        ret = ctypes.c_uint32(0)
        ok = self._kernel32.DeviceIoControl(
            self._handle, self.IOCTL_EMI_GET_MEASUREMENT,
            None, 0, buf, len(buf), ctypes.byref(ret), None,
        )
        if not ok:
            raise OSError(f"IOCTL_EMI_GET_MEASUREMENT fallito "
                          f"err={ctypes.get_last_error()}")
        off = self.PKG_RECORD_INDEX * self.RECORD_SIZE
        energy_pwh = int.from_bytes(buf.raw[off:off + 8], "little", signed=False)
        time_raw = int.from_bytes(buf.raw[off + 8:off + 16], "little", signed=False)
        return energy_pwh * self.PWH_TO_J, time_raw * self.TIME_UNIT_S

    def close(self) -> None:
        if getattr(self, "_handle", None) not in (None, 0):
            try:
                self._kernel32.CloseHandle(self._handle)
            except Exception:
                pass
            self._handle = None


def validate_against_emi(measure_fn, window_s: float = 30.0,
                        tolerance: float = EMI_CONCORDANCE_TOLERANCE):
    """Valida una sorgente RAPL contro il delta PKG EMI sulla stessa finestra.

    ``measure_fn`` e' un callable che ritorna il delta package in Joule misurato
    dalla sorgente in esame sulla finestra ``window_s``. Ritorna
    ``(concorda: bool, delta_rapl_j, delta_emi_j, scarto_rel)`` oppure
    ``(False, None, None, motivo)`` se EMI non e' leggibile.
    """
    emi = EmiReferenceReader()
    try:
        e0, t0 = emi.read_pkg_joules()
        rapl_delta = measure_fn(window_s)
        e1, t1 = emi.read_pkg_joules()
    except Exception as exc:
        return False, None, None, f"EMI non leggibile: {exc}"
    finally:
        emi.close()
    d_emi = max(0.0, e1 - e0)
    if d_emi <= 0:
        return False, None, None, "delta EMI nullo (finestra troppo corta?)"
    scarto = abs(rapl_delta - d_emi) / d_emi
    return scarto <= tolerance, rapl_delta, d_emi, scarto


@dataclass
class _MsrInput(ctypes.Structure):
    MsrAddress: ctypes.c_uint32
    Reserved: ctypes.c_uint32


class WinRing0Backend:
    """RdMSR reale via device \\\\.\\WINRING0 (WinRing0x64.sys) o inpoutx64.

    Fedele a EMI QUANDO FUNZIONA: legge direttamente 0x606 (unita') e i contatori
    0x611/0x639/0x641/0x619 -> delta tra due letture = Joule reali come nei CSV EMI.
    Richiede il driver WinRing0 caricato (admin). STATO ATTUALE su MINI_IT13
    (brief P0-4): CreateFile riesce ma l'ioctl RDMSR FALLISCE perche' il codice
    ioctl qui usato non corrisponde al .sys installato; inoltre WinRing0 e' nella
    Vulnerable Driver Blocklist/HVCI. probe() lo marca NON FUNZIONANTE finche' non
    supera la validazione EMI (validate_against_emi, tolleranza 2%).
    """

    name = "winring0_msrdirect"
    #: True solo dopo RdMSR funzionante (+ eventuale validazione EMI, vedi probe()).
    provides_package_energy = False

    def __init__(self, device: str = r"\\.\WINRING0",
                 require_emi_validation: bool = False) -> None:
        self.device = device
        self._handle = None
        self._validated = False
        self._require_emi_validation = require_emi_validation

    def _open_handle(self):
        if self._handle not in (None, -1, 0):
            return self._handle
        import sys
        if sys.platform != "win32":
            raise OSError("WinRing0 disponibile solo su Windows")
        kernel32 = ctypes.WinDLL("kernel32", use_last_error=True)  # pragma: no cover
        GENERIC_READ = 0x80000000
        GENERIC_WRITE = 0x40000000
        OPEN_EXISTING = 3
        share = 0
        h = kernel32.CreateFileW(
            self.device, GENERIC_READ | GENERIC_WRITE, share, None,
            OPEN_EXISTING, 0, None,
        )
        INVALID = ctypes.c_void_p(-1).value
        if h == INVALID or h == 0:
            raise OSError(f"CreateFile({self.device}) fallito err={ctypes.get_last_error()}")
        self._h_kernel32 = kernel32
        self._handle = h
        return h

    def _rdmsr(self, addr: int) -> int:
        h = self._open_handle()
        inbuf = _MsrInput(addr, 0)
        out = ctypes.c_uint64(0)
        bytes_ret = ctypes.c_uint32(0)
        ok = self._h_kernel32.DeviceIoControl(
            h, WINRING_RDMSR_IOCTL,
            ctypes.byref(inbuf), ctypes.sizeof(inbuf),
            ctypes.byref(out), ctypes.sizeof(out),
            ctypes.byref(bytes_ret), None,
        )
        if not ok:
            raise OSError(f"DeviceIoControl RdMSR 0x{addr:x} fallito")
        return int(out.value)

    def probe(self):
        # P0-4: mai dichiararsi "consigliato" senza prova. Se l'ioctl RdMSR non
        # risponde (Mini_IT13: CreateFile OK ma DeviceIoControl fallisce perche'
        # WINRING_RDMSR_IOCTL non e' il codice del .sys installato) il backend va
        # marciao NON FUNZIONANTE, con motivo esplicito.
        try:
            unit_raw = self._rdmsr(PKG_UNIT_MSR)
        except Exception as exc:  # pragma: no cover - richiede Windows+driver
            return False, (f"WinRing0 NON FUNZIONANTE su questa macchina: {exc} "
                           f"(ioctl congetturato/errato o bloccato da HVCI/"
                           f"Vulnerable Driver Blocklist; vedi brief P0-4)")
        units = RaplUnits.from_msr(unit_raw)
        # sanity check: energy unit ragionevole (2^-16..2^-6), dopo fix decode P0-3
        if not (2.0 ** -16 <= units.joule_unit_j <= 2.0 ** -6):
            return False, f"pkg_unit 0x{unit_raw:x} -> scala J implausibile ({units.joule_unit_j})"
        exp = round(-math.log2(units.joule_unit_j))
        pkg_raw = None
        try:
            pkg_raw = self._rdmsr(RAPL_MSR_ADDRESSES["package"]) & 0xFFFFFFFF
        except Exception as exc:
            return False, f"WinRing0: 0x606 leggibile ma 0x611 fallisce ({exc})"
        if self._require_emi_validation:
            be = self

            def _measure(window_s: float) -> float:
                u = RaplUnits.from_msr(be._rdmsr(PKG_UNIT_MSR))
                c0 = be._rdmsr(RAPL_MSR_ADDRESSES["package"]) & 0xFFFFFFFF
                time.sleep(window_s)
                c1 = be._rdmsr(RAPL_MSR_ADDRESSES["package"]) & 0xFFFFFFFF
                from .rapl_units import counter_delta_to_joules
                return counter_delta_to_joules(c0, c1, u)

            ok, d_rapl, d_emi, scarto = validate_against_emi(_measure, window_s=30.0)
            if not ok:
                return False, (f"WinRing0: RdMSR OK ma validazione EMI fallita: {scarto}")
            self._validated = True
            self.provides_package_energy = True
            return True, (f"WinRing0 VALIDATO vs EMI: RAPL={d_rapl:.2f} J "
                          f"EMI={d_emi:.2f} J scarto={scarto*100:.2f}%")
        # Senza validazione EMI richiesta esplicitamente: disponibile ma NON
        # dichiarato "reale al 100%" (flag _validated resta False).
        self.provides_package_energy = True
        return True, (f"WinRing0 RdMSR risponde (joule_unit=2^-{exp} J/LSB, "
                      f"pkg_raw={pkg_raw}); NON ancora validato vs EMI (P0-4)")

    def read_snapshot(self) -> Optional[RaplSnapshot]:
        try:
            units = RaplUnits.from_msr(self._rdmsr(PKG_UNIT_MSR))
            counters: Dict[str, Optional[int]] = {}
            for dom, msr in RAPL_MSR_ADDRESSES.items():
                try:
                    counters[dom] = self._rdmsr(msr) & 0xFFFFFFFF
                except Exception:
                    counters[dom] = None
        except Exception:
            return None
        return RaplSnapshot(ts=time.monotonic(), units=units, counters=counters,
                            source="winring0_msrdirect")

    def close(self) -> None:
        if getattr(self, "_handle", None) not in (None, -1, 0):
            try:
                self._h_kernel32.CloseHandle(self._handle)
            except Exception:
                pass
            self._handle = None


# --------------------------------------------------------------------------- #
# 3) CIM root\wmi ProcessorPowerMetrics (nativo, zero driver)                   #
# --------------------------------------------------------------------------- #
class CimProcessorPowerMetricsBackend:
    """Prova a leggere i contatori RAPL esposti NATIVAMENTE da Windows via CIM/WMI.

    Classi candidate (dipendono da firmware/OEM/sku):
      * root\\wmi::ProcessorPowerMetrics       (alcuni Win11 recenti)
      * root\\wmi::MSAPROTOR... / MSAcpi_PowerMeter / BatteryMeter
    Se trova campi numerici interpretabili come contatori energia cumulativi li
    converte in un RaplSnapshot; altrimenti probe fallisce e si passa oltre.
    """

    name = "cim_processorpowermetrics"

    NAMESPACE = "root/wmi"
    #: Classi candidate per contatori energia RAPL nativi (verifica live su MINI_IT13:
    #: `Get-CimInstance -Namespace root\\wmi -ClassName ProcessorPowerMetrics`).
    CLASSES = ["ProcessorPowerMetrics", "MSAcpi_PowerMeter", "BatteryMeter"]

    def __init__(self) -> None:
        self._session = None
        self._cls: Optional[str] = None
        self._field_map: Dict[str, str] = {}

    def _connect(self):
        import wmi  # pip install wmi (usa win32com sotto)  # noqa: PLC0415

        if self._session is None:
            self._session = wmi.WMI(namespace=self.NAMESPACE)
        return self._session

    @staticmethod
    def _instance_property_names(inst) -> List[str]:
        """Scoperta difensiva dei nomi di proprieta' di un oggetto WMI.

        P0-1 (brief MINI_IT13): ``inst.__properties__`` NON esiste sugli oggetti
        win32com del pacchetto ``wmi`` (AttributeError: __properties__. Did you
        mean: 'Properties_'?) e faceva crashare l'intera cascata dei backend.
        Proviamo in ordine: obj.Properties_ (.Name), __properties__, Properties()
        (cimplib), vars(); se nulla funziona ritorniamo [] senza sollevare.
        """
        names: List[str] = []
        try:
            props = getattr(inst, "Properties_", None)
            if props is not None:
                for p in props:
                    n = getattr(p, "Name", None)
                    if n:
                        names.append(str(n))
        except Exception:
            pass
        if not names:
            try:
                names = [str(k) for k in getattr(inst, "__properties__", []) or []]
            except Exception:
                names = []
        if not names:
            try:
                plist = getattr(inst, "Properties", None)
                if callable(plist):
                    names = [str(getattr(p, "name", p)) for p in plist()]
            except Exception:
                pass
        if not names:
            try:
                names = [k for k in vars(inst) if not k.startswith("_")]
            except Exception:
                names = []
        return names

    def probe(self):
        # CONTRATTO (P0-1): probe() deve SEMPRE ritornare (bool, str), mai
        # sollevare: la cascata select_backend() deve degradare, non crashare.
        try:
            import sys
            if sys.platform != "win32":
                return False, "CIM root\\wmi disponibile solo su Windows"
            try:
                self._connect()
            except Exception as exc:
                return False, f"WMI/CIM non raggiungibile: {exc}"
            candidates = []
            for cls_name in self.CLASSES:
                try:
                    insts = getattr(self._session, cls_name)()
                except Exception:
                    continue
                if not insts:
                    continue
                try:
                    prop_names = self._instance_property_names(insts[0])
                    props = {k.lower(): k for k in prop_names}
                except Exception as exc:
                    return False, f"CIM {cls_name}: scoperta proprieta' fallita ({exc})"
                fmap = {}
                for want, aliases in {
                    "package": ["packageenergy", "energy", "pkgenergy", "totalenergy"],
                    "dram": ["dramenergy", "memoryenergy"],
                    "pp0": ["coreenergy", "pp0energy"],
                }.items():
                    for a in aliases:
                        if a in props:
                            fmap[want] = props[a]
                            break
                if fmap:
                    candidates.append((cls_name, fmap))
            if not candidates:
                return False, "nessuna proprieta' energia in root\\wmi (firmware non espone RAPL)"
            self._cls, self._field_map = candidates[0]
            return True, f"CIM {self._NAMESPACE}::{self._cls} OK"
        except Exception as exc:  # rete di sicurezza finale: mai traceback fuori
            return False, f"CIM probe ha sollevato {type(exc).__name__}: {exc}"

    def read_snapshot(self) -> Optional[RaplSnapshot]:
        if not self._cls:
            return None
        try:
            insts = getattr(self._connect(), self._cls)()
        except Exception:
            return None
        if not insts:
            return None
        inst = insts[0]
        # Fallback dichiarato: pkg_unit client (energy 2^-14 J). Se la classe CIM
        # esponesse il raw pkg_unit, usare RaplUnits.from_msr() al posto.
        units = RaplUnits.default_client()
        counters: Dict[str, Optional[int]] = {d: None for d in RAPL_MSR_ADDRESSES}
        for dom, field in self._field_map.items():
            try:
                v = float(getattr(inst, field))
            except Exception:
                continue
            counters[dom] = int(round(v / units.joule_unit_j))
        if counters["package"] is None:
            return None
        return RaplSnapshot(ts=time.monotonic(), units=units, counters=counters,
                            source="cim_processorpowermetrics")


# --------------------------------------------------------------------------- #
# Mock backend (per test/Linux/demo end-to-end senza hardware)                  #
# --------------------------------------------------------------------------- #
class MockRaplBackend:
    """Genera contatori RAPL sintetici coerenti (monotoni, wrap-correct).

    P1-1 (brief MINI_IT13): un mock NON deve poter essere scambiato per una
    misura reale. Ogni snapshot porta ``source="mock"`` e :func:`mock_banner`
    va stampato in testa a ogni run che usa questo backend; la CLI accetta
    ``--mock`` solo insieme a ``--allow-mock``, che rinomina gli output in
    ``*_MOCK.*``. I valori sono le firme cablate pp0_ratio/pp1_ratio/dram_ratio
    (es. PKG=34.9 -> PP0=24.5 PP1=3.5 DRAM=5.2 J su MINI_IT13: erano mock!).

    Simula una CPU che consuma ``base_w`` idle + picchi proporzionali a una funzione
    ``load_fn(t)``. Utile per validare tutta la catena driver->attribuzione senza
    Windows ne' driver kernel.
    """

    name = "mock_rapl"
    #: firma inconfondibile negli output (P1-1)
    provides_package_energy = True  # il mock emette contatori, ma SONO finti
    SOURCE_LABEL = "mock"

    DOMAIN_TO_MSR = dict(RAPL_MSR_ADDRESSES)

    def __init__(self, base_w: float = 12.0, load_fn=None,
                 dram_ratio: float = 0.15, pp0_ratio: float = 0.7,
                 pp1_ratio: float = 0.1, seed_t0: Optional[float] = None) -> None:
        self.base_w = base_w
        self.load_fn = load_fn or (lambda t: 0.0)
        self.dram_ratio = dram_ratio
        self.pp0_ratio = pp0_ratio
        self.pp1_ratio = pp1_ratio
        self.units = RaplUnits(joule_unit_j=2.0 ** -14, watt_unit_w=2.0 ** -3,
                               time_unit_s=2.0 ** -10)
        self._t0 = seed_t0 if seed_t0 is not None else time.monotonic()
        self._accum_j: Dict[str, float] = {"package": 0.0, "pp0": 0.0, "pp1": 0.0,
                                           "dram": 0.0, "platform": 0.0}
        self._last_t = self._t0

    def probe(self):
        return True, ("MOCK RAPL backend (nessun hardware richiesto) - "
                      "DATI SINTETICI, non una misura reale [P1-1]")

    def _advance(self, now: float):
        dt = max(0.0, now - self._last_t)
        if dt > 0:
            load = self.load_fn(now - self._t0)
            pkg_w = self.base_w + load
            self._accum_j["package"] += pkg_w * dt
            self._accum_j["pp0"] += pkg_w * self.pp0_ratio * dt
            self._accum_j["pp1"] += pkg_w * self.pp1_ratio * dt
            self._accum_j["dram"] += pkg_w * self.dram_ratio * dt
            self._accum_j["platform"] += pkg_w * 1.1 * dt
            self._last_t = now

    def read_snapshot(self) -> Optional[RaplSnapshot]:
        now = time.monotonic()
        self._advance(now)
        counters = {d: int(round(j / self.units.joule_unit_j)) & 0xFFFFFFFF
                    for d, j in self._accum_j.items()}
        snap = RaplSnapshot(ts=now, units=self.units, counters=counters,
                            source=self.SOURCE_LABEL)
        snap.is_mock = True  # flag esplicito per CLI/report (P1-1)
        return snap


# --------------------------------------------------------------------------- #
# Selezione backend                                                             #
# --------------------------------------------------------------------------- #
def all_backends(dll_path: Optional[str] = None) -> List[MsrBackend]:
    """Cascata backend in ordine di preferenza (direct MSR > CIM > LHM).

    Ritorna una lista NUOVA a ogni chiamata: i backendi sono istanze fresche,
    cosi' chi chiama puo' marciare uno dei tre senza effetti collaterali globali.
    """
    return [
        WinRing0Backend(),
        CimProcessorPowerMetricsBackend(),
        LibreHardwareMonitorBackend(dll_path=dll_path),
    ]


#: Sorgenti di snapshot che NON sono contatori RAPL hardware reali (P0-5/P1-1):
#: usate da attribution per rifiutare il metodo real_rapl.
NON_REAL_SOURCES = frozenset({"power_integration", "mock"})


def backend_provides_real_energy(backend) -> tuple[bool, str]:
    """True se il backend fornisce un VERO contatore package RAPL (non integrazione).

    Criteri (brief MINI_IT13 P0-5):
      * ``provides_package_energy`` esplicitamente False (LHM power-integration)
        -> rifiutato con motivo;
      * WinRing0: RdMSR diretto -> accettato solo se probe e' andato a buon fine
        (su MINI_IT13 fallisce: ioctl congetturato, vedi P0-4);
      * CIM root\\wmi: contatori nativi firmware -> accettato.
    Ritorna (bool, motivo). Non solleva mai.
    """
    try:
        if getattr(backend, "provides_package_energy", None) is False:
            return False, ("backend = power-integration (LHM integra P*dt, nessun "
                           "sensore Energy su questa CPU): NON e' un contatore MSR reale")
        name = getattr(backend, "name", "")
        if name == "librehardwaremonitor":
            snap = None
            try:
                snap = backend.read_snapshot()
            except Exception:
                pass
            if snap is not None and snap.source in NON_REAL_SOURCES:
                return False, f"sorgente snapshot = {snap.source!r}: non real_rapl"
            return True, "LHM espone sensori Energy nativi"
        if name == "winring0_msrdirect":
            ok, reason = safe_probe(backend)
            return ok, reason if not ok else "RdMSR diretto 0x611 (parita' EMI)"
        if name == "cim_processorpowermetrics":
            return True, "contatori energia nativi CIM root\\wmi"
        if name == "mock_rapl":
            return False, "MOCK: dati sintetici, mai real_rapl (P1-1)"
        return True, "backend sconosciuto: assunto reale (verificare)"
    except Exception as exc:  # pragma: no cover
        return False, f"valutazione fallita: {exc}"


def select_backend(prefer: Optional[str] = None,
                   backends: Optional[List[MsrBackend]] = None) -> tuple[MsrBackend, bool, str]:
    """Ritorna (backend, disponibile, motivo). Preferenza: direct MSR > CIM > LHM.

    La cascata DEVE degradare, non crashare (P0-1): ogni probe passa da
    :func:`safe_probe`, quindi un backend rotto produce solo un motivo negativo
    e si passa al successivo. NB: un backend "disponibile" puo' essere comunque
    solo power-integration (es. LHM): usare backend_provides_real_energy() per
    distinguere, non fidarsi del solo bool.
    """
    order: List[MsrBackend]
    if backends is not None:
        order = list(backends)
    else:
        order = all_backends()
    if prefer:
        order.sort(key=lambda b: 0 if b.name == prefer else 1)
    for b in order:
        ok, reason = safe_probe(b)
        if ok:
            return b, True, reason
    # nessuno disponibile: ritorna comunque l'ultimo della cascata (mock gestito altrove)
    return order[-1], False, "nessun backend MSR disponibile (usera' stima)"


def mock_banner(stream=None) -> None:
    """Banner OBBLIGATORIO quando si usano dati mock (P1-1)."""
    import sys
    out = stream or sys.stderr
    print("!" * 72, file=out)
    print("*** ATTENZIONE: DATI MOCK / SINTETICI *** - non sono misure reali.", file=out)
    print("*** Output rinominati *_MOCK.* -- non confrontare con EMI o report.  ***", file=out)
    print("!" * 72, file=out)


def integrate_power(samples, units: Optional[RaplUnits] = None):
    """Integra una sequenza di ``(ts, power_w)`` in energia cumulativa (J).

    Serve quando il backend espone solo potenza istantanea (es. LHM ``Power``
    sensor) ma vogliamo lo stesso formato a contatore cumulativo usato da EMI.
    Ritorna una lista di ``(ts, energy_j_cumulativa)``.
    """
    out = []
    acc = 0.0
    prev_ts = None
    for ts, p_w in samples:
        if prev_ts is not None:
            acc += max(0.0, ts - prev_ts) * max(0.0, p_w)
        out.append((ts, acc))
        prev_ts = ts
    return out


def make_mock_backend(base_w: float = 12.0, load_fn=None) -> MockRaplBackend:
    """Factory del backend sintetico (demo/test senza hardware Windows)."""
    return MockRaplBackend(base_w=base_w, load_fn=load_fn)

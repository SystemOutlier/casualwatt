"""CLI ausiliaria: verifica i 3 approcci per leggere i contatori RAPL su Windows.

Da eseguire **sul PC di destinazione**, in PowerShell (Windows 10/11):

    # approccio 2 prima di tutto: verifica se il firmware espone gia' i contatori
    python -m cpuepower.check_rapl --cim

    # approccio 1: LibreHardwareMonitor via pythonnet
    pip install pythonnet
    # scarica LibreHardwareMonitorLib.dll (nuget: LibreHardwareMonitor) e mettila
    # accanto al progetto o passala con --dll
    python -m cpuepower.check_rapl --lhm --dll vendor\\LibreHardwareMonitorLib.dll

    # approccio 3: RdMSR diretto via WinRing0 (driver kernel, admin + eventuale
    # Test Signing se usi una tua copia non firmata)
    python -m cpuepower.check_rapl --winring0

    # tutti, con dump degli ultimi MSR letti e conversione in J
    python -m cpuepower.check_rapl --all --sample-seconds 5

Output: per ogni backend dice se funziona, stampa la scala sciolta da 0x606
(Joule/LSB) e il delta Package/PP0/PP1/DRAM in Joule reali sulla finestra di
campionamento — gli stessi numeri che trovi nei CSV EMI.
"""

from __future__ import annotations

import argparse
import sys
import time

from .msr_backends import (
    CimProcessorPowerMetricsBackend,
    LibreHardwareMonitorBackend,
    WinRing0Backend,
)
from .rapl_units import diff_snapshots


def check_backend(backend, sample_s: float, verbose: bool) -> bool:
    ok, reason = backend.probe()
    print(f"\n### {backend.name}: {'DISPONIBILE' if ok else 'non disponibile'} — {reason}")
    if not ok:
        return False
    try:
        opener = getattr(backend, "open", None)
        if callable(opener):
            opener()
        a = backend.read_snapshot()
        time.sleep(sample_s)
        b = backend.read_snapshot()
    except Exception as exc:
        print(f"  errore lettura: {exc}")
        return False
    if a is None or b is None:
        print("  snapshot non ottenuto")
        return False
    w = diff_snapshots(a, b)
    print(f"  scala energia   : {w.units.joule_unit_j:.9f} J/LSB "
          f"(1 LSB = {w.units.joule_unit_j*1000:.4f} mJ)")
    for name, val in (("Package", w.package_j), ("PP0 ", w.pp0_j),
                      ("PP1 ", w.pp1_j), ("DRAM", w.dram_j), ("Psys", w.platform_j)):
        if val is not None:
            pw = val / w.window_s if w.window_s > 0 else float('nan')
            print(f"  {name}: delta {val:8.3f} J  ({pw:7.2f} W medi) sul delta t={w.window_s:.2f} s")
        else:
            print(f"  {name}: dominio non esposto")
    if w.wrapped_domains:
        print(f"  wrap-around su: {', '.join(w.wrapped_domains)} (gestito correttamente)")
    if verbose:
        print(f"  raw before: {a.counters}")
        print(f"  raw after : {b.counters}")
    return True


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="check_rapl", description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    g = ap.add_mutually_exclusive_group(required=True)
    g.add_argument("--cim", action="store_true", help="approccio 2: root\\wmi CIM nativo")
    g.add_argument("--lhm", action="store_true", help="approccio 1: LibreHardwareMonitor+pythonnet")
    g.add_argument("--winring0", action="store_true", help="approccio 3: RdMSR diretto WinRing0")
    g.add_argument("--all", action="store_true", help="prova tutti e tre in sequenza")
    ap.add_argument("--dll", default=None, help="percorso LibreHardwareMonitorLib.dll")
    ap.add_argument("--device", default=r"\\.\WINRING0", help="nome device WinRing0/inpoutx64")
    ap.add_argument("--sample-seconds", type=float, default=2.0)
    ap.add_argument("-v", "--verbose", action="store_true")
    args = ap.parse_args(argv)

    if sys.platform != "win32":
        print("ATTENZIONE: non sei su Windows; i backend reali non possono funzionare "
              "(usa `cpuepower.cli tree --mock` per la demo della catena completa).")

    backends = []
    if args.all or args.winring0:
        backends.append(WinRing0Backend(device=args.device))
    if args.all or args.cim:
        backends.append(CimProcessorPowerMetricsBackend())
    if args.all or args.lhm:
        backends.append(LibreHardwareMonitorBackend(dll_path=args.dll))

    worked = [b.name for b in backends if check_backend(b, args.sample_seconds, args.verbose)]
    print("\n=== RIEPILOGO ===")
    if worked:
        print(f"Backend funzionanti: {', '.join(worked)}")
        print("Usali cosi':  python -m cpuepower.cli tree --exe ollama.exe --driver rapl_msr")
        return 0
    print("Nessun backend RAPL reale disponibile su questa macchina.")
    print("Prossimi passi consigliati:")
    print("  1) prova come Admin (WinRing0 richiede privilegi);")
    print("  2) Get-CimInstance -Namespace root\\wmi -ClassName ProcessorPowerMetrics")
    print("     per vedere se il firmware espone i contatori;")
    print("  3) pip install pythonnet + LibreHardwareMonitorLib.dll (approccio 1);")
    print("  4) solo in extremis: driver custom + Test Signing (bcdedit /set testsigning on).")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())

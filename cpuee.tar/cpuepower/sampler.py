"""Campionatore periodico multi-driver + selezione automatica del driver migliore."""

from __future__ import annotations

import threading
import time
from typing import Callable, List, Optional

from .drivers.base import DriverCapability, EnergyDriver, registry_drivers
from .types import PackageEnergy


def all_drivers() -> List[EnergyDriver]:
    return registry_drivers()


def best_driver_for(need_package_energy: bool = True,
                    drivers: Optional[List[EnergyDriver]] = None) -> Optional[EnergyDriver]:
    """Primo driver (in ordine di preferenza) che soddisfa il requisito.

    ``need_package_energy=True`` → cerca contatore cumulativo reale (wmi_msr/rapl_registry);
    se nessuno dei due ce la fa, ripiega su ``estimate`` (energia integrata stimata).
    """
    drivers = drivers or registry_drivers()
    fallback = None
    for d in drivers:
        caps = d.probe()
        if not caps.available:
            continue
        if need_package_energy and caps.provides_package_energy:
            return d
        if fallback is None:
            fallback = d
    return fallback  # tipicamente EstimateDriver


class EnergySampler:
    """Thread che legge periodicamente un driver e invia letture a callback.

    Uso::

        sampler = EnergySampler(driver, interval_s=1.0, on_sample=cb)
        sampler.start()
        ...
        sampler.stop()

    Ogni callback riceve ``(PackageEnergy_current, PackageEnergy_previous)``; il delta
    energia/potenza si calcola facilmente dalla differenza dei due contatori.
    """

    def __init__(self, driver: EnergyDriver, interval_s: float = 1.0,
                 on_sample: Optional[Callable[[PackageEnergy, Optional[PackageEnergy]], None]] = None
                 ) -> None:
        self.driver = driver
        self.interval_s = interval_s
        self.on_sample = on_sample
        self._stop = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self.last: Optional[PackageEnergy] = None
        self.previous: Optional[PackageEnergy] = None

    def _loop(self) -> None:
        try:
            self.driver.open()
        except Exception as exc:
            if self.on_sample:
                ts = time.time()
                self.on_sample(PackageEnergy.unavailable(ts, self.driver.source, str(exc)), None)
            return
        try:
            while not self._stop.is_set():
                cur = self.driver.read_package()
                self.previous, self.last = self.last, cur
                if self.on_sample:
                    self.on_sample(cur, self.previous)
                self._stop.wait(self.interval_s)
        finally:
            self.driver.close()

    def start(self) -> None:
        if self._thread and self._thread.is_alive():
            return
        self._stop.clear()
        self._thread = threading.Thread(target=self._loop, daemon=True,
                                         name=f"cpuepower-{self.driver.name}")
        self._thread.start()

    def stop(self, timeout: float = 2.0) -> None:
        self._stop.set()
        if self._thread:
            self._thread.join(timeout=timeout)
            self._thread = None

    # ------------------------------------------------------- synchronous helpers
    def power_over_window(self, window_s: Optional[float] = None) -> Optional[float]:
        """Lettura sincrona: restituisce la potenza media (W) sull'ultimo intervallo."""
        window_s = window_s or self.interval_s
        a = self.driver.read_package()
        time.sleep(window_s)
        b = self.driver.read_package()
        if a.available and b.available and b.timestamp > a.timestamp:
            dt = b.timestamp - a.timestamp
            d_mj = max(0.0, (b.energy_mj or 0.0) - (a.energy_mj or 0.0))
            return d_mj / 1000.0 / dt
        return None

"""Driver di stima: potenza CPU da profilo TDP + utilizzo (funziona ovunque, anche non-Windows).

Modello lineare semplificato (stile Intel Power Gadget "energy estimate"):

    P(t) = P_idle + util_frac * (P_max - P_idle)

dove ``util_frac`` e' l'utilizzo medio ponderato per frequenza su tutti i core logici
(psutil.cpu_percent con intervallo, o GetSystemTimes su Windows), e il profilo
(P_idle, P_max, TDP) viene dedotto da:

1. valori passati esplicitamente dall'utente;
2. tabella interna per le CPU piu' comuni (match su nome ``Win32_Processor.Name``);
3. fallback conservativo: ``P_idle = 0.35 * TDP_nominal``, ``P_max = TDP_nominal``.

Il contatore "energia" restituito e' un integrale numerico della potenza stimata:
viene accumulato ad ogni ``read_package`` moltiplicando P stimata per il tempo dalla
lettura precedente. Non e' una misura, ma permette attribuzioni relative coerenti.
"""

from __future__ import annotations

import time
from typing import List, Optional, Tuple

from ..types import CoreEnergy, PackageEnergy, ReadingSource
from .base import DriverCapability, EnergyDriver

#: (pattern nel nome CPU) -> (TDP W, idle W). Estendibile dall'utente via set_profile().
CPU_PROFILE_TABLE = [
    ("i9-14900", 125.0, 30.0),
    ("i9-13900", 125.0, 30.0),
    ("i7-14700", 65.0, 20.0),
    ("i7-13700", 65.0, 20.0),
    ("i5-14600", 65.0, 18.0),
    ("i5-13600", 65.0, 18.0),
    ("i5-12400", 65.0, 15.0),
    ("i7-12700", 65.0, 20.0),
    ("i3-12100", 60.0, 12.0),
    ("ryzen 9 7950", 170.0, 35.0),
    ("ryzen 9 7900", 65.0, 25.0),
    ("ryzen 7 7700", 65.0, 22.0),
    ("ryzen 5 7600", 65.0, 20.0),
    ("ryzen 7 5800", 105.0, 25.0),
    ("ryzen 5 5600", 65.0, 20.0),
]


class EstimateDriver(EnergyDriver):
    name = "estimate"
    description = "Stima CPU-time x profilo TDP (fallback sempre disponibile)"
    source = ReadingSource.ESTIMATED
    requires_admin = False

    def __init__(self, tdp_w: Optional[float] = None, idle_w: Optional[float] = None) -> None:
        self._tdp_w = tdp_w
        self._idle_w = idle_w
        self._accumulated_mj = 0.0
        self._last_ts: Optional[float] = None
        self._cpu_name: str = ""

    # ------------------------------------------------------------------ probing
    def probe(self) -> DriverCapability:
        try:
            import psutil  # noqa: F401

            return DriverCapability(
                name=self.name, description=self.description, available=True,
                provides_package_energy=False,   # mai una misura reale
                provides_core_utility=True,      # possiamo leggere cpu_percent per-core
                reason="stima, non misura", requires_admin=False)
        except ImportError:
            return DriverCapability(
                name=self.name, description=self.description, available=False,
                provides_package_energy=False, provides_core_utility=False,
                reason="psutil mancante", requires_admin=False)

    def set_profile(self, tdp_w: float, idle_w: Optional[float] = None) -> None:
        """Permette all'utente di forzare il profilo termico della propria CPU."""
        self._tdp_w = tdp_w
        if idle_w is not None:
            self._idle_w = idle_w

    def _resolve_profile(self) -> Tuple[float, float]:
        if self._tdp_w is not None:
            tdp = self._tdp_w
        else:
            tdp = self._lookup_tdp()
        idle = self._idle_w if self._idle_w is not None else max(2.0, 0.15 * tdp)
        return tdp, idle

    def _lookup_tdp(self) -> float:
        name = self._get_cpu_name().lower()
        for pattern, tdp, _idle in CPU_PROFILE_TABLE:
            if pattern in name:
                if self._idle_w is None:
                    # memorizza idle di tabella se non impostato dall'utente
                    for p, t, i in CPU_PROFILE_TABLE:
                        if p == pattern:
                            self._idle_w = i
                return tdp
        cores = self._logical_counts()
        return 15.0 + 6.0 * max(cores // 2, 1)   # fallback grezzo ~6W/core attivo

    def _get_cpu_name(self) -> str:
        if self._cpu_name:
            return self._cpu_name
        if self.is_windows():
            try:
                import winreg

                with winreg.OpenKey(
                        winreg.HKEY_LOCAL_MACHINE,
                        r"HARDWARE\DESCRIPTION\System\CentralProcessor\0") as k:
                    self._cpu_name, _ = winreg.QueryValueEx(k, "ProcessorNameString")
                return self._cpu_name
            except OSError:
                pass
        try:
            import platform

            self._cpu_name = platform.processor() or "unknown"
        except Exception:
            self._cpu_name = "unknown"
        return self._cpu_name

    @staticmethod
    def _logical_counts() -> int:
        try:
            import os

            return os.cpu_count() or 1
        except Exception:
            return 1

    # ------------------------------------------------------------------- reads
    def read_package(self) -> PackageEnergy:
        ts = time.time()
        util = self._system_util_fraction()
        tdp, idle = self._resolve_profile()
        power_w = idle + util * (tdp - idle)
        if self._last_ts is not None:
            dt = max(0.0, ts - self._last_ts)
            self._accumulated_mj += power_w * dt * 1000.0
        self._last_ts = ts
        return PackageEnergy(timestamp=ts, energy_mj=self._accumulated_mj, available=True,
                             source=self.source,
                             note=f"stima P={power_w:.1f}W util={util*100:.1f}%")

    def _system_util_fraction(self) -> float:
        """Utilizzo medio 0..1 ponderato (usa psutil; no blocking > pochi ms)."""
        try:
            import psutil

            pct = psutil.cpu_percent(interval=None)
            if pct < 0:
                return 0.0
            return min(1.0, pct / 100.0)
        except Exception:
            return 0.0

    def read_cores(self) -> List[CoreEnergy]:
        ts = time.time()
        try:
            import psutil

            per = psutil.cpu_percent(interval=None, percpu=True)
            return [CoreEnergy(core_id=i, timestamp=ts, perf_utility_pct=p)
                    for i, p in enumerate(per)]
        except Exception:
            return []

"""Interfaccia comune per tutti i driver di lettura energia CPU."""

from __future__ import annotations

import abc
import time
from dataclasses import dataclass
from typing import List, Optional

from ..types import CoreEnergy, PackageEnergy, ReadingSource


@dataclass
class DriverCapability:
    """Risultato del probe: cosa sa fornirmi questo driver su questa macchina?"""

    name: str
    description: str
    available: bool                 # il driver puo' essere istanziato (OS + dipendenze)
    provides_package_energy: bool   # espone energia cumulativa del package (RAPL-like)
    provides_core_utility: bool     # espone metriche per-core (% utility / frequenza)
    reason: str = ""                # perche' non disponibile, se disponibile=False
    requires_admin: bool = False

    def format(self) -> str:
        status = "OK " if self.available else "-- "
        return (
            f"[{status}] {self.name:<14} {self.description:<45} "
            f"package={self.provides_package_energy} cores={self.provides_core_utility}"
            + (f"  ({self.reason})" if self.reason and not self.available else "")
        )


class EnergyDriver(abc.ABC):
    """Driver astratto: sorgente di misure/derive di energia CPU.

    Un driver deve poter rispondere a ``probe`` (senza effetti collaterali pesanti)
    e, se disponibile, a :meth:`read_package` e opzionalmente :meth:`read_cores`.

    Convenzione: ``energy_mj`` restituita da ``read_package`` e' un *contatore cumulativo*
    monotono (stile MSR PKG_ENERGY_STATUS), in millijoule. Il delta fra due letture
    consecutive fornisce l'energia consumata nella finestra.
    """

    #: nome breve univoco (usato anche come value di ReadingSource quando possibile)
    name: str = "base"
    description: str = "Driver base"
    source: ReadingSource = ReadingSource.UNKNOWN
    requires_admin: bool = False

    @abc.abstractmethod
    def probe(self) -> DriverCapability:
        """Verifica se il driver e' utilizzabile su questa macchina. Idempotente."""

    @abc.abstractmethod
    def read_package(self) -> PackageEnergy:
        """Legge il contatore di energia del package (o una sua stima)."""

    def read_cores(self) -> List[CoreEnergy]:
        """Metriche per-core. Default: non disponibili."""
        return []

    def open(self) -> None:
        """Eventuale inizializzazione costosa (handle WMI/PDH). Chiamato dal sampler."""
        return None

    def close(self) -> None:
        """Rilascio risorse."""
        return None

    # ------------------------------------------------------------------ helpers
    @staticmethod
    def is_windows() -> bool:
        import sys

        return sys.platform == "win32"

    @staticmethod
    def now() -> float:
        return time.time()


def registry_drivers() -> List[EnergyDriver]:
    """Elenco canonico dei driver, in ordine di preferenza (migliore prima).

    ``rapl_msr`` e' primo perche' e' l'unico che fornisce *Joule reali* dai
    contatori hardware (MSR), esattamente come il benchmark EMI; segue wmi_msr
    (firmware-dependent), poi le stime.
    """
    from .estimate import EstimateDriver
    from .pdh import PdhDriver
    from .rapl_msr import RealRaplDriver
    from .rapl_registry import RaplRegistryDriver
    from .wmi_msr import WmiMsrDriver

    return [RealRaplDriver(), WmiMsrDriver(), RaplRegistryDriver(),
            PdhDriver(), EstimateDriver()]

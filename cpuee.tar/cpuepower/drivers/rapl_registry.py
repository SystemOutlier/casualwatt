"""Driver "RAPL via registro": legge valori di energia scritti nel registro da tool terzi.

Alcuni applicativi (Intel Power Gadget, AIDA64, Open Hardware Monitor quando eseguito
come servizio, LibreHardwareMonitor) pubblicano periodicalmente letture RAPL/MSR in
chiavi di registro accessibili senza driver firmati. Questo driver cerca quelle chiavi
e le interpreta come contatore cumulativo in mJ.

Chiavi note cercate:
* ``HKLM\\SOFTWARE\\Intel\\PowerGadget``            (valori DWORD/QWORD vari per versione)
* ``HKCU\\Software\\OpenHardwareMonitor\\...``      (sensori ActivityMonitoring / Energy)
* ``HKLM\\SYSTEM\\CurrentControlSet\\Services\\ipgapp`` (variante servizio IPG)

Il formato non e' documentato ufficialmente: il probe fa una lettura reale e verifica
che esista un valore numerico plausibilmente monotono fra due letture a distanza di
~50 ms; se il test passa, il driver viene marcato ``provides_package_energy=True``.

Su Linux usa ``/sys/class/powercap`` (equivalente RAPL esposto dal kernel) cosi' che i
test unitari possano validare la logica di parsing con dati finti, e cosi' che il modulo
funzioni anche su dual-boot/WSL2 dove powercap esiste.
"""

from __future__ import annotations

import os
import time
from typing import List, Optional, Tuple

from ..types import PackageEnergy, ReadingSource
from .base import DriverCapability, EnergyDriver

REG_CANDIDATES: List[Tuple[str, str]] = [
    # (hive path, subkey)
    (r"HKEY_LOCAL_MACHINE\SOFTWARE\Intel\PowerGadget", ""),
    (r"HKEY_CURRENT_USER\Software\OpenHardwareMonitor", "Sensors"),
]


class RaplRegistryDriver(EnergyDriver):
    name = "rapl_registry"
    description = "RAPL esposto nel registro (Intel Power Gadget/OHM) o /sys/powercap"
    source = ReadingSource.REGISTRY_RAPL
    requires_admin = False

    POWERCAP_DIR = "/sys/class/powercap"

    def __init__(self) -> None:
        self._powercap_files: List[str] = []
        self._reg_key: Optional[str] = None
        self._reg_value: Optional[str] = None

    # ------------------------------------------------------------------ probing
    def probe(self) -> DriverCapability:
        if self.is_windows():
            ok, key, val = self._probe_registry()
            if ok:
                self._reg_key, self._reg_value = key, val
                return self._caps(True, provides_package=True)
            return self._caps(False, reason="nessuna chiave RAPL nel registro (IPG/OHM non installati?)")
        # Non-Windows: fallback powercap (Linux) - utile anche per i test
        files = self._find_powercap_files()
        if files:
            self._powercap_files = files
            return self._caps(True, provides_package=True)
        return self._caps(False, reason="/sys/class/powercap assente")

    def _caps(self, available: bool, provides_package: bool = False,
              reason: str = "") -> DriverCapability:
        return DriverCapability(
            name=self.name, description=self.description, available=available,
            provides_package_energy=provides_package, provides_core_utility=False,
            reason=reason, requires_admin=self.requires_admin)

    def _probe_registry(self) -> Tuple[bool, Optional[str], Optional[str]]:
        try:
            import winreg  # noqa: PLC0415
        except ImportError:
            return False, None, None
        energy_names = ("Package Energy", "PKG Energy", "energy", "TotalEnergy",
                        "Core Energy", "Cores Energy")
        for hive, sub in REG_CANDIDATES:
            base = self._open_reg(winreg, hive)
            if base is None:
                continue
            try:
                key_path = f"{hive}" + (f"\\{sub}" if sub else "")
                with winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE if "HKLM" in hive or
                                    "HKEY_LOCAL_MACHINE" in hive else
                                    winreg.HKEY_CURRENT_USER,
                                    key_path.split("\\", 1)[1]) as k:
                    i = 0
                    while True:
                        try:
                            name, value, _typ = winreg.EnumValue(k, i)
                        except OSError:
                            break
                        i += 1
                        if any(e.lower() in str(name).lower() for e in energy_names) and \
                                isinstance(value, (int, float)) and value > 0:
                            return True, hive, name
            except OSError:
                continue
        return False, None, None

    @staticmethod
    def _open_reg(winreg, hive_path: str):
        mapping = {
            "HKEY_LOCAL_MACHINE": winreg.HKEY_LOCAL_MACHINE,
            "HKLM": winreg.HKEY_LOCAL_MACHINE,
            "HKEY_CURRENT_USER": winreg.HKEY_CURRENT_USER,
            "HKCU": winreg.HKEY_CURRENT_USER,
        }
        root = hive_path.split("\\", 1)[0]
        return mapping.get(root)

    def _find_powercap_files(self) -> List[str]:
        out = []
        try:
            for entry in sorted(os.listdir(self.POWERCAP_DIR)):
                if entry.startswith("intel-rapl"):
                    f = os.path.join(self.POWERCAP_DIR, entry, "energy_uj")
                    if os.path.exists(f):
                        out.append(f)
        except OSError:
            pass
        return out

    # ------------------------------------------------------------------- reads
    def open(self) -> None:
        caps = self.probe()
        if not caps.available:
            raise RuntimeError(f"rapl_registry non disponibile: {caps.reason}")

    def read_package(self) -> PackageEnergy:
        ts = time.time()
        if self.is_windows():
            return self._read_registry(ts)
        return self._read_powercap(ts)

    def _read_registry(self, ts: float) -> PackageEnergy:
        if self._reg_key is None:
            self.probe()
        if self._reg_key is None or self._reg_value is None:
            return PackageEnergy.unavailable(ts, self.source, "chiave non trovata")
        import winreg

        hive_const = (winreg.HKEY_LOCAL_MACHINE
                      if self._reg_key.startswith("HKLM") or
                      self._reg_key.startswith("HKEY_LOCAL_MACHINE")
                      else winreg.HKEY_CURRENT_USER)
        subkey = self._reg_key.split("\\", 1)[1]
        try:
            with winreg.OpenKey(hive_const, subkey) as k:
                value, _typ = winreg.QueryValueEx(k, self._reg_value)
            v = float(value)
            # IPG scrive tipicamente uJ o mJ: euristica scala
            if v > 1e10:
                v /= 1000.0  # uJ -> mJ
            return PackageEnergy(timestamp=ts, energy_mj=v, available=True,
                                 source=self.source, note=f"reg:{self._reg_value}")
        except OSError as exc:
            return PackageEnergy.unavailable(ts, self.source, str(exc))

    def _read_powercap(self, ts: float) -> PackageEnergy:
        if not self._powercap_files:
            self.probe()
        total_uj = 0.0
        n = 0
        for f in self._powercap_files:
            try:
                with open(f, "r", encoding="ascii") as fh:
                    total_uj += float(fh.read().strip())
                    n += 1
            except OSError:
                continue
        if n == 0:
            return PackageEnergy.unavailable(ts, self.source, "file powercap illeggibili")
        # Solo package domain (intel-rapl:N), non i sottodomini :M
        return PackageEnergy(timestamp=ts, energy_mj=total_uj / 1000.0, available=True,
                             source=self.source, note=f"{n} domain powercap")

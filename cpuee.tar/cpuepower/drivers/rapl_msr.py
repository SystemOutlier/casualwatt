"""Driver RAPL "vero": contatori MSR hardware -> Joule reali (come il benchmark EMI).

Sostituisce le stime (TDP, registry di tool terzi) con letture hardware autentiche.
Windows non espone gli MSR in user-mode, quindi il driver si appoggia a un
:class:`~cpuepower.msr_backends.MsrBackend` che incapsula uno dei tre approcci:

1. **WinRing0 / RdMSR diretto**  — legge ``IA32_RAPL_PKG_UNIT_MSR`` (0x606) e i
   contatori ``PKG/PP0/PP1/DRAM_ENERGY_STATUS`` (0x611/0x613/0x614/0x619):
   identico alla metodologia EMI (delta tra due letture = Joule reali).
2. **LibreHardwareMonitor via pythonnet** — riusa il suo driver kernel firmato;
   integra la potenza istantanea P(t)·dt per ricostruire il contatore cumulativo.
3. **CIM ``root\\wmi::ProcessorPowerMetrics``** — contatori esposti nativamente da
   Windows 10/11 recenti, zero dipendenze extra.

Se nessuno dei tre è disponibile, :meth:`probe` fallisce e il sampler ripiega sui
driver di stima preesistenti (mai spacciare una stima per misura reale: la
:class:`~cpuepower.types.PackageEnergy` mantiene il ``source`` corretto).

Il driver espone anche :meth:`read_rapl_window`, che dà il delta multi-dominio
(Package/PP0/PP1/DRAM in J) fra due snapshot: è l'oggetto che l'albero di processo
moltiplica per la frazione CPU (formula finale EMI-style).
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from ..rapl_units import (
    RaplSnapshot,
    RaplWindowEnergy,
    counter_delta_to_joules,
    diff_snapshots,
)
from ..types import CoreEnergy, PackageEnergy, ReadingSource
from .base import DriverCapability, EnergyDriver


class RealRaplDriver(EnergyDriver):
    """Energia package REALE dai contatori MSR RAPL (via backend kernel-signed)."""

    name = "rapl_msr"
    description = "RAPL MSR reali (WinRing0/LHM/CIM) - Joule hardware come EMI"
    source = ReadingSource.RAPL_MSR
    requires_admin = True   # WinRing0/LHM necessitano driver Ring0; CIM no ma raro

    def __init__(self, backend=None, prefer: Optional[str] = None) -> None:
        # backend iniettabile (Mock nei test); default: selezione automatica
        self._backend = backend
        self._prefer = prefer
        self._last_snapshot: Optional[RaplSnapshot] = None
        self._caps_cache: Optional[DriverCapability] = None
        self._reason = ""

    # ------------------------------------------------------------------ setup
    def _ensure_backend(self):
        if self._backend is not None:
            return self._backend
        from ..msr_backends import select_backend

        backend, ok, reason = select_backend(prefer=self._prefer)
        self._reason = reason
        if not ok:
            self._backend = None
        else:
            self._backend = backend
        return self._backend

    # ------------------------------------------------------------------ probe
    def probe(self) -> DriverCapability:
        if self._caps_cache is not None:
            return self._caps_cache
        backend = self._ensure_backend()
        if backend is None:
            caps = DriverCapability(
                name=self.name, description=self.description, available=False,
                provides_package_energy=False, provides_core_utility=False,
                reason=self._reason or "nessun backend MSR disponibile",
                requires_admin=True,
            )
        else:
            snap = backend.read_snapshot()
            has_pkg = snap is not None and snap.counters.get("package") is not None
            caps = DriverCapability(
                name=self.name,
                description=f"{self.description} [{backend.name}]",
                available=has_pkg,
                provides_package_energy=bool(has_pkg),
                provides_core_utility=snap is not None and snap.counters.get("pp0") is not None,
                reason="" if has_pkg else "snapshot iniziale senza dominio package",
                requires_admin=True,
            )
        self._caps_cache = caps
        return caps

    # ------------------------------------------------------------------ reads
    def open(self) -> None:
        b = self._ensure_backend()
        opener = getattr(b, "open", None)
        if callable(opener):
            opener()

    def close(self) -> None:
        if self._backend is not None:
            self._backend.close()

    def read_snapshot(self) -> Optional[RaplSnapshot]:
        b = self._ensure_backend()
        if b is None:
            return None
        return b.read_snapshot()

    def read_package(self) -> PackageEnergy:
        """Contatore cumulativo PKG in millijoule (contratto base.EnergyDriver)."""
        ts = time.time()
        snap = self.read_snapshot()
        if snap is None:
            return PackageEnergy.unavailable(ts, self.source, "backend MSR non leggibile")
        pkg_j = snap.package_j()
        if pkg_j is None:
            return PackageEnergy.unavailable(ts, self.source, "dominio package assente")
        mono = snap.ts
        note_bits = [f"backend={snap.source}", f"J/LSB=2^{int(round(_log2(snap.units.joule_unit_j)))}"]
        pp0 = snap.counters.get("pp0")
        dram = snap.counters.get("dram")
        if pp0 is not None:
            note_bits.append(f"pp0_raw={pp0}")
        if dram is not None:
            note_bits.append(f"dram_raw={dram}")
        self._last_snapshot = snap
        return PackageEnergy(
            timestamp=ts, energy_mj=pkg_j * 1000.0, available=True,
            source=self.source, note=", ".join(note_bits),
        )

    def read_rapl_window(self, before: Optional[RaplSnapshot] = None,
                         after: Optional[RaplSnapshot] = None) -> RaplWindowEnergy:
        """Delta energia REALE (J) per dominio RAPL fra due snapshot.

        Se ``before``/``after`` omessi, usa l'ultimo snapshot noto (o lo cattura) e
        attende ``window_s`` secondi. Questo è esattamente il "delta tra inizio e
        fine test" dei CSV EMI.
        """
        if after is None:
            window_s = getattr(self, "_default_window_s", 1.0)
            if before is None:
                before = self.read_snapshot()
                time.sleep(window_s)
            after = self.read_snapshot()
        if before is None or after is None:
            return RaplWindowEnergy(window_s=0.0, package_j=None, pp0_j=None,
                                    pp1_j=None, dram_j=None, platform_j=None,
                                    wrapped_domains=[], units=None)  # type: ignore[arg-type]
        return diff_snapshots(before, after)

    def read_cores(self) -> List[CoreEnergy]:
        """PP0 (core domain) come proxy energetico per-core, se disponibile."""
        snap = self.read_snapshot()
        if snap is None:
            return []
        cores_j = snap.counters.get("pp0")
        if cores_j is None:
            return []
        n = _logical_cpus()
        per_core_j = counter_delta_to_joules  # noqa: F841 (reference for API symmetry)
        j_total = cores_j * snap.units.joule_unit_j
        share = j_total / max(1, n)
        return [CoreEnergy(core_id=i, timestamp=time.time(), energy_mj=share * 1000.0)
                for i in range(n)]

    # ---------------------------------------------------------------- helpers
    @property
    def backend_name(self) -> str:
        return self._backend.name if self._backend else "none"


def _log2(x: float) -> float:
    import math

    try:
        return math.log2(x)
    except ValueError:
        return 0.0


def _logical_cpus() -> int:
    import os

    return os.cpu_count() or 1

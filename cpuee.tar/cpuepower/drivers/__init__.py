"""Driver package: nessuna dipendenza extra; usa submoduli."""

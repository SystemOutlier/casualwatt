"""Driver PDH (Performance Data Helper): contatori di utilizzo CPU ponderati per frequenza.

Contatori chiave (disponibili da Windows 10 1703+ su hardware Intel/AMD recente):

* ``\\Processor Information(*)\\% Processor Utility``
    Utilizzo "energeticamente pesato": tiene conto della frequenza effettiva, quindi e'
    il miglior proxy disponibile via API pubbliche per distribuire l'energia package
    fra i core. Valore 0..100 per istanza ``<NUMA>,<core>``, piu' istanza ``_Total``.
* ``\\Processor Information(_Total)\\Processor Performance Precise Total Base Mode``
    Contatore cumulativo di "performance utility" in tick: la sua derivata / base_freq
    fornisce un'utilita' media ponderata, utile per stimare potenza dinamica.
* ``\\Processor(_Total)\\% Idle Time`` → per il modello idle/dynamic del driver estimate.

Implementazione: usa ``win32pdh`` (pywin32). Su piattaforme non-Windows il probe
restituisce ``available=False``. Il modulo espone anche una funzione helper
``process_utility_per_instance`` usabile per query ``\\Process(<nome>)\\...`` quando i
contatori per-processo sono abilitati (``lodctr /r`` + HKLM\\...\\EnableFlags).
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from ..types import CoreEnergy, PackageEnergy, ReadingSource
from .base import DriverCapability, EnergyDriver

# Costanti win32pdh (ripetute qui per evitare import a runtime su non-Windows)
PDH_FMT_DOUBLE = 0x00000200
PDH_NO_BERF = 0x00000004


class PdhDriver(EnergyDriver):
    name = "pdh"
    description = "Performance Counters (% Processor Utility per-core)"
    source = ReadingSource.PDH_COUNTER
    requires_admin = False

    COUNTER_PATH_UTILITY_ALL = r"\Processor Information(*)\% Processor Utility"
    COUNTER_PATH_PRECISE_TOTAL = (
        r"\Processor Information(_Total)\Processor Performance Precise Total Base Mode")
    COUNTER_PATH_IDLE = r"\Processor(_Total)\% Idle Time"

    def __init__(self) -> None:
        self._query = None
        self._handles: Dict[str, int] = {}
        self._probe_ok: Optional[bool] = None

    # ------------------------------------------------------------------ probing
    def probe(self) -> DriverCapability:
        if not self.is_windows():
            return self._caps(False, reason="non-Windows")
        try:
            import win32pdh  # noqa: PLC0415

            paths, _instances = win32pdh.EnumObjectItems(
                None, None, "Processor Information", -1)
            has_utility = any("% Processor Utility" == p for p in paths)
            has_precise = any("Processor Performance Precise Total" in p for p in paths)
            return self._caps(True, provides_package=False,
                              provides_cores=has_utility or has_precise,
                              reason="" if (has_utility or has_precise) else
                              "contatori Processor Utility assenti su questa CPU/OS")
        except Exception as exc:
            return self._caps(False, reason=f"win32pdh: {exc}")

    def _caps(self, available: bool, provides_package: bool = False,
              provides_cores: bool = False, reason: str = "") -> DriverCapability:
        self._probe_ok = available
        return DriverCapability(
            name=self.name, description=self.description, available=available,
            provides_package_energy=provides_package, provides_core_utility=provides_cores,
            reason=reason, requires_admin=self.requires_admin)

    # ------------------------------------------------------------------- reads
    def open(self) -> None:
        if not self.is_windows():
            raise RuntimeError("pdh disponibile solo su Windows")
        import win32pdh

        if self._query is None:
            self._query = win32pdh.OpenQuery(None)
            for path in (self.COUNTER_PATH_UTILITY_ALL, self.COUNTER_PATH_PRECISE_TOTAL,
                         self.COUNTER_PATH_IDLE):
                try:
                    h = win32pdh.AddCounter(None, path)
                    self._handles[path] = h
                    win32pdh.AddToQuery(self._query, h)
                except Exception:
                    # contatore assente: ignoralo, useremo quelli disponibili
                    continue
            if not self._handles:
                raise RuntimeError("nessun contatore PDH registrato con successo")

    def close(self) -> None:
        if self._query is not None:
            import win32pdh

            for h in self._handles.values():
                try:
                    win32pdh.RemoveCounter(h)
                except Exception:
                    pass
            try:
                win32pdh.CloseQuery(self._query)
            except Exception:
                pass
        self._query = None
        self._handles = {}

    def _collect(self) -> Dict[int, float]:
        """Esegue la collect e restituisce handle -> valore double."""
        import win32pdh

        assert self._query is not None
        win32pdh.CollectQueryData(self._query)
        out: Dict[int, float] = {}
        for h in self._handles.values():
            try:
                _, val = win32pdh.GetFormattedCounterValue(h, PDH_FMT_DOUBLE | PDH_NO_BERF)
                out[h] = float(val)
            except Exception:
                continue
        return out

    def read_package(self) -> PackageEnergy:
        ts = time.time()
        return PackageEnergy.unavailable(ts, self.source,
                                         "PDH non fornisce energia assoluta; usare per attribuzione")

    def read_cores(self) -> List[CoreEnergy]:
        ts = time.time()
        if self._query is None:
            try:
                self.open()
            except Exception:
                return []
        cores: List[CoreEnergy] = []
        import win32pdh

        # % Processor Utility: enumera le istanze "<numa>,<core>"
        h_all = self._handles.get(self.COUNTER_PATH_UTILITY_ALL)
        if h_all is not None:
            try:
                items = win32pdh.GetFormattedCounterArrayDouble(h_all)
                for idx, (inst, _fmt, val) in enumerate(items):
                    if "_Total" in inst:
                        continue
                    cores.append(CoreEnergy(core_id=idx, timestamp=ts,
                                            perf_utility_pct=float(val)))
            except Exception:
                pass
        return cores

    # ------------------------------------------------------- extra helpers
    def total_processor_utility(self) -> Optional[float]:
        """Utility totale 0..100 (ponderata per frequenza), se il contatore esiste."""
        if self._query is None:
            return None
        vals = self._collect()
        h = self._handles.get(self.COUNTER_PATH_UTILITY_ALL)
        if h is None:
            return None
        # Per l'array: media pesata gia' fornita dall'istanza _Total nel GetFormattedCounterArray
        import win32pdh

        try:
            items = win32pdh.GetFormattedCounterArrayDouble(h)
            totals = [float(v) for (inst, _f, v) in items if "_Total" in inst]
            if totals:
                return totals[0]
            per_core = [float(v) for (inst, _f, v) in items if "_Total" not in inst]
            if per_core:
                return sum(per_core) / len(per_core)
        except Exception:
            return None
        return None

    def idle_time_pct(self) -> Optional[float]:
        if self._query is None:
            return None
        vals = self._collect()
        h = self._handles.get(self.COUNTER_PATH_IDLE)
        if h is None:
            return None
        return vals.get(h)

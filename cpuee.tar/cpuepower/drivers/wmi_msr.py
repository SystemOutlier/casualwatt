"""Driver WMI: lettura di MSR/energia CPU tramite i namespace ``Root\\wmi`` e ``Root\\CIMV2``.

Sorgenti usate (in ordine di preferenza):

1. ``Root\\wmi`` → classi ``ProcessorPerformance`` / ``MSR_ProcessorPerformance``:
   espongono ``UtilizationPercentage``, ``CurrentFrequency`` e, su alcuni firmware,
   campi energia derivati dagli MSR RAPL.
2. ``Root\\wmi`` → ``ACPI_ThermalZoneInformationEx`` per temperature (contesto).
3. ``Root\\CIMV2`` → ``Win32_Processor`` per metadati (nome CPU, numero core, TDP se esposto).

Nota: la disponibilita' delle proprieta' RAPL via WMI dipende dal firmware/OEM;
per questo il probe fa una lettura reale e verifica quali campi sono presenti.

Il modulo importa ``win32com.client`` solo quando si esegue su Windows: cosi' la
libreria resta importabile anche per i test su Linux.
"""

from __future__ import annotations

import time
from typing import Dict, List, Optional

from ..types import CoreEnergy, PackageEnergy, ReadingSource
from .base import DriverCapability, EnergyDriver


def _get_wmi(namespace: str):
    """Restituisce un oggetto ``WbemScripting.SWbemLocator`` connesso al namespace."""
    import win32com.client  # noqa: PLC0415 - import pigro, solo su Windows

    locator = win32com.client.GetObject("winmgmts:" + namespace)
    return locator


class WmiMsrDriver(EnergyDriver):
    name = "wmi_msr"
    description = "WMI Root\\wmi (MSR/RAPL esposti dal firmware)"
    source = ReadingSource.WMI_MSR
    requires_admin = False

    #: nome della classe WMI che espone i dati di performance/energia per processore
    PERF_CLASS_CANDIDATES = [
        "ProcessorPerformance",
        "MSR_ProcessorPerformance",
    ]

    def __init__(self) -> None:
        self._conn = None
        self._perf_class: Optional[str] = None
        self._energy_field: Optional[str] = None
        self._cached_caps: Optional[DriverCapability] = None

    # ------------------------------------------------------------------ probing
    def probe(self) -> DriverCapability:
        if not self.is_windows():
            return self._caps(False, reason="non-Windows")
        try:
            conn = _get_wmi("root/wmi")
        except Exception as exc:  # WMI assente o pywin32 mancante
            return self._caps(False, reason=f"WMI non raggiungibile: {exc}")

        perf_class = None
        for cand in self.PERF_CLASS_CANDIDATES:
            try:
                insts = list(conn.InstancesOf(cand))
                if insts:
                    perf_class = cand
                    break
            except Exception:
                continue

        if perf_class is None:
            return self._caps(False, reason="nessuna classe ProcessorPerformance in Root\\wmi")

        # Cerco un campo energia-like nelle istanze (nomi tipici dei driver OEM).
        energy_field = None
        try:
            for inst in conn.InstancesOf(perf_class):
                props = {p.Name for p in inst.Properties_}
                for cand_field in ("EnergyEstimate", "PackageEnergy", "RAPLEstimate",
                                   "EnergyConsumed", "PowerEstimate"):
                    if cand_field in props:
                        energy_field = cand_field
                        break
                if energy_field:
                    break
        except Exception:
            pass

        self._perf_class = perf_class
        self._energy_field = energy_field
        provides_pkg = energy_field is not None
        return self._caps(True, provides_package=provides_pkg,
                          provides_cores=True,
                          reason="" if provides_pkg else
                          f"classe {perf_class} trovata ma senza campo energia: uso per utility/frequenze")

    def _caps(self, available: bool, provides_package: bool = False,
              provides_cores: bool = False, reason: str = "") -> DriverCapability:
        caps = DriverCapability(
            name=self.name,
            description=self.description,
            available=available,
            provides_package_energy=provides_package,
            provides_core_utility=provides_cores,
            reason=reason,
            requires_admin=self.requires_admin,
        )
        self._cached_caps = caps
        return caps

    # ------------------------------------------------------------------- reads
    def open(self) -> None:
        if self._conn is None and self.is_windows():
            self._conn = _get_wmi("root/wmi")
            if self._perf_class is None:
                caps = self.probe()
                if not caps.available:
                    raise RuntimeError(f"wmi_msr non disponibile: {caps.reason}")

    def close(self) -> None:
        self._conn = None

    def _instances(self) -> List[dict]:
        """Converte le istanze WMI della classe di performance in dicts."""
        assert self._conn is not None and self._perf_class is not None
        out = []
        for inst in self._conn.InstancesOf(self._perf_class):
            d: Dict[str, object] = {}
            for prop in inst.Properties_:
                try:
                    d[prop.Name] = prop.Value
                except Exception:
                    pass
            out.append(d)
        return out

    def read_package(self) -> PackageEnergy:
        ts = time.time()
        if not self.is_windows() or self._conn is None:
            try:
                self.open()
            except Exception as exc:
                return PackageEnergy.unavailable(ts, self.source, str(exc))
        try:
            insts = self._instances()
        except Exception as exc:
            return PackageEnergy.unavailable(ts, self.source, f"lettura fallita: {exc}")

        if self._energy_field is None:
            return PackageEnergy.unavailable(
                ts, self.source,
                "field energia non esposto dal firmware; usare pdh/estimate per utilità")

        total_mj = 0.0
        seen = 0
        for d in insts:
            val = d.get(self._energy_field)
            if val is None:
                continue
            # Alcuni firmware espongono uJ, altri mJ, altri J: normalizziamo a mJ.
            v = float(val)
            if v > 1e9:      # verosimilmente microjoule cumulativi
                v /= 1000.0
            elif v < 1e4 and seen == 0:
                # valori minuscoli: probabilmente gia' mJ, nessuna conversione
                pass
            total_mj += v
            seen += 1
        if seen == 0:
            return PackageEnergy.unavailable(ts, self.source, "campo presente ma vuoto")
        return PackageEnergy(timestamp=ts, energy_mj=total_mj, available=True,
                             source=self.source, note=f"{seen} socket(s), field={self._energy_field}")

    def read_cores(self) -> List[CoreEnergy]:
        ts = time.time()
        if not self.is_windows() or self._conn is None:
            return []
        cores: List[CoreEnergy] = []
        try:
            insts = self._instances()
        except Exception:
            return []
        for idx, d in enumerate(insts):
            util = d.get("UtilizationPercentage")
            freq = d.get("CurrentFrequency")       # MHz
            cores.append(CoreEnergy(
                core_id=idx,
                timestamp=ts,
                perf_utility_pct=float(util) if util is not None else None,
                frequency_ghz=(float(freq) / 1000.0) if freq is not None else None,
            ))
        return cores

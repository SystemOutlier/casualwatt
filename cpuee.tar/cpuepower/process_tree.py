"""Enumerazione alberi di processo e snapshot differenziali dei tempi CPU.

Usa psutil (disponibile su Windows/Linux/macOS). Su Windows i tempi CPU provengono
da ``GetProcessTimes`` (kernel/user), quindi includono il tempo speso nelle syscall:
e' la metrica corretta per attribuire lavoro CPU a un processo.

Funzioni principali:
* :func:`find_roots_by_name` — trova tutti i processi con un dato exe name;
* :class:`ProcessTree` — albero radicato su un PID, con ``snapshot()``;
* :func:`snapshot_all_processes` — mappa pid->ProcessInfo di tutto il sistema
  (serve per calcolare il denominatore della frazione di CPU);
* :func:`compute_tree_delta` — differenza fra due snapshot → ProcessTreeDelta.

Nota "albero": se un software ha piu' root (es. Chrome con launcher + renderer orfani
ri-adottati da svchost/init), conviene usare :func:`tree_for_exe` che unisce gli alberi
di tutti i processi con lo stesso nome exe, considerando come "figli" anche i processi
il cui antenato con quel nome e' un altro membro del gruppo.
"""

from __future__ import annotations

import time
from typing import Dict, Iterable, List, Optional, Set

from .types import ProcessCpuTimes, ProcessInfo, ProcessTreeDelta


def _proc_info(p) -> Optional[ProcessInfo]:
    """Costruisce ProcessInfo da un psutil.Process, tollerando errori di accesso.

    Nota: ``cpu_affinity`` non e' disponibile su tutte le piattaforme (es. Linux
    sotto alcuni container/sandbox solleva RuntimeError): i metadati opzionali
    vengono raccolti singolarmente per non scartare l'intero processo.
    """
    try:
        # NB: su psutil.Process pid/ppid/name/create_time sono PROPRIETA' (non metodi)
        pid = p.pid
        ct = p.cpu_times()
        info = ProcessInfo(
            pid=pid,
            ppid=_safe(lambda: p.ppid, None),
            name=_safe(lambda: p.name, "?"),
            create_time=_safe(lambda: p.create_time, 0.0),
            cpu=ProcessCpuTimes(pid=pid, user_s=float(ct.user), kernel_s=float(ct.system)),
            threads=_safe(lambda: p.num_threads(), 0),
            num_cpus=_safe(lambda: len(p.cpu_affinity()), 0),
        )
        return info
    except Exception:
        # processi protetti/exit race: salta
        return None


def _safe(fn, default):
    try:
        return fn()
    except Exception:
        return default


def find_roots_by_name(exe_name: str, include_case_insensitive: bool = True) -> List[int]:
    import psutil

    target = exe_name.lower() if include_case_insensitive else exe_name
    roots: List[int] = []
    for proc in psutil.process_iter(["name"]):
        try:
            nm = (proc.info.get("name") or "")
            if (nm.lower() == target) if include_case_insensitive else (nm == target):
                roots.append(proc.pid)
        except Exception:
            continue
    return roots


class ProcessTree:
    """Albero di processi radicato su ``root_pid``.

    I nodi sono memorizzati come dict pid->ProcessInfo con ``children`` popolati.
    Le nuove creazioni di figli fra uno snapshot e l'altro vengono gestite
    ri-eseguendo :meth:`refresh`; i PID morti restano nel delta precedente per non
    perdere energia gia' consumata (vedi :func:`compute_tree_delta`).
    """

    def __init__(self, root_pid: int, follow_orphans: bool = False) -> None:
        self.root_pid = root_pid
        self.follow_orphans = follow_orphans
        self.nodes: Dict[int, ProcessInfo] = {}
        self.refresh()

    # ------------------------------------------------------------------ build
    def refresh(self) -> None:
        import psutil

        try:
            root = psutil.Process(self.root_pid)
        except psutil.NoSuchProcess:
            self.nodes = {}
            return
        infos: Dict[int, ProcessInfo] = {}
        stack = [root]
        seen: Set[int] = set()
        while stack:
            proc = stack.pop()
            if proc.pid in seen:
                continue
            seen.add(proc.pid)
            info = _proc_info(proc)
            if info is None:
                continue
            infos[proc.pid] = info
            try:
                stack.extend(proc.children(recursive=False))
            except (psutil.NoSuchProcess, psutil.AccessDenied):
                pass
        # collega children list
        for pid, info in infos.items():
            info.children = []
        for pid, info in infos.items():
            parent = infos.get(info.ppid if info.ppid in infos else None)
            if parent is not None and pid != self.root_pid:
                parent.children.append(info)
        self.nodes = infos

    @property
    def pids(self) -> Set[int]:
        return set(self.nodes.keys())

    def snapshot(self) -> Dict[int, ProcessCpuTimes]:
        """Rilegge i processi dell'albero e restituisce pid->cpu times correnti."""
        self.refresh()
        return {pid: info.cpu for pid, info in self.nodes.items()}

    def describe(self) -> str:
        lines = []

        def walk(info: ProcessInfo, depth: int) -> None:
            lines.append("  " * depth + f"{info.name} (pid {info.pid})")
            for ch in info.children:
                walk(ch, depth + 1)

        root = self.nodes.get(self.root_pid)
        if root:
            walk(root, 0)
        return "\n".join(lines)


def tree_for_exe(exe_name: str) -> List[ProcessTree]:
    """Tutti gli alberi radicati su processi con quel nome eseguibile."""
    return [ProcessTree(pid) for pid in find_roots_by_name(exe_name)]


def snapshot_all_processes() -> Dict[int, ProcessCpuTimes]:
    """CPU times di ogni processo visibile: denominatore per la frazione di CPU."""
    import psutil

    out: Dict[int, ProcessCpuTimes] = {}
    for proc in psutil.process_iter(attrs=None):
        try:
            ct = proc.cpu_times()
            out[proc.pid] = ProcessCpuTimes(pid=proc.pid, user_s=float(ct.user),
                                             kernel_s=float(ct.system))
        except Exception:
            continue
    return out


def compute_tree_delta(
    tree_pids: Iterable[int],
    before_tree: Dict[int, ProcessCpuTimes],
    after_tree: Dict[int, ProcessCpuTimes],
    before_system: Dict[int, ProcessCpuTimes],
    after_system: Dict[int, ProcessCpuTimes],
    window_s: float,
    root_name: str = "",
) -> ProcessTreeDelta:
    """Calcola il delta CPU dell'albero e del sistema fra due snapshot.

    Regole:
    * processo nuovo nell'albero (assente in before): delta = valore after intero
      (approssimazione: nato nella finestra);
    * processo morto (presente in before, assente in after): delta = prima - 0? Non
      conosciamo i tempi alla morte: usiamo 0 e annotiamo (limite documentato);
    * delta negativo (riciclo PID): clampato a 0.
    """
    tree_pids = set(tree_pids)
    per_pid: Dict[int, float] = {}
    per_pid_user: Dict[int, float] = {}
    for pid in tree_pids:
        a = after_tree.get(pid)
        b = before_tree.get(pid)
        if a is None:
            continue
        if b is None:
            d_total, d_user = a.total_s, a.user_s
        else:
            d_total = max(0.0, a.total_s - b.total_s)
            d_user = max(0.0, a.user_s - b.user_s)
        per_pid[pid] = d_total
        per_pid_user[pid] = d_user

    sys_total = 0.0
    all_pids = set(before_system) | set(after_system)
    for pid in all_pids:
        a = after_system.get(pid)
        b = before_system.get(pid)
        if a is not None and b is not None:
            sys_total += max(0.0, a.total_s - b.total_s)
        elif a is not None:
            # processo nato nella finestra: conta tutto il suo CPU time (upper bound)
            sys_total += max(0.0, a.total_s)
        # b is not None and a is None -> processo morto: i tempi alla morte non sono
        # piu' osservabili; contributo 0 (limite documentato nel README)

    return ProcessTreeDelta(
        root_pid=next(iter(tree_pids), 0),
        root_name=root_name,
        window_s=window_s,
        per_pid_delta_s=per_pid,
        per_pid_user_delta_s=per_pid_user,
        total_cpu_s=sum(per_pid.values()),
        system_total_cpu_s=sys_total,
        n_processes_in_tree=len(per_pid),
    )


def measure_window(tree: ProcessTree, window_s: float = 2.0) -> ProcessTreeDelta:
    """Pattern comune: snapshot → attendi → snapshot → delta.

    Include anche i processi che muoiono durante la finestra (l'energia consumata
    prima di morire resta contata perche' usiamo lo snapshot *prima*).
    """
    t0 = time.monotonic()
    before_tree = tree.snapshot()
    before_sys = snapshot_all_processes()
    time.sleep(window_s)
    after_tree = tree.snapshot()
    after_sys = snapshot_all_processes()
    dt = time.monotonic() - t0
    pids = set(before_tree) | set(after_tree)
    root_name = ""
    r = tree.nodes.get(tree.root_pid)
    if r:
        root_name = r.name
    return compute_tree_delta(pids, before_tree, after_tree, before_sys, after_sys,
                              window_s=dt, root_name=root_name)

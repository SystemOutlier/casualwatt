"""cpuepower - driver di lettura consumo CPU su Windows + attribuzione ad alberi di processo."""

__version__ = "0.1.0"

from .types import (
    CoreEnergy,
    PackageEnergy,
    ProcessCpuTimes,
    ProcessInfo,
    ProcessTreeEnergy,
    ReadingSource,
)
from .drivers.base import EnergyDriver, DriverCapability
from .drivers.wmi_msr import WmiMsrDriver
from .drivers.pdh import PdhDriver
from .drivers.rapl_registry import RaplRegistryDriver
from .drivers.estimate import EstimateDriver
from .process_tree import ProcessTree, snapshot_all_processes
from .attribution import AttributionMethod, TreeEnergyEstimator
from .sampler import EnergySampler, all_drivers, best_driver_for

__all__ = [
    "CoreEnergy",
    "PackageEnergy",
    "ProcessCpuTimes",
    "ProcessInfo",
    "ProcessTreeEnergy",
    "ReadingSource",
    "EnergyDriver",
    "DriverCapability",
    "WmiMsrDriver",
    "PdhDriver",
    "RaplRegistryDriver",
    "EstimateDriver",
    "ProcessTree",
    "snapshot_all_processes",
    "AttributionMethod",
    "TreeEnergyEstimator",
    "EnergySampler",
    "all_drivers",
    "best_driver_for",
]

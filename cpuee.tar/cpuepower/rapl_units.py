"""Decodifica dei contatori RAPL (MSR) in Joule reali.

Questa e' la parte "pura" che replica esattamente cio' che fa il tool di benchmark
EMI: legge i contatori cumulativi degli MSR RAPL e li converte in microJoule/Joule
usando l'unita' di misura scalata definita da ``IA32_RAPL_PKG_UNIT_MSR`` (0x606).

Layout MSR Intel (SDM Vol.4 cap.14, validato contro arch/x86/include/asm/msr-index.h
del kernel Linux e arch/x86/events/rapl.c::rapl_check_hw_unit()):

* ``0x606 IA32_RAPL_PKG_UNIT_MSR``      unita'/scale:
    - bits  0.. 3 : power_unit  -> 1 / 2^n  Watt per LSB dei power limit  (!!! non i joule)
    - bits  8..12 : energy_unit -> 1 / 2^n  Joule per LSB dei contatori energia
    - bits 14..17 : step_unit   -> incrementi dei power limit
    - bits 21..24 : time_unit   -> 1 / 2^n  secondi per LSB delle unita' tempo
  Il kernel estrae l'energy unit con ``(msr >> 8) & 0x1F`` (RAPL_UNIT_ENERGY_MASK).
  NON esiste alcun bit "data_wrapped" nel pkg_unit: l'avviso di wrap, quando c'e',
  arriva da altri mechanismi; qui il wrap si rileva dal delta negativo del contatore.
* ``0x611 MSR_PKG_ENERGY_STATUS``      Package energy counter (32 bit, wrap a 2^32*unit)
* ``0x639 MSR_PP0_ENERGY_STATUS``      Core domain (P-core/E-core, a seconda della Pi)
* ``0x641 MSR_PP1_ENERGY_STATUS``      GPU/uncore domain (assente su molti SKU)
* ``0x619 MSR_DRAM_ENERGY_STATUS``     Energia DRAM
* ``0x64D MSR_PLATFORM_ENERGY_COUNTER`` Energia piattaforma (Skylake+, "platform"/CUPS)

NB: 0x613 = MSR_PKG_PERF_STATUS, 0x614 = MSR_PKG_POWER_INFO, 0x618 =
MSR_DRAM_POWER_LIMIT: NON sono contatori di energia (errori corretti nel brief
MINI_IT13 del 23/10/2026).

I contatori sono *cumulativi* e a 32 bit: ogni lettura fornisce un valore assoluto
che va differenziato con la lettura precedente; se il delta risulta negativo si
compensa aggiungendo 2^32 (wrap).

Esempio tipico (client Tiger/Alder/Raptor Lake, incluso i9-13900HK):
pkg_unit grezzo 0x000A0E03 -> energy_unit=bits8-12=14 -> 2^-14 = 61,035 nJ/LSB,
power_unit=bits0-3=3 -> 2^-3 = 0,125 W/LSB, time_unit=bits21-24=10 -> 2^-10 s.
Un delta di 65536 LSB = esattamente 1 J.

Il modulo non dipende da Windows ne' da librerie esterne: e' testabile ovunque e
viene usato sia dal driver WMI/CIM (che restituisce gia' i raw counter) sia dal
driver RdMSR via WinRing0/LibreHardwareMonitor.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Optional

#: Dominio RAPL -> indirizzo MSR del contatore energia cumulativo (32 bit validi).
#: Nomi/valori verificati contro arch/x86/include/asm/msr-index.h del kernel Linux:
#:   MSR_PKG_ENERGY_STATUS=0x611, MSR_PP0_ENERGY_STATUS=0x639,
#:   MSR_PP1_ENERGY_STATUS=0x641, MSR_DRAM_ENERGY_STATUS=0x619,
#:   MSR_PLATFORM_ENERGY_COUNTER=0x64D.
#: NON usare 0x613 (MSR_PKG_PERF_STATUS), 0x614 (MSR_PKG_POWER_INFO),
#: 0x618 (MSR_DRAM_POWER_LIMIT): non sono contatori di energia.
RAPL_MSR_ADDRESSES: Dict[str, int] = {
    "package": 0x611,        # MSR_PKG_ENERGY_STATUS
    "pp0": 0x639,            # MSR_PP0_ENERGY_STATUS (core domain)
    "pp1": 0x641,            # MSR_PP1_ENERGY_STATUS (GPU/uncore)
    "dram": 0x619,           # MSR_DRAM_ENERGY_STATUS
    "platform": 0x64D,       # MSR_PLATFORM_ENERGY_COUNTER (Skylake+)
}

#: Indirizzo MSR delle unita' di misura scalate (vale per tutti i domini PKC).
PKG_UNIT_MSR = 0x606         # IA32_RAPL_PKG_UNIT_MSR
#: 0x618 e' MSR_DRAM_POWER_LIMIT (power limit, NON un'unita' di misura): tenuto
#: solo come riferimento storico, non usato in lettura.
DRAM_POWER_LIMIT_MSR = 0x618

COUNTER_BITS = 32
COUNTER_WRAP = 1 << COUNTER_BITS  # 2^32


@dataclass(frozen=True)
class RaplUnits:
    """Scale derivate da IA32_RAPL_PKG_UNIT_MSR (0x606).

    Field ``data_wrapped`` tenuto per compatibilita' d'API ma NON derivato dal
    pkg_unit: il SDM non definisce alcun bit data_wrapped in 0x606. Il wrap dei
    contatori si rileva dal delta negativo (vedi counter_delta_to_joules).
    """

    joule_unit_j: float          # Joule per LSB dei contatori energia (energy_unit, bits 8-12)
    watt_unit_w: float           # Watt per LSB dei power limit (power_unit, bits 0-3)
    time_unit_s: float           # Secondi per LSB delle unita' tempo (time_unit, bits 21-24)
    step_unit_w: Optional[float] = None   # incrementi power limit (bits 14-17)
    data_wrapped: bool = False   # sempre False: nessun bit del 0x606 lo rappresenta

    @classmethod
    def from_msr(cls, raw: int) -> "RaplUnits":
        """Decodifica il valore grezzo (64 bit) di IA32_RAPL_PKG_UNIT_MSR (0x606).

        Bitfield verificato contro il kernel Linux, arch/x86/events/rapl.c::
        rapl_check_hw_unit() e include/asm/msr-index.h::

            INTEL_RAPL_POWER_UNIT_MASK = GENMASK(3, 0)     -> watt  (LSB 0..3)
            INTEL_RAPL_ENERGY_UNIT_MASK = GENMASK(12, 8)   -> joule (LSB 8..12)
            INTEL_RAPL_TIME_UNIT_MASK = GENMASK(23, 16)    -> tempo (LSB 16..23)

        Attenzione al bug storico (brief MINI_IT13 P0-3): i joule NON sono nei
        bit 0-3. Sul 13900HK leggere i bit 0-3 come energy dava 2^-3 = 0,125 J
        invece di 2^-14 = 6,1e-5 J, cio' energie gonfiate ~2048x.
        """
        power_bits = (raw >> 0) & 0xF        # RAPL_UNIT_POWER_MASK  GENMASK(3,0)
        energy_bits = (raw >> 8) & 0x1F      # RAPL_UNIT_ENERGY_MASK GENMASK(12,8)
        step_bits = (raw >> 14) & 0xF        # RAPL_UNIT_STEP_MASK   GENMASK(17,14)
        time_bits = (raw >> 16) & 0xFF       # RAPL_UNIT_TIME_MASK   GENMASK(23,16)
        return cls(
            joule_unit_j=2.0 ** (-energy_bits),
            watt_unit_w=2.0 ** (-power_bits),
            time_unit_s=2.0 ** (-time_bits),
            step_unit_w=2.0 ** (-step_bits),
            data_wrapped=False,
        )

    @classmethod
    def default_client(cls) -> "RaplUnits":
        """Configurazione tipica Intel client (Alder/Raptor Lake): pkg_unit 0x000A0E03."""
        return cls.from_msr(0x000A0E03)

    #: Alias deprecato: prima si usava come fallback; ora == default_client().
    default_skylake = classmethod(lambda cls: cls.default_client())


def counter_to_joules(raw_counter: float, units: RaplUnits) -> float:
    """Converte un valore grezzo del contatore energia in Joule assoluti."""
    return float(raw_counter) * units.joule_unit_j


def counter_delta_to_joules(prev_raw: float, cur_raw: float,
                            units: RaplUnits, wrapped: bool = False) -> float:
    """Delta di due letture cumulative del *medesimo* contatore, in Joule.

    Gestisce il wrap-around a 32 bit: se cur < prev (o il bit data_wrapped e'
    impostato) aggiunge 2^32 LSB prima di scalare. Ritorna sempre >= 0.
    """
    diff = int(cur_raw) - int(prev_raw)
    if diff < 0 or wrapped:
        diff += COUNTER_WRAP
    if diff < 0:  # doppia wrap teorica: clamp
        diff = 0
    return diff * units.joule_unit_j


@dataclass
class RaplDomainReading:
    """Lettura istantanea + cumulato (in J) di un dominio RAPL (PKG/PP0/PP1/DRAM)."""

    name: str                    # "package" | "pp0" | "pp1" | "dram" | "platform"
    raw_counter: int             # valore grezzo 32 bit letto dall'MSR
    energy_j: float              # raw * joule_unit  (contatore cumulativo in J)
    available: bool = True
    note: str = ""


@dataclass
class RaplSnapshot:
    """Insieme coerente di letture RAPL prese nello stesso istante.

    ``counters`` mappa nome-dominio -> raw counter 32 bit (None se dominio assente).
    ``ts`` timestamp monotono associato alla lettura (per calcolare i Watt).
    """

    ts: float
    units: RaplUnits
    counters: Dict[str, Optional[int]]
    cpu_index: int = 0
    source: str = ""

    DOMAIN_TO_MSR = dict(RAPL_MSR_ADDRESSES)  # 0x611/0x639/0x641/0x619/0x64D (kernel msr-index.h)

    def readings(self) -> Dict[str, RaplDomainReading]:
        out: Dict[str, RaplDomainReading] = {}
        for dom, raw in self.counters.items():
            if raw is None:
                out[dom] = RaplDomainReading(dom, 0, 0.0, available=False, note="domain not exposed")
            else:
                out[dom] = RaplDomainReading(dom, raw, counter_to_joules(raw, self.units))
        return out

    def package_j(self) -> Optional[float]:
        raw = self.counters.get("package")
        return None if raw is None else counter_to_joules(raw, self.units)

    def dram_j(self) -> Optional[float]:
        raw = self.counters.get("dram")
        return None if raw is None else counter_to_joules(raw, self.units)


@dataclass
class RaplWindowEnergy:
    """Energia reale consumata dai vari domini in una finestra [before, after]."""

    window_s: float
    package_j: Optional[float]
    pp0_j: Optional[float]
    pp1_j: Optional[float]
    dram_j: Optional[float]
    platform_j: Optional[float]
    wrapped_domains: list
    units: RaplUnits

    @property
    def package_w(self) -> Optional[float]:
        if self.package_j is None or self.window_s <= 0:
            return None
        return self.package_j / self.window_s

    @property
    def dram_w(self) -> Optional[float]:
        if self.dram_j is None or self.window_s <= 0:
            return None
        return self.dram_j / self.window_s


def diff_snapshots(before: RaplSnapshot, after: RaplSnapshot) -> RaplWindowEnergy:
    """Delta energia (J) per dominio fra due snapshot, con gestione wrap."""
    units = after.units
    wrapped = units.data_wrapped or before.units.data_wrapped
    window_s = max(0.0, after.ts - before.ts)
    out: Dict[str, Optional[float]] = {}
    wrapped_domains = []
    for dom in ("package", "pp0", "pp1", "dram", "platform"):
        b = before.counters.get(dom)
        a = after.counters.get(dom)
        if b is None or a is None:
            out[dom] = None
            continue
        if int(a) < int(b):
            wrapped_domains.append(dom)
        out[dom] = counter_delta_to_joules(b, a, units, wrapped=(dom in wrapped_domains))
    return RaplWindowEnergy(
        window_s=window_s,
        package_j=out["package"], pp0_j=out["pp0"], pp1_j=out["pp1"],
        dram_j=out["dram"], platform_j=out["platform"],
        wrapped_domains=wrapped_domains, units=units,
    )

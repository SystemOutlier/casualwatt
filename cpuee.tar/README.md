# CPU Energy Drivers per Windows (Python)

Toolkit Python per **leggere il consumo energetico della CPU su Windows** e, dove possibile,
**isolare il consumo di un albero di processi** (un software con i suoi figli).

> ⚠️ Premessa importante: Windows **non espone una API pubblica per l'energia consumata dal
> singolo processo**. I driver qui implementati usano le sorgenti disponibili, ordinate per
> affidabilità, e una **stima euristica** (basata su tempo CPU per core + TDP) quando serve
> attribuire energia a un sotto-albero di processi. Vedi la sezione *Metodi di attribuzione*.

---

## Struttura del progetto

```
cpuepower/                 libreria principale
├── __init__.py
├── types.py               Dataclass: PackageEnergy, CoreEnergy, ProcessInfo, ProcessTreeEnergy...
├── drivers/               "Driver" di lettura (sorgenti dati)
│   ├── base.py            Interfaccia astratta EnergyDriver + capability probing
│   ├── wmi_msr.py         Driver A: WMI Root\wmi (ProcessorPerformance / ACPI) via pywin32
│   ├── pdh.py             Driver B: Performance Counter \Processor Information(*)\% Processor
│   │                      Utility  + \Processor Information(*)\Processor Performance Precise Total
│   ├── rapl_registry.py   Driver C: lettura valori RAPL/esposti da tool terzi nel registro
│   └── estimate.py        Driver D: stima da GetProcessTimes + TDP (funziona sempre)
├── process_tree.py        Enumerazione alberi di processo (psutil) + snapshot differenziale
├── attribution.py         Attribuzione energia -> albero di processo (3 strategie)
├── sampler.py             Campionatore periodico multi-driver con callback
└── cli.py                 CLI: `python -m cpuepower.cli ...`
examples/
├── list_drivers.py        Probe dell'hardware: quali driver sono attivi
├── monitor_package.py     Lettura in continuo del consumo package (driver migliori)
├── tree_chrome.py         Isolamento consumo albero di Chrome (o di qualsiasi exe)
└── tree_pid.py            Isolamento consumo a partire da un PID
tests/                     Test unitari (mock, eseguibili anche su Linux)
```

## Installazione

```bash
pip install -r requirements.txt      # psutil, pywin32 (solo Windows), pynvml opzionale
```

Su Linux/macOS la libreria è comunque importabile: i driver specifici Windows restituiscono
`taken=False`, resta disponibile il driver `estimate` basato su psutil.

## Uso rapido

### 1. Scoprire cosa offre la macchina

```bash
python -m cpuepower.cli probe
```

Output tipico su un laptop Intel con Intel Power Gadget installato:

```
[OK ] wmi_msr       WMI Root\wmi MSR readout        package=True  cores=False
[OK ] pdh            Performance Counters utility    package=False cores=True
[-- ] rapl_registry  Registro (Intel Power Gadget)   package=True  cores=False
[OK ] estimate       Stima CPU-time x TDP            package=False cores=False
Best driver for package energy: wmi_msr
```

### 2. Leggere il consumo del package CPU

```bash
python -m cpuepower.cli package --interval 1 --count 5
```

### 3. Isolare il consumo di un albero di processo

```bash
# tutto l'albero di chrome.exe
python -m cpuepower.cli tree --exe chrome.exe --window 5

# a partire da un PID
python -m cpuepower.cli tree --pid 12345 --window 5 --method apodictic
```

## Metodi di attribuzione (energy → process tree)

| Metodo          | Come funziona                                                                                                     | Precisione                                   |
|-----------------|-------------------------------------------------------------------------------------------------------------------|----------------------------------------------|
| `exact`         | Usa contatori per-processo esposti dal driver (es. WMI `ProcessorInformation` per-process o PerfCounter `\\Process(name)\\% Processor Utility` se presente) | Reale, ma raramente disponibile              |
| `apodictic`     | Ripartizione lineare: `E_tree = E_pkg * (ΣΔCPU_tree / ΣΔCPU_all)`                                                  | Buona approssimazione a livello package      |
| `heuristic`     | Per ogni core: quota di CPU dell'albero sul core × energia del core (da % Utility per core)                        | Migliore su CPU con contatori per-core       |
| `tdp_estimate`  | `P ≈ idle_frac*P_idle + active_frac*(TDP - P_idle)*C_state_adjust`                                                 | Ordine di grandezza, non richiede driver     |

Note:
- La ripartizione `apodictic` assume che il costo per cycle sia uniforme tra i processi: valido
  come prima approssimazione, ignora differenze AVX vs scalar e boost per-core.
- L'energia delle **GPU integrate** (GFX domain RAPL) non è attribuita ai processi; per quelle
  servirebbe NVML/ADL (fuori scope).

## Limitazioni note

1. **RAPL non è per-processo**: i MSR `PKG_ENERGY_STATUS`/`DRAM_ENERGY_STATUS` sono globali.
   L'attribuzione per-processo è sempre derivata da metriche di utilizzo (% Processor Utility,
   CPU time), quindi una **stima**, non una misura.
2. `% Processor Utility` (PDH/WMI) pesa l'utilizzo per frequenza: è il miglior proxy Windows
   per l'"energia relativa" di un processo. Il nostro driver `pdh` lo usa per la frazione.
3. Richiede privilegi admin per alcuni contatori PDH e per leggere determinati rami di registro.
4. AMD: su Ryzen il driver `wmi_msr` può esporre `AMD PSP` tramite WMI; altrove usare
   `estimate` + `turbostat`-like (WSL2) oppure RyzenMaster/ADLT se installati.

## Riferimenti API

- WMI: `Root\wmi`: `ProcessorPerformance`, `MSR_ProcessorPerformance`, `ACPI_ThermalZoneInformationEx`
- PDH: `\Processor Information(*)\% Processor Utility`, `\Processor Information(_Total)\Processor Performance Precise Total Base Mode`
- Win32: `GetProcessTimes`, `KUSER_SHARED_DATA`, `QueryNtPowerInformation(SystemPowerPolicyAc)`
